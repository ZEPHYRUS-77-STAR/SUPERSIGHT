# SecureSight AI — Full Production Folder Structure

Legend:  ✅ exists in current scaffold   ·   🟡 partial/stub   ·   ⬜ planned (not yet built)

```
securesight-ai/
│
├── README.md                                   ✅ project overview
├── NOTICE.md                                   ✅ scope & safety notice
├── LICENSE                                     ⬜ license text
├── CHANGELOG.md                                ⬜ release history
├── .gitignore                                  ✅
├── .editorconfig                               ⬜ formatting rules
├── pyproject.toml                              ⬜ root tooling (ruff/black/mypy)
│
├── backend/                                    ── FastAPI service + AI engine ──
│   ├── requirements.txt                        ✅ core deps
│   ├── requirements-optional.txt               ✅ heavy AI deps
│   ├── pytest.ini                              ⬜ test config
│   ├── Dockerfile                              ⬜ container build
│   ├── .env.example                            ⬜ config template
│   │
│   └── app/
│       ├── __init__.py                         ✅
│       ├── main.py                             ✅ FastAPI app, localhost bind, CORS
│       │
│       ├── api/                                ── REST layer ──
│       │   ├── __init__.py                     ✅
│       │   ├── routes.py                       ✅ /scan /protect /preview /history /audit
│       │   ├── routes_camera.py                ⬜ /camera/capture /camera/stream
│       │   ├── routes_upload.py                ⬜ /upload/guard (batch + per-app)
│       │   ├── routes_updates.py               ⬜ /updates/check /updates/apply
│       │   ├── schemas.py                      🟡 exists but ORPHANED — wire or remove
│       │   ├── deps.py                         ⬜ shared deps (rate-limit, size-limit)
│       │   └── errors.py                       ⬜ unified error handlers
│       │
│       ├── ai/                                 ── detection + protection engine ──
│       │   ├── __init__.py                     ✅
│       │   ├── pipeline.py                     ✅ orchestrator + CLI
│       │   ├── types.py                        ✅ Detection / RiskLevel / risk map
│       │   ├── blur.py                         ✅ region-only blur + annotate
│       │   ├── segment.py                      ✅ SAM box→mask (bbox fallback)
│       │   ├── ocr.py                          ✅ Paddle+Tesseract + sensitive text
│       │   ├── pii.py                          ✅ Aadhaar/PAN/passport/Luhn/IFSC
│       │   ├── model_registry.py               ⬜ resolve/load weights from ai_models/
│       │   └── detectors/
│       │       ├── __init__.py                 ✅
│       │       ├── opencv_face.py              ✅ Haar (always on)
│       │       ├── mediapipe_face.py           ✅ optional
│       │       ├── yolo.py                     ✅ person/object/weapon/document
│       │       ├── nsfw.py                     ✅ NudeNet
│       │       ├── face_match.py               ✅ identity match
│       │       ├── document_id.py              ⬜ dedicated ID-card classifier
│       │       └── weapon.py                   ⬜ dedicated weapon model
│       │
│       ├── camera/                             ── capture subsystem (MISSING) ──
│       │   ├── __init__.py                     ⬜
│       │   ├── capture.py                      ⬜ front/rear, HDR, flash
│       │   ├── video.py                        ⬜ recording
│       │   ├── live_scan.py                    ⬜ real-time AI overlay/warnings
│       │   └── devices.py                      ⬜ enumerate/select cameras
│       │
│       ├── integrations/                       ── upload guard (MISSING) ──
│       │   ├── __init__.py                     ⬜
│       │   ├── base.py                         ⬜ UploadGuard interface
│       │   ├── browser.py                      ⬜ browser upload hook
│       │   ├── whatsapp.py                     ⬜
│       │   ├── telegram.py                     ⬜
│       │   ├── gmail.py                        ⬜
│       │   ├── instagram.py                    ⬜
│       │   ├── facebook.py                     ⬜
│       │   ├── x.py                            ⬜
│       │   └── linkedin.py                     ⬜
│       │
│       ├── core/                               ── config / security / services ──
│       │   ├── __init__.py                     ✅
│       │   ├── config.py                       ✅ paths, thresholds, online flag
│       │   ├── crypto.py                       ✅ AES-256-GCM + PBKDF2
│       │   ├── protection.py                   ✅ consent-based, owner-recoverable
│       │   ├── watcher.py                      🟡 built but NOT wired into main.py
│       │   ├── updater.py                      ⬜ online model/threat-intel updates
│       │   ├── logging.py                      ⬜ encrypted structured logs
│       │   └── service.py                      ⬜ background service lifecycle
│       │
│       └── db/                                 ── encrypted local store ──
│           ├── __init__.py                     ✅
│           ├── database.py                     ✅ SQLite + AES, scans/audit/state
│           ├── models.py                       ⬜ table/dataclass definitions
│           └── migrations/                     ⬜ schema migrations
│               └── 0001_init.sql               ⬜
│
├── frontend/                                   ── React dashboard (production) ──
│   ├── index.html                              ✅ single-file runnable prototype
│   ├── package.json                            ⬜ Vite + React toolchain
│   ├── vite.config.ts                          ⬜
│   ├── tsconfig.json                           ⬜
│   ├── public/
│   │   └── favicon.svg                         ⬜
│   └── src/
│       ├── main.tsx                            ⬜ app entry
│       ├── App.tsx                             ⬜
│       ├── api/client.ts                       ⬜ typed API client
│       ├── components/
│       │   ├── Dropzone.tsx                    ⬜
│       │   ├── RiskReport.tsx                  ⬜
│       │   ├── ProtectionBadge.tsx             ⬜
│       │   ├── HistoryTable.tsx                ⬜
│       │   └── CameraView.tsx                  ⬜
│       ├── hooks/useScan.ts                    ⬜
│       └── styles/theme.css                    ⬜
│
├── desktop/                                    ── Electron shell ──
│   ├── package.json                            ✅ (currently in frontend/electron/)
│   ├── main.js                                 ✅ spawns backend + loads dashboard
│   ├── preload.js                              ⬜ secure context bridge
│   ├── tray.js                                 ⬜ system tray + status
│   └── resources/
│       ├── icon.ico                            ⬜ windows icon
│       ├── icon.icns                           ⬜ mac icon
│       └── icon.png                            ⬜ linux icon
│
├── ai_models/                                  ── model assets (empty today) ──
│   ├── README.md                               ⬜ where to obtain weights
│   ├── download_models.py                      ⬜ fetch + checksum verify
│   ├── weights/
│   │   ├── yolov8n.pt                          ⬜
│   │   ├── yolov8-document.pt                  ⬜ custom ID/doc model
│   │   ├── sam_vit_b.pth                       ⬜
│   │   └── nudenet/                            ⬜
│   ├── configs/
│   │   └── thresholds.yaml                     ⬜ per-category confidences
│   └── training/                               ── dataset + training ──
│       ├── label_studio_config.xml             ⬜ annotation schema
│       ├── prepare_dataset.py                  ⬜
│       ├── train_yolo.py                       ⬜
│       └── datasets/                           ⬜ (gitignored)
│
├── database/                                   ── DB ops (runtime data is local) ──
│   ├── schema.sql                              ⬜ canonical schema
│   ├── seed.sql                                ⬜ optional defaults
│   └── backup/                                 ⬜ encrypted backup target
│
├── installer/                                  ── packaging per OS ──
│   ├── windows/
│   │   ├── securesight.nsi                     ⬜ NSIS script
│   │   └── electron-builder.yml                ⬜
│   ├── macos/
│   │   ├── entitlements.plist                  ⬜
│   │   └── notarize.js                         ⬜
│   ├── linux/
│   │   ├── securesight.desktop                 ⬜
│   │   └── appimage.yml                        ⬜
│   └── service/
│       ├── securesight.service                 ⬜ systemd (user scope)
│       └── windows_service.md                  ⬜ service install notes
│
├── scripts/                                    ── build & run helpers ──
│   ├── install.sh                              ✅
│   ├── run.sh                                  ✅
│   ├── build_frontend.sh                       ⬜
│   ├── build_desktop.sh                        ⬜
│   ├── build_all.sh                            ⬜ end-to-end release build
│   ├── package_installers.sh                   ⬜
│   └── smoke_test.sh                           ⬜ CLI smoke gate
│
├── tests/  (backend/tests/)                    ── test suite ──
│   ├── __init__.py                             ✅
│   ├── test_pii.py                             ✅
│   ├── test_blur.py                            ✅
│   ├── test_protection.py                      ✅
│   ├── test_pipeline.py                        ⬜ end-to-end integration
│   ├── test_api.py                             ⬜ FastAPI TestClient
│   ├── test_crypto.py                          ⬜ AES/PBKDF2 round-trip
│   ├── test_database.py                        ⬜ encrypted store
│   ├── e2e/                                    ⬜ Playwright dashboard tests
│   └── fixtures/                               ⬜ sample images
│
├── docs/                                       ── documentation ──
│   ├── ARCHITECTURE.md                         ✅
│   ├── SECURITY.md                             ✅
│   ├── INSTALL.md                              ✅
│   ├── DEPLOY.md                               ✅
│   ├── TESTING.md                              ✅
│   ├── STRUCTURE.md                            ✅ (this file)
│   ├── API.md                                  ⬜ endpoint reference
│   ├── CAMERA.md                               ⬜ capture subsystem
│   └── diagrams/                               ⬜ architecture/flow images
│
├── samples/                                    ── demo assets ──
│   ├── sample_input.png                        ✅
│   ├── sample_detected.png                     ✅
│   └── sample_protected.png                    ✅
│
└── .github/
    └── workflows/
        ├── ci.yml                              ⬜ lint + tests + smoke
        └── release.yml                         ⬜ build + sign installers
```

## Summary counts
- ✅ exists: 41 files/dirs   ·   🟡 partial/orphaned: 3   ·   ⬜ planned: ~95

## Notes tying back to the audit
- `app/api/schemas.py` is 🟡 — present but unimported; either wire into routes or delete.
- `app/core/watcher.py` is 🟡 — fully written but never imported by `main.py`.
- `camera/` and `integrations/` are the two largest ⬜ gaps (the capture and
  auto-upload ends of the intended flow).
- `desktop/` is shown as a top-level folder here; in the current scaffold the
  Electron files live under `frontend/electron/` — move during productionization.
