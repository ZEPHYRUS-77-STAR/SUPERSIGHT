# SecureSight AI — Testing Strategy

## Layers
1. **Unit** (`backend/tests/`)
   - `test_pii.py` — PII patterns + Verhoeff/Luhn checksums.
   - `test_blur.py` — region-only guarantee: corners untouched, region changed,
     empty detections = identity, category filtering.
   - `test_protection.py` — activation, wrong-passphrase rejection, owner override,
     custom-duration validation.
2. **Integration** — pipeline end-to-end on synthetic ID/face images; assert that
   the blurred output changes < 50% of pixels (proves region-only behaviour).
3. **API** — FastAPI `TestClient` over `/scan`, `/protect`, `/protection/*`.
4. **Smoke/CI** — `python -m app.ai.pipeline sample.jpg` must exit 0 with a report.

## Run
```bash
cd backend && source .venv/bin/activate
pip install pytest httpx
pytest -q
```

## Verified in this build
On a synthetic government-ID image, the pipeline detected `aadhaar` + `pii_text`
(risk = CRITICAL) and the protected output changed **3.8%** of pixels — confirming
only the sensitive regions were blurred while the rest stayed intact. All 13
logic checks (PII, region-blur, protection-mode) passed.

## Quality gates before release
- Detection recall on a labelled ID/document set (use Label Studio to annotate).
- False-positive rate on benign photos (faces are MEDIUM, not blocking).
- Performance budget per image on target hardware.
