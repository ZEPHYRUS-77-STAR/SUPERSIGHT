# SecureSight AI — Security & Privacy Design

## Threat model & posture
SecureSight AI protects the **user's own privacy** by catching sensitive content
before it is shared. It is a *defensive* tool. It is **not** surveillance software
and contains no capability to monitor a person without their knowledge or to
withhold control of the device from its owner.

## Why we did NOT build "unremovable / anti-bypass" protection
The original brief asked for software that cannot be uninstalled, disabled,
stopped, or bypassed, with anti-bypass detection, an admin lockout, and a
self-respawning watchdog. We deliberately **did not implement** these, because:

- Code that resists removal by the device owner, relaunches itself when killed,
  and locks out the administrator is **technically indistinguishable from a
  rootkit / stalkerware**, regardless of intent.
- It would violate the owner's control of their own machine and most platform
  policies (Windows, macOS, Android, app stores), and could not be safely shipped.
- The same mechanism is exactly what malware and abusers rely on.

### What we built instead: consent-based, owner-recoverable Protection Mode
- The user enables protection for a chosen duration (1/7/15/30/90 days or custom).
- While active, the app keeps monitoring and applying policy.
- At activation the user sets a **recovery passphrase** (PBKDF2-HMAC-SHA256,
  200k iterations). The device owner can **always** override/disable protection
  with it, and can **always** uninstall the software.
- All state changes are written to an encrypted **audit log**.

This preserves the useful "I want to commit to safe-sharing for two weeks"
behaviour without ever taking control away from the owner.

## Data protection
- **Local only**: image bytes are processed in memory and never persisted to disk
  by default and never transmitted off-device. No telemetry.
- **Encryption at rest**: AES-256-GCM (via `cryptography`) for DB detail columns,
  audit details, and any quarantined files. Device-local key in `keyring.bin`
  (0600). A clearly-labelled non-crypto fallback exists only for dev when the
  `cryptography` package is missing — not for production.
- **Key handling**: keys never leave the device; no escrow, no server.
- **Network**: API binds to `127.0.0.1`; CORS limited to the local dashboard
  origin. Online mode (updates only) is opt-in and off by default.

## Compliance alignment
- **GDPR / India DPDP Act**: data minimisation (no image storage), purpose
  limitation (local privacy protection only), privacy-by-design/default,
  user control (enable/override/uninstall), and an auditable processing log.
- Because no personal data is collected or transmitted, the software acts as a
  local tool under the user's sole control rather than a data processor service.

## Hardening checklist for production
- Ship `cryptography`; fail closed if it is unavailable.
- Sign released binaries; verify update packages before applying.
- Run the service as the user (not elevated) — it needs no admin rights.
- Store the recovery passphrase hash only; never the plaintext.
- Rate-limit and size-limit uploads at the API layer.
