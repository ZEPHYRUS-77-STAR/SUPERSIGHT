# SecureSight AI — API Reference

Base URL: `http://127.0.0.1:8077/api` (localhost only).

## Core
| Method | Path | Body | Returns |
|--------|------|------|---------|
| GET | `/health` | — | version + active backends + online flag |
| POST | `/scan` | multipart `file` | JSON `ScanResult` (risk, detections, warning) |
| POST | `/protect` | multipart `file` (+ `categories`, `method`) | region-blurred JPEG + `X-SecureSight-Risk` header |
| POST | `/preview` | multipart `file` | annotated JPEG (boxes) |
| GET | `/history?limit=` | — | recent scans (decrypted locally) |
| GET | `/audit?limit=` | — | audit log |

## Protection mode (consent-based, owner-recoverable)
| Method | Path | Body |
|--------|------|------|
| GET | `/protection/status` | — |
| POST | `/protection/activate` | `{duration:"1d|7d|15d|30d|90d|custom", recovery_passphrase, custom_seconds?}` |
| POST | `/protection/deactivate` | `{recovery_passphrase}` (owner override) |

## Camera
| Method | Path | Body |
|--------|------|------|
| GET | `/camera/devices` | — |
| POST | `/camera/capture` | `{out_dir, device?, hdr?, flash?, auto_blur?, filename?}` |
| POST | `/camera/record/start` | `{out_path, device?, fps?, scan_every?, max_seconds?}` |
| POST | `/camera/record/stop` | `{out_path}` |

## Upload guard (scan-before-attach)
| Method | Path | Body |
|--------|------|------|
| GET | `/upload/platforms` | — |
| POST | `/upload/guard` | `{image_path, platform, out_dir?}` |
| POST | `/upload/guard/batch` | `{image_paths:[...], platform, out_dir?}` |

## Updates (opt-in online mode) & service
| Method | Path | Body |
|--------|------|------|
| GET | `/updates/models` | — (which weights are present) |
| POST | `/updates/check` | `{force?}` |
| GET | `/service/status` | — |
| POST | `/service/watch` | `{folder}` (folder auto-scan) |
| POST | `/service/unwatch` | `{folder}` |

### ScanResult shape
```json
{
  "width": 520, "height": 300, "risk": "critical", "count": 2,
  "detections": [
    {"category": "aadhaar", "confidence": 0.97, "box": [40,120,114,22],
     "source": "tesseract", "risk": "critical", "explanation": "..."}
  ],
  "backends": {"face": "opencv_haar", "ocr": "tesseract", "...": "..."},
  "warning": "2 sensitive region(s) found [CRITICAL]: aadhaar, pii_text..."
}
```
