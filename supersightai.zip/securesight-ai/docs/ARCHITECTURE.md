# SecureSight AI — Architecture

## 1. Principles
- **Local-first / zero-trust**: image bytes never leave the device. The API binds
  to `127.0.0.1` only. No telemetry, no server-side image storage.
- **Graceful degradation**: the pipeline always runs on bundled OpenCV + regex PII;
  deep-learning detectors (YOLO/SAM/MediaPipe/PaddleOCR/NudeNet/face_recognition)
  activate automatically when their weights/packages are present.
- **Region-only protection**: only sensitive pixels are blurred, never the whole image.
- **Owner sovereignty**: Protection Mode is consent-based and always recoverable.

## 2. High-level component diagram

```
                       ┌──────────────────────────────┐
   Electron desktop    │        React Dashboard        │
   shell (optional) ──►│  scan · report · protect · UI │
                       └───────────────┬──────────────┘
                                       │ HTTP (localhost:8077)
                       ┌───────────────▼──────────────┐
                       │        FastAPI service        │
                       │  /scan /protect /preview      │
                       │  /history /audit /protection  │
                       └───────┬───────────────┬───────┘
                               │               │
                 ┌─────────────▼───┐     ┌─────▼───────────────┐
                 │   AI Pipeline    │     │  Encrypted SQLite   │
                 │  (orchestrator)  │     │  scans·audit·state  │
                 └───┬───────┬──────┘     └─────────────────────┘
        ┌────────────┘       └───────────────┐
        ▼                                     ▼
 ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
 │  Detectors   │  │     OCR      │  │  Segmenter   │  │ Blur engine  │
 │ face/obj/    │  │ Paddle+Tess  │  │    (SAM)     │  │  (OpenCV)    │
 │ nsfw/match   │  │  + PII regex │  │  box→mask    │  │ region-only  │
 └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘
        ▲
 ┌──────┴───────┐
 │  Watchdog    │  folder auto-scan (monitor & warn)
 └──────────────┘
```

## 3. AI pipeline (data flow)

1. **Decode** image (OpenCV) → BGR ndarray.
2. **Detect** in parallel categories:
   - Faces: MediaPipe if available, else OpenCV Haar (always on); optional
     `face_recognition` labels known identities.
   - Objects/persons/weapons/documents: YOLOv8 (optional).
   - NSFW: NudeNet (optional).
   - Sensitive text: OCR (PaddleOCR→Tesseract) → PII classifier (Aadhaar Verhoeff,
     PAN format, passport/DL patterns, Luhn cards, IFSC, email, phone, keywords).
3. **Merge** near-duplicate boxes (IoU), assign per-category **risk level**.
4. **Report**: overall risk + human-readable warning/explanations.
5. **Protect** (on request): for each region, optionally tighten the box to a
   **SAM mask**, blur only those pixels (gaussian/pixelate/fill), composite over
   the untouched original.

`backend/app/ai/pipeline.py` is the single orchestrator; detectors are isolated,
lazy, and independently testable.

## 4. Folder structure

```
backend/app/
  main.py                 FastAPI app, localhost bind, CORS to local dashboard
  api/        routes.py   /scan /protect /preview /history /audit /protection/*
              schemas.py   pydantic models
  ai/         pipeline.py  orchestrator + CLI
              types.py     Detection, RiskLevel, category→risk map
              blur.py      region-only blur + annotate
              ocr.py       Paddle/Tesseract + sensitive-text extraction
              pii.py       PII patterns + checksums (Verhoeff/Luhn)
              segment.py   SAM box→mask (bbox fallback)
              detectors/   opencv_face · mediapipe_face · yolo · nsfw · face_match
  core/       config.py    paths, thresholds, online flag
              crypto.py    AES-256-GCM + PBKDF2 passphrase
              protection.py consent-based, owner-recoverable Protection Mode
              watcher.py   Watchdog folder auto-scan
  db/         database.py  encrypted SQLite (scans/audit/protection/known_faces)
```

## 5. Database design (SQLite, sensitive columns AES-256-GCM encrypted)

| Table | Columns | Notes |
|-------|---------|-------|
| `scans` | id, ts, source, risk, n_regions, **detail_enc** | detail JSON encrypted; no image bytes |
| `audit` | id, ts, event, **detail_enc** | tamper-evident event log |
| `protection` | id=1, active, started, expires, recovery_salt, recovery_hash | single-row state |
| `known_faces` | id, name, **encoding_enc** | optional local identity gallery |

## 6. API design

| Method | Path | Purpose |
|--------|------|---------|
| GET  | `/api/health` | version + active backends |
| POST | `/api/scan` | multipart image → JSON risk report |
| POST | `/api/protect` | multipart image → region-blurred JPEG (+risk headers) |
| POST | `/api/preview` | annotated boxes JPEG |
| GET  | `/api/history` | recent scans (decrypted locally) |
| GET  | `/api/audit` | audit log |
| GET  | `/api/protection/status` | protection state |
| POST | `/api/protection/activate` | enable for duration + recovery passphrase |
| POST | `/api/protection/deactivate` | owner override (requires passphrase) |

## 7. Online vs Offline
- **Offline (default)**: all detection, OCR, blur, risk analysis run locally.
- **Online (opt-in)**: only model/threat-intel update downloads; no image upload.
  Controlled by `settings.online_mode` (default `False`).

## 8. Deployment
Desktop: Electron shell spawns the local FastAPI process and loads the dashboard.
Headless/service: run `python -m app.main` (systemd unit / Windows service / Docker).
See `DEPLOY.md`.
