# SecureSight AI — Deployment

## A. Desktop application (recommended)
Package the Electron shell with `electron-builder`:
```bash
cd frontend && npm install && npm run dist
```
Produces a platform installer in `dist/`. The installer bundles the dashboard and
launches the local Python backend. (Bundle a Python runtime or require it as a
prerequisite, depending on your distribution strategy.)

## B. Local service (headless)
Run the API as a normal-user service.

**systemd (Linux), user scope:**
```ini
# ~/.config/systemd/user/securesight.service
[Unit]
Description=SecureSight AI local service
[Service]
WorkingDirectory=%h/securesight-ai/backend
ExecStart=%h/securesight-ai/backend/.venv/bin/python -m app.main
Restart=on-failure
[Install]
WantedBy=default.target
```
```bash
systemctl --user enable --now securesight
```
> Note: `Restart=on-failure` here is ordinary crash recovery of a user service —
> the user can stop/disable it at any time. It is **not** an anti-uninstall watchdog.

## C. Docker (CPU)
```dockerfile
FROM python:3.11-slim
RUN apt-get update && apt-get install -y libgl1 libglib2.0-0 tesseract-ocr \
    && rm -rf /var/lib/apt/lists/*
WORKDIR /app
COPY backend/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY backend /app
EXPOSE 8077
CMD ["python", "-m", "app.main"]
```
```bash
docker build -t securesight-ai .
docker run --rm -p 127.0.0.1:8077:8077 -v ss_data:/root/.securesight securesight-ai
```

## D. Production build checklist
- Pin and install `cryptography`; fail closed if missing.
- Set `settings.online_mode` policy and a real signed `update_url`.
- Keep the bind address on loopback unless you front it with an authenticated proxy.
- Add request size/rate limits.
- Run `python -m app.ai.pipeline` smoke test in CI; run the test suite.
- Code-sign desktop binaries.
