# SecureSight AI — Installation

## Requirements
- Python 3.10+
- (optional desktop) Node.js 18+ for the Electron shell
- (optional OCR backup) the system `tesseract` binary

## 1. Core install (works everywhere)
```bash
cd securesight-ai
bash scripts/install.sh            # or do it manually:
# cd backend && python -m venv .venv && source .venv/bin/activate
# pip install -r requirements.txt
```
This gives you: face detection (OpenCV), full PII/ID text detection, region blur,
the API, the DB, and Protection Mode.

## 2. Run
```bash
bash scripts/run.sh                # starts API on http://127.0.0.1:8077
```
Open `frontend/index.html` in a browser (or use the Electron shell below).

CLI (no server):
```bash
cd backend
python -m app.ai.pipeline some.jpg --out protected.jpg --preview boxes.jpg
```

## 3. Optional heavy AI models
Enable any subset; the pipeline auto-detects them:
```bash
cd backend && source .venv/bin/activate
pip install -r requirements-optional.txt
# YOLOv8 weights download on first use; for SAM, place a checkpoint and set it
# in app/ai/segment.py (Segmenter(checkpoint=...)).
```
Platform notes:
- **Tesseract**: `apt install tesseract-ocr` (Linux), `brew install tesseract` (mac),
  or the UB-Mannheim installer (Windows).
- **face_recognition** needs `dlib` (a C++ build toolchain / CMake).
- **PaddleOCR** needs `paddlepaddle` matching your CPU/GPU.

## 4. Desktop shell (Electron)
```bash
cd frontend
npm install
npm start                          # launches backend + dashboard window
npm run dist                       # build installer via electron-builder
```

## 5. Data location
App data (DB, keys, models, quarantine) lives in:
- Windows: `%APPDATA%\SecureSightAI`
- Linux/mac: `~/.securesight`
Override with the `SECURESIGHT_HOME` environment variable.
