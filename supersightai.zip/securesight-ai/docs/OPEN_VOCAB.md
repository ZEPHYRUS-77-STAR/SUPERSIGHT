# Open-Vocabulary Detection (YOLO-World + Grounding DINO)

SecureSight uses two zero-shot, text-prompted detectors so it can flag dangerous
or sensitive objects that aren't in any fixed class list — guns, knives, military
vehicles, ID cards, etc. — just by naming them.

## How it works
1. `ai/open_vocab.py` defines prompts grouped by SecureSight risk category
   (e.g. `firearm: ["a gun","a handgun","a rifle", ...]`).
2. `detectors/yolo_world.py` (Ultralytics **YOLO-World**) sets those phrases as its
   class vocabulary and localises them.
3. `detectors/grounding_dino.py` (**Grounding DINO**, via HuggingFace Transformers or
   the standalone package) does text-conditioned detection with the same prompts.
4. Each detection is mapped back to a risk category → fed into `risk_scoring_service`
   → if HIGH, `redaction_service` applies **permanent black-box** redaction to that
   exact object. No fixed-class retraining required.

## Risk → action (unchanged engine, now fed by open-vocab)
| Detected (example prompt) | Category | Weight | Result |
|---|---|---|---|
| "a handgun" / "a rifle" | firearm | 90 | HIGH → BLOCK + black box |
| "a knife" | weapon | 90 | HIGH → BLOCK + black box |
| "a military tank" / "a missile" | military_sensitive | 100 | HIGH → BLOCK + black box |
| "a passport" | passport | 70 | HIGH → BLOCK + black box |
| "a credit card" | bank_document | 75 | HIGH → BLOCK + black box |
| "a human face" | face | 15 | contributes to score |

## Online vs offline
- **Online**: first run downloads the model weights (YOLO-World `.pt` from
  Ultralytics; Grounding DINO from HuggingFace).
- **Offline**: once cached locally the detectors run with no network. Everything
  else (OCR, PII, blur, redaction, scoring, DB) is already fully offline.

## Enable
```
pip install -r backend/requirements-optional.txt   # ultralytics + transformers + pillow
```
Weights auto-resolve from `ai_models/weights/` (see `model_registry.py`):
`yolov8s-worldv2.pt`, `groundingdino_swint_ogc.pth`. Without them these two
detectors stay silently disabled and the rest of the pipeline runs normally.
