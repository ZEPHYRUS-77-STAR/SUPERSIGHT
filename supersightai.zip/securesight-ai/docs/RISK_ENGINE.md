# Smart Risk Assessment & Upload Control Engine

A conditional, two-stage system that runs before any save/share/sync/upload.

## Flow
```
Image → Stage1 sensitive_content_detector
      → if NOT sensitive:  ALLOW_UPLOAD  (scoring + redaction skipped)
      → if sensitive:      risk_scoring_service → classify
                           → redaction_service (black box, if required)
                           → upload_decision_engine → notification
```
No image containing sensitive content bypasses scoring.

## Services (`backend/app/services/`)
- `sensitive_content_detector.py` — Stage 1. Runs the detector stack (YOLOv8,
  Paddle/Tesseract OCR, MediaPipe, NudeNet, face_recognition + OpenCV fallbacks)
  and adds OCR-keyword detection for military / restricted-area / government-secret
  / employee-ID. Returns `(has_sensitive, detections)`.
- `risk_scoring_service.py` — weighted 0–100 score + HIGH/MEDIUM/LOW bands.
- `redaction_service.py` — permanent **black-box** redaction (solid fill, not blur;
  non-recoverable). Coordinates from detectors, optionally tightened by SAM.
- `upload_decision_engine.py` — orchestrates and returns the decision.
- `privacy_settings_service.py` — PII-as-sensitive toggle (default OFF).

## Scoring weights
military 100 · government_secret 100 · restricted_area 95 · weapon/firearm 90 ·
aadhaar 80 · pan/bank_document 75 · nsfw 70 · passport/driving_licence 70 ·
sensitive_ocr 60 · signature/employee_id 40 · face 15 · pii_text 20 (only if enabled).

Aggregation: `score = min(100, max_weight + 0.3 * sum(other_weights))`.

## Bands & decisions
| Band | Score | Decision | Redaction | Override |
|------|-------|----------|-----------|----------|
| HIGH | 70–100 | `BLOCK_UPLOAD` | black box (local copy) | none |
| MEDIUM | 40–69 | `ALLOW_UPLOAD_OF_REDACTED_VERSION_ONLY` | auto black box | none |
| LOW | 0–39 | `ALLOW_UPLOAD` | optional, user choice | yes |

## API
- `POST /api/risk/assess` (multipart `file`) → full decision JSON.
- `POST /api/risk/redacted` (multipart `file`) → black-box redacted JPEG.
- `GET/POST /api/privacy/settings` → `{treat_pii_as_sensitive: bool}`.

Redacted HIGH/MEDIUM copies are written to the encrypted quarantine dir; decisions
are recorded in the encrypted audit log.
