# SecureSight AI — Camera Subsystem

Two capture paths, both AI-gated (an image is scanned before it is saved):

## 1. Server-side hardware capture (`backend/app/camera/`)
- `devices.py` — enumerate/select cameras (OpenCV `VideoCapture`).
- `capture.py` — still capture with:
  - **HDR**: real exposure fusion (`cv2.createMergeMertens`) over 3 bracketed frames.
  - **Flash**: honest software low-light boost (gamma + brightness) for webcams
    whose hardware torch isn't controllable cross-platform.
  - **AI gate**: the frame is scanned and, if `auto_blur` is on, sensitive regions
    are blurred *before* the file is written to `out_dir`.
- `video.py` — `VideoRecorder` records to mp4 while scanning every Nth frame and
  logging risky moments to the encrypted audit log.
- `live_scan.py` — `live_frames()` generator yields annotated frames + detections
  for a real-time preview with warnings.

Driven via the `/api/camera/*` endpoints (see API.md).

## 2. Browser capture (`frontend/src/components/CameraView.tsx`)
Uses `getUserMedia` for the live preview and posts a captured frame to `/api/scan`.
Good for the web dashboard where the browser owns the camera permission.

## Capture → save flow
```
open device → grab frame(s) → [HDR fuse] → [flash boost]
   → Pipeline.scan → if risky & auto_blur → region-blur
   → write file → audit log (risk, regions, blurred)
```
No frame is written to disk before it passes the scan step.
