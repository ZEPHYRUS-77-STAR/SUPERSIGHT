# NOTICE — scope of this build

This is a **runnable reference scaffold**, not a finished commercial product.

- The OpenCV face detection, PII/ID text detection, region-only blur, FastAPI
  service, encrypted SQLite, and consent-based Protection Mode work out of the box.
- The deep-learning detectors (YOLOv8, SAM, MediaPipe, PaddleOCR, NudeNet,
  face_recognition) are integrated behind clean interfaces and activate when their
  packages/weights are installed; otherwise the pipeline degrades gracefully.
- For production you must train/supply the document & weapon models, add ID/
  document datasets (annotate with Label Studio), and complete the hardening
  checklist in docs/SECURITY.md and docs/DEPLOY.md.

Intentionally **excluded** for safety: anti-uninstall, anti-bypass, admin
lockout, and self-respawning watchdog behaviour. See docs/SECURITY.md.
