// SecureSight AI — offline desktop shell.
// Orchestrates first-run setup, starts the local FastAPI backend on the SQLite
// fallback (no internet / Postgres needed), shows a startup status splash while
// verifying services, then loads the built SPA. Tray keeps it running.
const { app, BrowserWindow, Tray, Menu, nativeImage } = require("electron");
const path = require("path");
const http = require("http");
const { ensureSetup, resourcePath } = require("./bootstrap");

const API_PORT = 8088;
const API_BASE = `http://127.0.0.1:${API_PORT}`;
let backend = null, win = null, splash = null, tray = null;

function loadSplash() {
  splash = new BrowserWindow({ width: 520, height: 360, frame: false, resizable: false,
    webPreferences: { contextIsolation: true } });
  splash.loadFile(path.join(__dirname, "splash.html"));
}

function startBackend(pythonExe) {
  const cwd = resourcePath("backend-v2");
  backend = require("child_process").spawn(pythonExe, ["-m", "app.main"], {
    cwd,
    stdio: "inherit",
    env: { ...process.env,
      SECURESIGHT_ENV: "desktop",
      DATABASE_URL: "",                 // empty -> SQLite offline fallback
      JWT_SECRET: process.env.JWT_SECRET || "desktop-local-secret-change-me" },
  });
  backend.on("error", (e) => console.error("backend failed:", e));
}

function ping(pathname) {
  return new Promise((resolve) => {
    http.get(`${API_BASE}${pathname}`, (r) => resolve(r.statusCode === 200))
        .on("error", () => resolve(false));
  });
}

async function waitForServices(maxMs = 60000) {
  const start = Date.now();
  const steps = [
    ["Backend service", "/api/health"],
    ["Database & storage", "/api/health/services"],
  ];
  for (const [label, pth] of steps) {
    splash?.webContents.send("status", { label, state: "checking" });
    while (Date.now() - start < maxMs) {
      if (await ping(pth)) { splash?.webContents.send("status", { label, state: "ok" }); break; }
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
}

function createMainWindow() {
  win = new BrowserWindow({
    width: 1200, height: 840, show: false, title: "SecureSight AI",
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true },
  });
  // Built SPA (frontend-v2/dist). Built with VITE_API_BASE=http://127.0.0.1:8088.
  win.loadFile(resourcePath(path.join("frontend-v2", "dist", "index.html")));
  win.once("ready-to-show", () => { win.show(); splash?.close(); splash = null; });
}

function makeTray() {
  const img = nativeImage.createFromPath(path.join(__dirname, "resources", "icon.png"));
  tray = new Tray(img.isEmpty() ? nativeImage.createEmpty() : img);
  tray.setToolTip("SecureSight AI (offline)");
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: "Open", click: () => win?.show() },
    { type: "separator" },
    { label: "Quit", click: () => app.quit() },
  ]));
}

app.whenReady().then(async () => {
  loadSplash();
  try {
    const pythonExe = await ensureSetup((msg) => splash?.webContents.send("status", msg));
    startBackend(pythonExe);
    await waitForServices();
  } catch (e) {
    splash?.webContents.send("status", { label: "Setup failed", state: "error", detail: String(e) });
  }
  createMainWindow();
  makeTray();
});

app.on("window-all-closed", (e) => { /* keep alive in tray */ });
app.on("before-quit", () => { if (backend) backend.kill(); });
