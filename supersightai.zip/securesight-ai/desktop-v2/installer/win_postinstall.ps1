# Optional post-install helper (NSIS already creates shortcuts + auto-launch).
# Verifies Python is available and warns if not, so first-run setup can proceed.
$ErrorActionPreference = "SilentlyContinue"
$py = (Get-Command python -ErrorAction SilentlyContinue) ?? (Get-Command py -ErrorAction SilentlyContinue)
if (-not $py) {
  [System.Windows.MessageBox]::Show(
    "SecureSight AI needs Python 3.10+ for local AI processing. Please install it from python.org, then relaunch.",
    "SecureSight AI") | Out-Null
}
