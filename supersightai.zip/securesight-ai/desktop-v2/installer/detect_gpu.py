"""GPU / CUDA detection for SecureSight AI desktop.

Writes <SECURESIGHT_HOME>/gpu.json describing the compute device so the backend
and UI can show CPU vs GPU mode. Priority: NVIDIA GPU (CUDA) -> CPU fallback.
Runs during first-run setup; never fails hard (CPU is always a valid fallback).
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path


def detect() -> dict:
    info = {"device": "cpu", "cuda": False, "gpu_name": None,
            "tensorrt": False, "source": "fallback"}

    # 1) torch (most reliable if installed)
    try:
        import torch
        if torch.cuda.is_available():
            info.update(device="cuda", cuda=True,
                        gpu_name=torch.cuda.get_device_name(0), source="torch")
            return info
    except Exception:
        pass

    # 2) nvidia-smi presence
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=8)
            name = out.stdout.strip().splitlines()[0] if out.stdout.strip() else "NVIDIA GPU"
            info.update(device="cuda", cuda=True, gpu_name=name, source="nvidia-smi")
        except Exception:
            pass
    return info


def main() -> int:
    home = Path(os.environ.get("SECURESIGHT_HOME", Path.home() / ".securesight"))
    home.mkdir(parents=True, exist_ok=True)
    info = detect()
    (home / "gpu.json").write_text(json.dumps(info, indent=2))
    print(f"[detect_gpu] device={info['device']} "
          f"gpu={info['gpu_name'] or '-'} (via {info['source']})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
