# Windows: build the offline desktop installer.
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$env:VITE_API_BASE = "http://127.0.0.1:8088"
Set-Location "$root\frontend-v2"; npm install; npm run build
Set-Location $PSScriptRoot; npm install; npm run dist
Write-Host "Installer in $root\dist-desktop"
