// First-run setup for the offline desktop app (item 22/23): create a Python
// virtualenv, install backend deps, initialize storage, detect GPU/CUDA. Idempotent:
// subsequent launches skip straight to starting the backend.
const { app } = require("electron");
const path = require("path");
const fs = require("fs");
const { spawnSync } = require("child_process");

// In a packaged build, bundled files live under process.resourcesPath; in dev they
// sit two levels up from desktop-v2/.
function resourcePath(rel) {
  const packaged = path.join(process.resourcesPath || "", rel);
  if (fs.existsSync(packaged)) return packaged;
  return path.join(__dirname, "..", rel);
}

function pythonCandidates() {
  return process.platform === "win32"
    ? ["python", "py"]
    : ["python3", "python"];
}

function venvPython(venvDir) {
  return process.platform === "win32"
    ? path.join(venvDir, "Scripts", "python.exe")
    : path.join(venvDir, "bin", "python");
}

function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { stdio: "inherit", ...opts });
  if (r.status !== 0) throw new Error(`${cmd} ${args.join(" ")} failed (${r.status})`);
}

async function ensureSetup(report = () => {}) {
  const userData = app.getPath("userData");
  const venvDir = path.join(userData, "venv");
  const py = venvPython(venvDir);
  const backendDir = resourcePath("backend-v2");

  if (!fs.existsSync(py)) {
    report({ label: "Creating Python environment", state: "checking" });
    const base = pythonCandidates().find((c) => spawnSync(c, ["--version"]).status === 0);
    if (!base) throw new Error("Python 3.10+ is required but was not found on PATH.");
    run(base, ["-m", "venv", venvDir]);
    report({ label: "Installing dependencies (first run only)", state: "checking" });
    run(py, ["-m", "pip", "install", "--upgrade", "pip"]);
    run(py, ["-m", "pip", "install", "-r", path.join(backendDir, "requirements.txt")]);
    report({ label: "Dependencies installed", state: "ok" });
  }

  // GPU / CUDA detection -> writes a small json the backend/UI can read.
  report({ label: "Detecting GPU / CUDA", state: "checking" });
  try {
    run(py, [resourcePath(path.join("desktop-v2", "installer", "detect_gpu.py"))],
        { stdio: "inherit", env: { ...process.env, SECURESIGHT_HOME: userData } });
  } catch { /* CPU fallback is fine */ }
  report({ label: "Ready", state: "ok" });

  return py;
}

module.exports = { ensureSetup, resourcePath };
