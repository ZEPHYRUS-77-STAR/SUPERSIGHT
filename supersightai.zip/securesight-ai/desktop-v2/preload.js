const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("securesight", {
  apiBase: "http://127.0.0.1:8088",
  offline: true,
  onStatus: (cb) => ipcRenderer.on("status", (_e, data) => cb(data)),
});
