# SecureSight AI — Offline Desktop App (v2)

An installable desktop application that runs the entire SecureSight AI v2 stack
**locally and offline**: the FastAPI backend on the **SQLite** fallback (no
Postgres, no internet), local OCR / PII / detection / redaction, CPU or GPU.

## How it works
- `main.js` shows a **startup splash** while it: runs first-run setup, launches the
  bundled backend (SQLite), and verifies services (`/api/health`, `/api/health/services`),
  then loads the built SPA. A tray icon keeps it running.
- `bootstrap.js` (first run only): creates a Python venv, installs
  `backend-v2/requirements.txt`, and runs GPU/CUDA detection. Subsequent launches
  skip straight to start.
- `installer/detect_gpu.py`: NVIDIA/CUDA detection → writes `gpu.json`; CPU fallback
  is automatic.

## Build the installer (one command)
```bash
# macOS / Linux
bash desktop-v2/build.sh
# Windows
powershell -ExecutionPolicy Bypass -File desktop-v2\build.ps1
```
Produces, in `dist-desktop/`:
- **Windows:** `SecureSight AI Setup.exe` (NSIS one-click wizard — installs deps,
  configures DB, creates desktop + start-menu shortcuts, GPU/CUDA auto-detect with
  CPU fallback, launches after install). **No terminal needed by end users.**
- **macOS:** `.dmg` · **Linux:** `.AppImage` / `.deb`.

## End-user workflow
1. Download the installer. 2. Double-click. 3. Finish the wizard. 4. SecureSight AI
launches — sign in (or register), upload/capture, scan, redact, share. Works with
no internet.

## Requirements on the user's machine
- Python 3.10+ (the installer prompts if missing).
- ~2–4 GB disk for the Python env; more if installing the optional ML models
  (`backend-v2/requirements-ml.txt`) for full GPU-accelerated detection.

## Notes
- Per-user install, no admin lock-in, fully uninstallable.
- All data stays on the device (SQLite + local `storage/`). Nothing is uploaded.
