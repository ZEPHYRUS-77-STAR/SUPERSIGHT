#!/usr/bin/env bash
# Build the offline desktop installer end-to-end.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"

echo "==> building frontend (API base = local backend)"
cd "$ROOT/frontend-v2"
VITE_API_BASE="http://127.0.0.1:8088" npm install
VITE_API_BASE="http://127.0.0.1:8088" npm run build

echo "==> packaging desktop installer"
cd "$HERE"
npm install
npm run dist            # -> dist-desktop/  (NSIS .exe / dmg / AppImage)
echo "==> done. Installer in $ROOT/dist-desktop"
