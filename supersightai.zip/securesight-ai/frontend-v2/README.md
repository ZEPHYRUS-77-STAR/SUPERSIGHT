# SecureSight AI — Frontend v2 (polished SPA)

React + TypeScript + Vite single-page app for the v2 platform. JWT auth, an
explainable-AI detection view, gallery with search, reports/PDF, and expiring
secure share links. Dark, professional, mobile-friendly.

## Run (dev)
```bash
cd frontend-v2
npm install
npm run dev            # http://127.0.0.1:5174  (proxies /api -> backend :8088)
```
Start the v2 backend first (`cd ../backend-v2 && uvicorn app.main:app --port 8088`).
Register an account, or sign in with the bootstrapped admin from the backend `.env`.

## Build
```bash
npm run build          # outputs frontend-v2/dist
npm run preview
```
Set `VITE_API_BASE` in `.env` to point at a remote API (otherwise the dev proxy
or same-origin `/api` is used).

## Structure
```
src/
├── main.tsx · App.tsx          router + providers (Auth, Toast)
├── api/client.ts               typed fetch client (JWT access/refresh, multipart)
├── auth/AuthContext.tsx        login/register/logout, current user
├── lib/types.ts                shared API types
├── components/
│   ├── Layout · ProtectedRoute · Dropzone · Toast
│   ├── RiskBadge · SourceChip  risk band + per-model source chips
│   ├── DetectionTable          explainable table (source, raw vs hybrid conf, risk +)
│   ├── DetectionOverlay        canvas bounding boxes colored by source
│   └── ShareDialog             kind + expiry → secure link + copy
└── pages/
    ├── LoginPage               sign in / register
    ├── ScanPage                upload → analyze → explainable results → redact → share
    ├── GalleryPage             categories + search (name/scan id/min risk), PDF, share
    └── SettingsPage            account + live engine/device status
```

## Explainable-AI view
Each detection shows object, **source** (YOLOv11 / YOLO-World / Grounding DINO /
Hybrid Verified) as a colored chip, a confidence bar (with raw-vs-hybrid for fused
detections), risk contribution, and a bounding box drawn on the image in the
source's colour.
