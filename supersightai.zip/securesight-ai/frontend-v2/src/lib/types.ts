export type Role = "admin" | "analyst" | "user";

export interface UserOut {
  id: string; email: string; full_name?: string | null; role: Role;
  is_active: boolean; created_at: string;
}
export interface Detection {
  category: string; label: string; box: [number, number, number, number];
  confidence: number; raw_confidence: number; hybrid_confidence?: number | null;
  source: "yolov11" | "yolo_world" | "grounding_dino" | "hybrid_verified";
  sources: string[]; risk_contribution: number; mask_area?: number | null;
}
export interface RiskOut {
  score: number; category: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  explanation: string; contributions: { category: string; weight: number }[];
}
export interface AnalyzeResponse {
  engine: any; detections: Detection[];
  ocr: { backend: string; text: string; word_count: number };
  pii: { category: string; type: string; text: string; severity: string }[];
  risk: RiskOut;
}
export interface ScanResponse {
  scan_id: string; risk_score: number; risk_category: string; decision: string;
  detections: Detection[]; risk: RiskOut;
}
export interface GalleryItem {
  id: string; filename: string; category: string;
  risk_score?: number | null; risk_category?: string | null; created_at: string;
}
export interface ShareOut {
  token: string; kind: string; expires_at: string | null; revoked: boolean; url?: string | null;
}
