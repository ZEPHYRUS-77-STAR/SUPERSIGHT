import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export function LoginPage() {
  const { login, register } = useAuth();
  const nav = useNavigate();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(null); setBusy(true);
    try {
      if (mode === "login") await login(email, password);
      else await register(email, password, name);
      nav("/");
    } catch (e) { setErr((e as Error).message); }
    finally { setBusy(false); }
  }

  return (
    <div className="center">
      <form className="card col" style={{ width: 380, maxWidth: "92vw" }} onSubmit={submit}>
        <div className="brand" style={{ fontSize: 20, justifyContent: "center" }}>🛡️ SecureSight AI</div>
        <p className="muted" style={{ textAlign: "center", marginTop: -4 }}>
          {mode === "login" ? "Sign in to your workspace" : "Create your account"}
        </p>
        {mode === "register" &&
          <input className="input" placeholder="Full name" value={name}
            onChange={(e) => setName(e.target.value)} />}
        <input className="input" type="email" placeholder="Email" value={email} required
          onChange={(e) => setEmail(e.target.value)} />
        <input className="input" type="password" placeholder="Password" value={password} required
          minLength={8} onChange={(e) => setPassword(e.target.value)} />
        {err && <div style={{ color: "var(--critical)" }}>{err}</div>}
        <button className="btn" disabled={busy}>{mode === "login" ? "Sign in" : "Create account"}</button>
        <button type="button" className="btn ghost"
          onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "Need an account? Register" : "Have an account? Sign in"}
        </button>
      </form>
    </div>
  );
}
