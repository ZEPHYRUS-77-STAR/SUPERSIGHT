import { useEffect, useState, useCallback } from "react";
import { api } from "../api/client";
import { RiskBadge } from "../components/RiskBadge";
import { ShareDialog } from "../components/ShareDialog";
import type { GalleryItem } from "../lib/types";

const CATS = ["all", "uploaded", "captured", "processed", "redacted", "reports"];

export function GalleryPage() {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [cat, setCat] = useState("all");
  const [q, setQ] = useState("");
  const [minRisk, setMinRisk] = useState("");
  const [share, setShare] = useState<string | null>(null);
  const [counts, setCounts] = useState<Record<string, number>>({});

  const load = useCallback(async () => {
    const params: Record<string, string> = {};
    if (cat !== "all") params.category = cat;
    if (q) params.q = q;
    if (minRisk) params.min_risk = minRisk;
    setItems(await api.gallery(params));
  }, [cat, q, minRisk]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { api.categories().then((c) =>
    setCounts(Object.fromEntries(c.map((x) => [x.category, x.count])))).catch(() => {}); }, []);

  async function pdf(id: string) {
    const blob = await api.reportPdf(id);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `report_${id}.pdf`; a.click();
  }

  return (
    <div className="col">
      <div className="row">
        {CATS.map((c) => (
          <button key={c} className={`btn ${cat === c ? "" : "ghost"} sm`} onClick={() => setCat(c)}>
            {c}{counts[c] != null ? ` (${counts[c]})` : ""}
          </button>
        ))}
      </div>
      <div className="row">
        <input className="input" style={{ maxWidth: 260 }} placeholder="Search name or scan id"
          value={q} onChange={(e) => setQ(e.target.value)} />
        <input className="input" style={{ maxWidth: 150 }} type="number" placeholder="Min risk"
          value={minRisk} onChange={(e) => setMinRisk(e.target.value)} />
      </div>

      {items.length === 0 && <div className="card muted">No items.</div>}
      <div className="grid gallery">
        {items.map((it) => (
          <div className="card tile col" key={it.id}>
            <div className="thumb">🖼️</div>
            <div style={{ fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {it.filename}
            </div>
            <div className="row" style={{ justifyContent: "space-between" }}>
              <RiskBadge category={it.risk_category} score={it.risk_score} />
              <span className="muted" style={{ fontSize: 11 }}>{it.category}</span>
            </div>
            <div className="muted" style={{ fontSize: 11 }}>{new Date(it.created_at).toLocaleString()}</div>
            <div className="row">
              <button className="btn ghost sm" onClick={() => pdf(it.id)}>PDF</button>
              <button className="btn ghost sm" onClick={() => setShare(it.id)}>Share</button>
            </div>
          </div>
        ))}
      </div>
      {share && <ShareDialog scanId={share} onClose={() => setShare(null)} />}
    </div>
  );
}
