import { useEffect, useState } from "react";
import { api } from "../api/client";
import { useAuth } from "../auth/AuthContext";

export function SettingsPage() {
  const { user } = useAuth();
  const [engine, setEngine] = useState<any>(null);
  useEffect(() => { api.engine().then(setEngine).catch(() => {}); }, []);
  return (
    <div className="col" style={{ maxWidth: 640 }}>
      <div className="card col">
        <strong>Account</strong>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <span className="muted">Email</span><span>{user?.email}</span>
        </div>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <span className="muted">Role</span><span className="chip">{user?.role}</span>
        </div>
      </div>
      <div className="card col">
        <strong>Detection engine</strong>
        {!engine && <span className="muted">Loading…</span>}
        {engine && (
          <>
            <div className="row" style={{ justifyContent: "space-between" }}>
              <span className="muted">Device</span>
              <span className="chip">{engine.device?.device}{engine.device?.gpu_name ? ` · ${engine.device.gpu_name}` : ""}</span>
            </div>
            <div className="row" style={{ flexWrap: "wrap" }}>
              {Object.entries(engine.detectors || {}).map(([k, v]) => (
                <span key={k} className="chip" style={{ color: v ? "var(--low)" : "var(--mut)" }}>
                  {k}: {v ? "on" : "off"}
                </span>
              ))}
              <span className="chip">SAM: {engine.segmentation}</span>
              <span className="chip">OCR: {engine.ocr}</span>
              <span className="chip">PII: {engine.pii}</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
