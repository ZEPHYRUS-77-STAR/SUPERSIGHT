import { useState } from "react";
import { api } from "../api/client";
import { Dropzone } from "../components/Dropzone";
import { DetectionOverlay } from "../components/DetectionOverlay";
import { DetectionTable } from "../components/DetectionTable";
import { RiskBadge } from "../components/RiskBadge";
import { ShareDialog } from "../components/ShareDialog";
import { useToast } from "../components/Toast";
import type { AnalyzeResponse } from "../lib/types";

const DECISION: Record<string, string> = {
  LOW: "ALLOW_UPLOAD", MEDIUM: "ALLOW_REDACTED_ONLY", HIGH: "BLOCK_UPLOAD", CRITICAL: "BLOCK_UPLOAD",
};

export function ScanPage() {
  const [file, setFile] = useState<File | null>(null);
  const [src, setSrc] = useState<string | null>(null);
  const [result, setResult] = useState<AnalyzeResponse | null>(null);
  const [scanId, setScanId] = useState<string | null>(null);
  const [redacted, setRedacted] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [share, setShare] = useState(false);
  const toast = useToast();

  function pick(f: File) {
    setFile(f); setResult(null); setScanId(null); setRedacted(null);
    setSrc(URL.createObjectURL(f));
  }
  async function analyze() {
    if (!file) return; setBusy(true);
    try {
      setResult(await api.detect(file));
      const s = await api.scan(file);  // persist to gallery
      setScanId(s.scan_id);
    } catch (e) { toast((e as Error).message); }
    finally { setBusy(false); }
  }
  async function redact() {
    if (!file) return; setBusy(true);
    try { setRedacted(URL.createObjectURL(await api.redactBlob(file, "blackbox"))); }
    catch (e) { toast((e as Error).message); }
    finally { setBusy(false); }
  }

  const risk = result?.risk;
  return (
    <div className="grid" style={{ gridTemplateColumns: "1fr 1fr", alignItems: "start" }}>
      <div className="col">
        {!src && <Dropzone onPick={pick} />}
        {src && <DetectionOverlay src={redacted || src} detections={redacted ? [] : (result?.detections || [])} />}
        <div className="row">
          {src && <button className="btn ghost sm" onClick={() => { setSrc(null); setFile(null); }}>Change</button>}
          <button className="btn" disabled={!file || busy} onClick={analyze}>{busy ? "Analyzing…" : "Analyze"}</button>
          {result && <button className="btn ghost" onClick={redact}>Redact (black-box)</button>}
          {scanId && <button className="btn ghost" onClick={() => setShare(true)}>Share</button>}
          {redacted && <a className="btn ghost" href={redacted} download="redacted.jpg">Download redacted</a>}
        </div>
      </div>

      <div className="col">
        {!result && <div className="card muted">Upload an image and click Analyze to run the hybrid detection engine.</div>}
        {risk && (
          <div className="card col">
            <div className="row" style={{ justifyContent: "space-between" }}>
              <strong>Risk assessment</strong>
              <RiskBadge category={risk.category} score={risk.score} />
            </div>
            <div className="muted">{risk.explanation}</div>
            <div className="row">
              <span className="chip">Decision: {DECISION[risk.category]}</span>
              {result?.engine?.device && <span className="chip">Device: {result.engine.device.device}</span>}
              <span className="chip">OCR: {result?.ocr.backend}</span>
            </div>
          </div>
        )}
        {result && (
          <div className="card">
            <strong>Explainable detections</strong>
            <DetectionTable detections={result.detections} />
          </div>
        )}
        {result && result.pii.length > 0 && (
          <div className="card">
            <strong>PII detected</strong>
            <div className="row" style={{ marginTop: 8 }}>
              {result.pii.map((p, i) => (
                <span key={i} className="chip">{p.category} · {p.severity}</span>
              ))}
            </div>
          </div>
        )}
      </div>
      {share && scanId && <ShareDialog scanId={scanId} onClose={() => setShare(false)} />}
    </div>
  );
}
