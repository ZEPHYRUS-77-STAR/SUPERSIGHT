const COLOR: Record<string, string> = {
  LOW: "var(--low)", MEDIUM: "var(--medium)", HIGH: "var(--high)", CRITICAL: "var(--critical)",
};
export function RiskBadge({ category, score }: { category?: string | null; score?: number | null }) {
  if (!category) return <span className="muted">—</span>;
  const c = COLOR[category] || "var(--mut)";
  return (
    <span className="pill" style={{ background: c, color: "#08111c" }}>
      {category}{score != null ? ` · ${score}` : ""}
    </span>
  );
}
