const LABEL: Record<string, string> = {
  yolov11: "YOLOv11", yolo_world: "YOLO-World",
  grounding_dino: "Grounding DINO", hybrid_verified: "Hybrid Verified",
};
export function SourceChip({ source }: { source: string }) {
  return (
    <span className="chip" style={{ borderColor: `var(--${source})`, color: `var(--${source})` }}>
      {LABEL[source] || source}
    </span>
  );
}
