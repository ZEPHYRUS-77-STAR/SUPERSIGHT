import { ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const link = ({ isActive }: { isActive: boolean }) => (isActive ? "active" : "");
  return (
    <div className="app">
      <nav className="nav">
        <span className="brand">🛡️ SecureSight AI</span>
        <NavLink to="/" className={link} end>Scan</NavLink>
        <NavLink to="/gallery" className={link}>Gallery</NavLink>
        <NavLink to="/settings" className={link}>Settings</NavLink>
        <span style={{ flex: 1 }} />
        <span className="muted" style={{ fontSize: 12 }}>{user?.email} · {user?.role}</span>
        <button className="btn ghost sm" onClick={() => { logout(); nav("/login"); }}>Logout</button>
      </nav>
      <div className="wrap">{children}</div>
    </div>
  );
}
