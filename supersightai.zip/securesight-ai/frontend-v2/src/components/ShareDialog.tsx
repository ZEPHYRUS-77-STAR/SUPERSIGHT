import { useState } from "react";
import { api } from "../api/client";
import { useToast } from "./Toast";

const KINDS = [
  { v: "image", label: "Original image" },
  { v: "redacted", label: "Redacted image" },
  { v: "report", label: "Full report" },
  { v: "risk_report", label: "Risk report" },
];
const EXPIRY = [
  { v: "1h", label: "1 hour" }, { v: "24h", label: "24 hours" },
  { v: "7d", label: "7 days" }, { v: "permanent", label: "Permanent" },
];

export function ShareDialog({ scanId, onClose }: { scanId: string; onClose: () => void }) {
  const [kind, setKind] = useState("redacted");
  const [expiry, setExpiry] = useState("24h");
  const [url, setUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const toast = useToast();

  async function create() {
    setBusy(true);
    try {
      const r = await api.createShare(scanId, kind, expiry);
      setUrl(r.url || r.token);
    } catch (e) { toast((e as Error).message); }
    finally { setBusy(false); }
  }
  function copy() { if (url) { navigator.clipboard.writeText(url); toast("Link copied"); } }

  return (
    <div className="center" style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 40 }}
      onClick={onClose}>
      <div className="card" style={{ width: 420, maxWidth: "92vw" }} onClick={(e) => e.stopPropagation()}>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <strong>Share</strong><button className="btn ghost sm" onClick={onClose}>✕</button>
        </div>
        <div className="col" style={{ marginTop: 12 }}>
          <label className="muted">What to share</label>
          <select value={kind} onChange={(e) => setKind(e.target.value)}>
            {KINDS.map((k) => <option key={k.v} value={k.v}>{k.label}</option>)}
          </select>
          <label className="muted">Link expires</label>
          <select value={expiry} onChange={(e) => setExpiry(e.target.value)}>
            {EXPIRY.map((x) => <option key={x.v} value={x.v}>{x.label}</option>)}
          </select>
          {!url
            ? <button className="btn" disabled={busy} onClick={create}>Generate secure link</button>
            : <div className="col">
                <input className="input" readOnly value={url} />
                <div className="row">
                  <button className="btn" onClick={copy}>Copy link</button>
                  <a className="btn ghost" href={url} target="_blank" rel="noreferrer">Open</a>
                </div>
              </div>}
        </div>
      </div>
    </div>
  );
}
