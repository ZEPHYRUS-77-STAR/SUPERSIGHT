import type { Detection } from "../lib/types";
import { SourceChip } from "./SourceChip";

// Explainable-AI table: object · source · raw vs hybrid confidence · risk contribution.
export function DetectionTable({ detections }: { detections: Detection[] }) {
  if (!detections.length) return <p className="muted">No sensitive objects detected.</p>;
  return (
    <table>
      <thead>
        <tr><th>Object</th><th>Source</th><th>Confidence</th><th>Risk +</th><th>Box</th></tr>
      </thead>
      <tbody>
        {detections.map((d, i) => (
          <tr key={i}>
            <td><strong>{d.category}</strong><div className="muted">{d.label}</div></td>
            <td><SourceChip source={d.source} /></td>
            <td style={{ minWidth: 140 }}>
              <div className="bar"><span style={{ width: `${Math.round(d.confidence * 100)}%` }} /></div>
              <div className="muted" style={{ fontSize: 11 }}>
                {(d.confidence * 100).toFixed(0)}%
                {d.hybrid_confidence != null && d.source === "hybrid_verified"
                  ? ` (raw ${(d.raw_confidence * 100).toFixed(0)}%)` : ""}
              </div>
            </td>
            <td>+{d.risk_contribution}</td>
            <td className="muted" style={{ fontSize: 11 }}>{d.box.join(", ")}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
