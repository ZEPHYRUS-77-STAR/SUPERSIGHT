import { useEffect, useRef } from "react";
import type { Detection } from "../lib/types";

const SRC_COLOR: Record<string, string> = {
  yolov11: "#7c3aed", yolo_world: "#0ea5e9",
  grounding_dino: "#10b981", hybrid_verified: "#f59e0b",
};

// Draws bounding boxes over the image, colored by detection source.
export function DetectionOverlay({ src, detections }: { src: string; detections: Detection[] }) {
  const imgRef = useRef<HTMLImageElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  function draw() {
    const img = imgRef.current, canvas = canvasRef.current;
    if (!img || !canvas) return;
    const sx = img.clientWidth / img.naturalWidth;
    const sy = img.clientHeight / img.naturalHeight;
    canvas.width = img.clientWidth; canvas.height = img.clientHeight;
    const ctx = canvas.getContext("2d"); if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = "12px Inter, sans-serif"; ctx.lineWidth = 2;
    detections.forEach((d) => {
      const [x, y, w, h] = d.box;
      const color = SRC_COLOR[d.source] || "#3b82f6";
      ctx.strokeStyle = color; ctx.fillStyle = color;
      ctx.strokeRect(x * sx, y * sy, w * sx, h * sy);
      const label = `${d.category} ${(d.confidence * 100).toFixed(0)}%`;
      ctx.globalAlpha = 0.85; ctx.fillRect(x * sx, y * sy - 16, ctx.measureText(label).width + 8, 16);
      ctx.globalAlpha = 1; ctx.fillStyle = "#08111c";
      ctx.fillText(label, x * sx + 4, y * sy - 4);
    });
  }

  useEffect(() => { draw(); /* eslint-disable-next-line */ }, [detections, src]);

  return (
    <div className="imgwrap">
      <img ref={imgRef} src={src} alt="scan" onLoad={draw} />
      <canvas ref={canvasRef} className="overlay" />
    </div>
  );
}
