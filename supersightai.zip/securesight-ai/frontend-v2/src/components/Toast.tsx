import { createContext, useContext, useState, ReactNode, useCallback } from "react";
const Ctx = createContext<(msg: string) => void>(() => {});
export const useToast = () => useContext(Ctx);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState<string | null>(null);
  const show = useCallback((m: string) => { setMsg(m); setTimeout(() => setMsg(null), 2600); }, []);
  return <Ctx.Provider value={show}>{children}{msg && <div className="toast">{msg}</div>}</Ctx.Provider>;
}
