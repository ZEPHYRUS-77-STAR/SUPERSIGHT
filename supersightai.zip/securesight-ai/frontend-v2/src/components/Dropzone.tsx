import { useRef } from "react";
export function Dropzone({ onPick, label = "Click or drop an image" }:
  { onPick: (f: File) => void; label?: string }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div className="card" style={{ borderStyle: "dashed", textAlign: "center", cursor: "pointer" }}
      onClick={() => ref.current?.click()}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) onPick(f); }}>
      <div style={{ fontSize: 28 }}>🛡️</div>
      <div className="muted">{label}</div>
      <input ref={ref} type="file" accept="image/*" hidden
        onChange={(e) => { const f = e.target.files?.[0]; if (f) onPick(f); }} />
    </div>
  );
}
