import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { api, tokens } from "../api/client";
import type { UserOut } from "../lib/types";

interface AuthState {
  user: UserOut | null; loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name?: string) => Promise<void>;
  logout: () => void;
}

const Ctx = createContext<AuthState>({} as AuthState);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserOut | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { setLoading(false); }, []);

  async function login(email: string, password: string) {
    await api.login(email, password);
    setUser(await api.me());
  }
  async function register(email: string, password: string, name?: string) {
    await api.register(email, password, name);
    await login(email, password);
  }
  function logout() { tokens.clear(); setUser(null); }

  return (
    <Ctx.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </Ctx.Provider>
  );
}
