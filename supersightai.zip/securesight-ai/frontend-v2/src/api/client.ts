// Typed v2 API client: JWT access/refresh, auto-retry on 401, multipart helpers.
import type {
  AnalyzeResponse, GalleryItem, ScanResponse, ShareOut, UserOut,
} from "../lib/types";

const BASE = import.meta.env.VITE_API_BASE || "";

let accessToken: string | null = null;
let refreshToken: string | null = null;

export const tokens = {
  set(a: string, r: string) { accessToken = a; refreshToken = r; },
  clear() { accessToken = null; refreshToken = null; },
  get access() { return accessToken; },
  get refresh() { return refreshToken; },
};

async function refresh(): Promise<boolean> {
  if (!refreshToken) return false;
  const r = await fetch(`${BASE}/api/auth/refresh`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });
  if (!r.ok) return false;
  const j = await r.json();
  accessToken = j.access_token; refreshToken = j.refresh_token;
  return true;
}

async function req<T>(path: string, init: RequestInit = {}, retry = true): Promise<T> {
  const headers = new Headers(init.headers);
  if (accessToken) headers.set("Authorization", `Bearer ${accessToken}`);
  const res = await fetch(`${BASE}${path}`, { ...init, headers });
  if (res.status === 401 && retry && (await refresh())) return req<T>(path, init, false);
  if (!res.ok) throw new Error((await res.json().catch(() => ({}))).detail || `HTTP ${res.status}`);
  const ct = res.headers.get("content-type") || "";
  return (ct.includes("application/json") ? res.json() : (res as unknown)) as Promise<T>;
}

async function reqBlob(path: string, init: RequestInit = {}): Promise<Blob> {
  const headers = new Headers(init.headers);
  if (accessToken) headers.set("Authorization", `Bearer ${accessToken}`);
  let res = await fetch(`${BASE}${path}`, { ...init, headers });
  if (res.status === 401 && (await refresh())) {
    headers.set("Authorization", `Bearer ${accessToken}`);
    res = await fetch(`${BASE}${path}`, { ...init, headers });
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.blob();
}

function fd(file: File, extra: Record<string, string> = {}) {
  const f = new FormData(); f.append("file", file);
  Object.entries(extra).forEach(([k, v]) => f.append(k, v));
  return f;
}

export const api = {
  async login(email: string, password: string) {
    const body = new URLSearchParams({ username: email, password });
    const r = await fetch(`${BASE}/api/auth/login`, { method: "POST", body });
    if (!r.ok) throw new Error("Invalid email or password");
    const j = await r.json(); tokens.set(j.access_token, j.refresh_token); return j;
  },
  register: (email: string, password: string, full_name?: string) =>
    req<UserOut>("/api/auth/register", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, full_name }),
    }),
  me: () => req<UserOut>("/api/auth/me"),
  engine: () => req<any>("/api/detect/engine"),
  detect: (file: File) => req<AnalyzeResponse>("/api/detect", { method: "POST", body: fd(file) }),
  scan: (file: File, category = "uploaded") =>
    req<ScanResponse>("/api/scan", { method: "POST", body: fd(file, { category }) }),
  redactBlob: (file: File, method = "blackbox") =>
    reqBlob("/api/redact", { method: "POST", body: fd(file, { method }) }),
  gallery: (params: Record<string, string> = {}) =>
    req<GalleryItem[]>(`/api/gallery?${new URLSearchParams(params)}`),
  categories: () => req<{ category: string; count: number }[]>("/api/gallery/categories"),
  report: (id: string) => req<any>(`/api/reports/${id}`),
  reportPdf: (id: string) => reqBlob(`/api/reports/${id}/pdf`),
  createShare: (scan_id: string, kind: string, expiry: string) =>
    req<ShareOut>("/api/share", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scan_id, kind, expiry }),
    }),
};
