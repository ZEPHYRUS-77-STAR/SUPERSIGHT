import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174,
    strictPort: true,
    proxy: {
      // dev convenience: proxy API to the v2 backend on :8088
      "/api": { target: "http://127.0.0.1:8088", changeOrigin: true },
    },
  },
  build: { outDir: "dist" },
});
