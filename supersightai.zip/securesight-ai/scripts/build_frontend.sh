#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE/frontend"
npm install
npm run build          # outputs frontend/dist
echo "[SecureSight] frontend built -> frontend/dist"
