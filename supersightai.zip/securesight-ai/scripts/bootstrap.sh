#!/usr/bin/env bash
# One-command setup for new team members.
# Creates the backend venv, installs core deps, runs the smoke test, and prints
# next steps. Optional flags: --optional (heavy AI deps), --frontend (npm install).
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
echo "==> SecureSight AI bootstrap"
cd "$HERE/backend"
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
pip install --upgrade pip >/dev/null
pip install -r requirements.txt
if [[ "${1:-}" == "--optional" || "${2:-}" == "--optional" ]]; then
  echo "==> installing optional AI models (large)…"
  pip install -r requirements-optional.txt || true
fi
echo "==> smoke test"
bash "$HERE/scripts/smoke_test.sh"
if [[ "${1:-}" == "--frontend" || "${2:-}" == "--frontend" ]]; then
  echo "==> frontend deps"; (cd "$HERE/frontend" && npm install)
fi
cat <<NOTE

✅ Backend ready.
Run the API:        cd backend && source .venv/bin/activate && python -m app.main
CLI scan:           python -m app.ai.pipeline image.jpg --out protected.jpg
Dashboard (dev):    cd frontend && npm install && npm run dev
Desktop app:        cd frontend && npm run build && cd electron && npm install && npm start
NOTE
