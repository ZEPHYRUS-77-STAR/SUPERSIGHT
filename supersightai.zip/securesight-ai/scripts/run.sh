#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE/backend"
[ -d .venv ] && source .venv/bin/activate || true
echo "[SecureSight] API → http://127.0.0.1:8077   Dashboard → frontend/index.html"
python -m app.main
