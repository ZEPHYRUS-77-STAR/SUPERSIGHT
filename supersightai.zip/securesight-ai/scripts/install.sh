#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE/backend"
echo "[SecureSight] creating venv…"
python3 -m venv .venv
source .venv/bin/activate
echo "[SecureSight] installing core deps…"
pip install --upgrade pip
pip install -r requirements.txt
echo "[SecureSight] (optional) heavy AI models: pip install -r requirements-optional.txt"
echo "[SecureSight] done. Run:  scripts/run.sh"
