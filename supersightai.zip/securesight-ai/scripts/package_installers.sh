#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE/frontend/electron"
case "$(uname -s)" in
  Linux*)  npx electron-builder --linux  --config "$HERE/installer/linux/appimage.yml" ;;
  Darwin*) npx electron-builder --mac ;;
  *)       npx electron-builder --win --config "$HERE/installer/windows/electron-builder.yml" ;;
esac
