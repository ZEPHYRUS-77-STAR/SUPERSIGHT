#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$HERE/backend"
[ -d .venv ] && source .venv/bin/activate || true
python -m py_compile $(find app -name '*.py')
python - <<'PY'
import numpy as np, cv2, tempfile, os
from app.ai.pipeline import Pipeline
img = np.full((300,500,3),245,np.uint8)
cv2.putText(img,"PAN ABCDE1234F",(20,150),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,0),2)
res = Pipeline.get().scan(img)
assert res.risk.value in {"low","medium","high","critical"}
print("smoke OK: risk =", res.risk.value, "regions =", len(res.detections))
PY
echo "[SecureSight] smoke test passed."
