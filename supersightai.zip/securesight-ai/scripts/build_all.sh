#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
bash "$HERE/scripts/smoke_test.sh"
bash "$HERE/scripts/build_frontend.sh"
bash "$HERE/scripts/build_desktop.sh"
echo "[SecureSight] full release build complete."
