#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
bash "$HERE/scripts/build_frontend.sh"
cd "$HERE/frontend/electron"
npm install
npx electron-builder --config "$HERE/installer/windows/electron-builder.yml"
echo "[SecureSight] desktop installer -> dist/"
