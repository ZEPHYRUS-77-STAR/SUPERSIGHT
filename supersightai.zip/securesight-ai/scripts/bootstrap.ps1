# One-command setup for Windows team members. Run in PowerShell:
#   powershell -ExecutionPolicy Bypass -File scripts\bootstrap.ps1
$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
Write-Host "==> SecureSight AI bootstrap (Windows)"
Set-Location "$root\backend"
python -m venv .venv
& "$root\backend\.venv\Scripts\python.exe" -m pip install --upgrade pip
& "$root\backend\.venv\Scripts\python.exe" -m pip install -r requirements.txt
Write-Host "✅ Backend ready."
Write-Host "Run API:   cd backend; .venv\Scripts\Activate.ps1; python -m app.main"
Write-Host "Dashboard: cd frontend; npm install; npm run dev"
