"""Train a YOLOv8 document/weapon detector from a prepared dataset.

Usage: python train_yolo.py path/to/data.yaml [epochs] [model_out.pt]
"""
from __future__ import annotations

import sys


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__); return 1
    data_yaml = sys.argv[1]
    epochs = int(sys.argv[2]) if len(sys.argv) > 2 else 80
    out = sys.argv[3] if len(sys.argv) > 3 else "yolov8-document.pt"
    from ultralytics import YOLO
    model = YOLO("yolov8n.pt")
    model.train(data=data_yaml, epochs=epochs, imgsz=640, batch=16,
                project="securesight_train", name="run")
    model.export()  # writes best weights under the run dir
    best = "securesight_train/run/weights/best.pt"
    import shutil
    shutil.copy(best, out)
    print(f"trained model -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
