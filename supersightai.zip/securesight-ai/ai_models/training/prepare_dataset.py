"""Convert Label Studio JSON-MIN export to YOLO format (images + label txts).

Usage: python prepare_dataset.py export.json images_dir out_dir
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

CLASSES = ["aadhaar", "pan", "passport", "driving_licence",
           "bank_document", "signature", "weapon", "document"]


def convert(export_json: str, images_dir: str, out_dir: str) -> None:
    out = Path(out_dir)
    (out / "images").mkdir(parents=True, exist_ok=True)
    (out / "labels").mkdir(parents=True, exist_ok=True)
    data = json.loads(Path(export_json).read_text())
    for task in data:
        img_name = Path(task["image"]).name
        src = Path(images_dir) / img_name
        if not src.exists():
            continue
        shutil.copy(src, out / "images" / img_name)
        lines = []
        for ann in task.get("label", []):
            cls = CLASSES.index(ann["rectanglelabels"][0])
            xc = (ann["x"] + ann["width"] / 2) / 100
            yc = (ann["y"] + ann["height"] / 2) / 100
            w = ann["width"] / 100
            h = ann["height"] / 100
            lines.append(f"{cls} {xc:.6f} {yc:.6f} {w:.6f} {h:.6f}")
        (out / "labels" / f"{src.stem}.txt").write_text("\n".join(lines))
    (out / "data.yaml").write_text(
        f"path: {out.resolve()}\ntrain: images\nval: images\n"
        f"names: {CLASSES}\n")
    print(f"wrote dataset to {out}")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print(__doc__); raise SystemExit(1)
    convert(*sys.argv[1:])
