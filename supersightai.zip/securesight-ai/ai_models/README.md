# AI model weights

SecureSight runs without these (OpenCV + OCR + regex path). Drop weights here to
activate the deep-learning detectors; the app auto-detects them via
`backend/app/ai/model_registry.py`.

| File | Detector | Source |
|------|----------|--------|
| `weights/yolov8n.pt` | general objects/persons | Ultralytics (auto-downloads on first use) |
| `weights/yolov8-document.pt` | ID/document regions | train with `training/train_yolo.py` |
| `weights/yolov8-weapon.pt` | weapons | train with `training/train_yolo.py` |
| `weights/sam_vit_b.pth` | precise masks (SAM) | Meta SAM release |

Run `python ai_models/download_models.py` to fetch the public base weights
(checksums verified). Custom document/weapon models must be trained — see
`training/`.
