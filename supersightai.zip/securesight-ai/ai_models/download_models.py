"""Fetch public base model weights into ai_models/weights with checksum checks.

Only downloads the freely-available base weights. Custom document/weapon models
are produced by the training scripts, not downloaded.
"""
from __future__ import annotations

import hashlib
import sys
import urllib.request
from pathlib import Path

WEIGHTS_DIR = Path(__file__).parent / "weights"

# name -> (url, sha256 or None to skip verification)
ARTIFACTS = {
    "yolov8n.pt": (
        "https://github.com/ultralytics/assets/releases/download/v8.2.0/yolov8n.pt",
        None,
    ),
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    WEIGHTS_DIR.mkdir(parents=True, exist_ok=True)
    for name, (url, expected) in ARTIFACTS.items():
        dest = WEIGHTS_DIR / name
        if dest.exists():
            print(f"[skip] {name} already present")
            continue
        print(f"[get ] {name} <- {url}")
        urllib.request.urlretrieve(url, dest)  # noqa: S310 (explicit, trusted host)
        if expected and sha256(dest) != expected:
            print(f"[FAIL] checksum mismatch for {name}", file=sys.stderr)
            dest.unlink(missing_ok=True)
            return 1
        print(f"[ok  ] {name}")
    print("done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
