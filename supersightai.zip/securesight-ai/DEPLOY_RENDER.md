# Get a public HTTPS link — deploy SecureSight AI to Render (free)

This deploys **one web service + a Postgres database** and gives you a public
`https://<name>.onrender.com` link. No servers to manage. ~15 minutes.

Everything is pre-wired: `deploy/cloud/render.yaml` (blueprint) +
`deploy/allinone.Dockerfile` (builds the React app and serves it together with the
API behind one URL, so there's no CORS or extra config).

## Step 1 — Put the code on GitHub
1. Create a new repo on github.com (e.g. `securesight-ai`).
2. Unzip the project, then from the `securesight-ai/` folder:
   ```bash
   git init && git add . && git commit -m "SecureSight AI"
   git branch -M main
   git remote add origin https://github.com/<you>/securesight-ai.git
   git push -u origin main
   ```

## Step 2 — Deploy on Render
1. Go to https://dashboard.render.com → sign up / log in (free).
2. Click **New +** → **Blueprint**.
3. **Connect** your GitHub and pick the `securesight-ai` repo.
4. Render reads `deploy/cloud/render.yaml` and shows: one **web service**
   (`securesight`) + one **Postgres** (`securesight-db`).
5. It will ask you to set **FIRST_ADMIN_PASSWORD** (the only secret you choose).
   Pick a strong password — this is your login.
6. Click **Apply**. Render builds the Docker image (5–10 min the first time).

## Step 3 — Open your link
- When the service goes **Live**, your URL is at the top:
  `https://securesight.onrender.com` (the exact name may have a random suffix).
- Open it → you'll see the SecureSight AI login.
- Log in with `admin@securesight.local` + the password you set (or click Register).

## What works on the free tier
- Full app: auth, upload, **hybrid-detection pipeline in fallback mode**
  (OpenCV + Tesseract OCR + regex PII + bbox masks), risk scoring, black-box
  redaction, gallery, reports, share links.
- The heavy GPU models (YOLOv11 / YOLO-World / Grounding DINO / SAM 2) are **not**
  installed on the free tier (no GPU, limited RAM). To enable them later, deploy the
  image with `requirements-ml.txt` on a GPU host (RunPod, Render GPU, your own box).

## If a build fails
Copy the red error text from Render's **Logs** tab and send it to me — first deploys
often need 1–2 small fixes, and I'll patch them immediately. Common ones are already
handled (opencv/numpy deps, Postgres URL scheme, CORS, frontend build).

## Free-tier note
Free Render services sleep after ~15 min idle and take ~30s to wake on the next
visit. Fine for demos/sharing; upgrade the service to keep it always-on.
