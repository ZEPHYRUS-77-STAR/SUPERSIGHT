"""Engine + session factory. Picks Postgres or the SQLite fallback from settings."""
from __future__ import annotations

from collections.abc import Iterator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from ..core.config import settings

_connect_args = {"check_same_thread": False} if settings.is_sqlite else {}
engine = create_engine(settings.sqlalchemy_url, pool_pre_ping=True,
                       connect_args=_connect_args, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False,
                            class_=Session, expire_on_commit=False)


def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
