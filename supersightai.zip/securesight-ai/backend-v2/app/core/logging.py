"""Loguru-based application logging.

Logs to stderr + a rotating file. Security-relevant events go through
`log_security_event` so they are consistently tagged for auditing.
"""
from __future__ import annotations

import sys
from pathlib import Path

from loguru import logger

_CONFIGURED = False


def configure_logging() -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    logger.remove()
    logger.add(sys.stderr, level="INFO",
               format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
                      "<level>{level: <8}</level> | {message}")
    log_dir = Path(__file__).resolve().parents[2] / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logger.add(log_dir / "securesight.log", rotation="10 MB", retention="14 days",
               level="INFO", enqueue=True)
    _CONFIGURED = True


def log_security_event(event: str, **fields) -> None:
    logger.bind(security=True).info("SECURITY {} {}", event, fields)


__all__ = ["logger", "configure_logging", "log_security_event"]
