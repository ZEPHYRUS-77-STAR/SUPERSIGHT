"""Shared FastAPI dependencies: DB session, current user, and RBAC guards."""
from __future__ import annotations

from collections.abc import Callable

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from ..db.session import get_db
from ..models.user import User, UserRole
from .security import decode_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

_CREDENTIALS_EXC = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Could not validate credentials",
    headers={"WWW-Authenticate": "Bearer"},
)


def get_current_user(token: str = Depends(oauth2_scheme),
                     db: Session = Depends(get_db)) -> User:
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            raise _CREDENTIALS_EXC
        user_id = payload.get("sub")
    except jwt.PyJWTError:
        raise _CREDENTIALS_EXC
    user = db.get(User, user_id)
    if user is None or not user.is_active:
        raise _CREDENTIALS_EXC
    return user


def require_role(*allowed: UserRole) -> Callable[[User], User]:
    """Dependency factory enforcing that the current user has one of `allowed` roles.

    ADMIN always passes. Usage: Depends(require_role(UserRole.ANALYST, UserRole.ADMIN))
    """
    def _guard(user: User = Depends(get_current_user)) -> User:
        if user.role == UserRole.ADMIN or user.role in allowed:
            return user
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="Insufficient role")
    return _guard
