"""Application configuration via pydantic-settings (env-driven).

PostgreSQL is used in production; if DATABASE_URL is empty we fall back to a local
SQLite file so the backend still runs offline / in dev with zero infra.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="", extra="ignore")

    env: str = Field("development", alias="SECURESIGHT_ENV")
    app_name: str = "SecureSight AI v2"
    app_version: str = "2.0.0"

    database_url: str = Field("", alias="DATABASE_URL")

    jwt_secret: str = Field("change-me", alias="JWT_SECRET")
    jwt_algorithm: str = Field("HS256", alias="JWT_ALGORITHM")
    access_token_expire_minutes: int = Field(30, alias="ACCESS_TOKEN_EXPIRE_MINUTES")
    refresh_token_expire_days: int = Field(7, alias="REFRESH_TOKEN_EXPIRE_DAYS")

    redis_url: str = Field("redis://localhost:6379/0", alias="REDIS_URL")

    first_admin_email: str = Field("admin@securesight.local", alias="FIRST_ADMIN_EMAIL")
    first_admin_password: str = Field("ChangeMe123!", alias="FIRST_ADMIN_PASSWORD")

    @property
    def sqlalchemy_url(self) -> str:
        if self.database_url:
            url = self.database_url
            # Normalize managed-Postgres schemes (Render/Heroku give postgres://)
            if url.startswith("postgres://"):
                url = "postgresql+psycopg2://" + url[len("postgres://"):]
            elif url.startswith("postgresql://"):
                url = "postgresql+psycopg2://" + url[len("postgresql://"):]
            return url
        # offline/dev fallback — local SQLite next to the package
        db_path = Path(__file__).resolve().parents[2] / "securesight_v2.db"
        return f"sqlite:///{db_path}"

    @property
    def is_sqlite(self) -> bool:
        return self.sqlalchemy_url.startswith("sqlite")


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
