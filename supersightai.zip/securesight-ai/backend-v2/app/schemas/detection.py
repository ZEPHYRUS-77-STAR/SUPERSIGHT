"""Detection / explainable-result schemas."""
from __future__ import annotations

from pydantic import BaseModel


class DetectionOut(BaseModel):
    category: str
    label: str
    box: list[int]
    confidence: float
    raw_confidence: float
    hybrid_confidence: float | None = None
    source: str
    sources: list[str]
    risk_contribution: int
    mask_area: int | None = None


class RiskOut(BaseModel):
    score: int
    category: str
    explanation: str
    contributions: list[dict]


class AnalyzeResponse(BaseModel):
    engine: dict
    detections: list[DetectionOut]
    ocr: dict
    pii: list[dict]
    risk: RiskOut


class ScanResponse(BaseModel):
    scan_id: str
    risk_score: int
    risk_category: str
    decision: str
    detections: list[DetectionOut]
    risk: RiskOut
