"""Share schemas."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ShareCreate(BaseModel):
    scan_id: str
    kind: str = "image"          # image | redacted | report | risk_report
    expiry: str = "24h"          # 1h | 24h | 7d | permanent


class ShareOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    token: str
    kind: str
    expires_at: datetime | None = None
    revoked: bool = False
    url: str | None = None
