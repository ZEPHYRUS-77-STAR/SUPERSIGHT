"""Scan schemas (used from Phase 2 onward; defined now for stable contracts)."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict

from ..models.scan import ScanStatus


class ScanOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    filename: str
    category: str
    status: ScanStatus
    risk_score: int | None = None
    risk_category: str | None = None
    created_at: datetime
