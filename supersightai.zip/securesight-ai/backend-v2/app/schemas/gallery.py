"""Gallery schemas."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict


class GalleryItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    filename: str
    category: str
    risk_score: int | None = None
    risk_category: str | None = None
    created_at: datetime


class CategoryCount(BaseModel):
    category: str
    count: int
