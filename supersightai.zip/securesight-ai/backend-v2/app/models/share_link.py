"""Temporary secure share links for gallery items and reports."""
from __future__ import annotations

import enum
import uuid

from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship
from datetime import datetime

from ..db.base import Base, TimestampMixin


class ShareKind(str, enum.Enum):
    IMAGE = "image"            # original uploaded image
    REDACTED = "redacted"      # sanitized version (regenerated on access)
    REPORT = "report"          # full security report (JSON)
    RISK_REPORT = "risk_report"  # risk summary only (JSON)


def _uuid() -> str:
    return str(uuid.uuid4())


class ShareLink(Base, TimestampMixin):
    __tablename__ = "share_links"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    token: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    scan_id: Mapped[str] = mapped_column(ForeignKey("scans.id"), index=True, nullable=False)
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    kind: Mapped[ShareKind] = mapped_column(Enum(ShareKind), default=ShareKind.IMAGE)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))  # None = permanent
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)

    scan: Mapped["Scan"] = relationship()
