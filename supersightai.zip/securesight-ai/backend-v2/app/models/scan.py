"""A single image/document scan and its lifecycle."""
from __future__ import annotations

import enum
import uuid

from sqlalchemy import Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..db.base import Base, TimestampMixin


class ScanStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


def _uuid() -> str:
    return str(uuid.uuid4())


class Scan(Base, TimestampMixin):
    __tablename__ = "scans"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True, nullable=False)
    filename: Mapped[str] = mapped_column(String(512), nullable=False)
    content_type: Mapped[str | None] = mapped_column(String(128))
    storage_path: Mapped[str | None] = mapped_column(String(1024))  # encrypted at rest
    category: Mapped[str] = mapped_column(String(32), default="uploaded")  # uploaded|captured|processed|redacted
    status: Mapped[ScanStatus] = mapped_column(Enum(ScanStatus), default=ScanStatus.PENDING)
    risk_score: Mapped[int | None] = mapped_column(Integer)
    risk_category: Mapped[str | None] = mapped_column(String(16))
    detections_json: Mapped[str | None] = mapped_column(Text)  # serialized detection summary

    owner: Mapped["User"] = relationship(back_populates="scans")
    report: Mapped["Report | None"] = relationship(back_populates="scan",
                                                   uselist=False, cascade="all, delete-orphan")
    risk_assessment: Mapped["RiskAssessment | None"] = relationship(
        back_populates="scan", uselist=False, cascade="all, delete-orphan")
