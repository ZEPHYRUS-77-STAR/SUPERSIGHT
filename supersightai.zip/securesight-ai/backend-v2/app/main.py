"""SecureSight AI v2 — FastAPI application (clean architecture).

Single-service deploy: serves the JSON API under /api AND the built React SPA at /
(when FRONTEND_DIR is set), so the whole app lives behind one URL with no CORS or
cross-service URL guessing. PostgreSQL in prod, SQLite fallback offline.
"""
from __future__ import annotations

import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .api.router import api_router
from .core.config import settings
from .core.logging import configure_logging, logger
from .db.base import Base
from .db.session import SessionLocal, engine
from .services.user_service import ensure_first_admin


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()
    if settings.is_sqlite:
        Base.metadata.create_all(bind=engine)   # dev/offline convenience
    with SessionLocal() as db:
        ensure_first_admin(db, settings.first_admin_email, settings.first_admin_password)
    logger.info("{} v{} started ({})", settings.app_name, settings.app_version,
                "sqlite" if settings.is_sqlite else "postgresql")
    yield
    logger.info("shutting down")


app = FastAPI(title=settings.app_name, version=settings.app_version, lifespan=lifespan)

# CORS — permissive by default for a single-service deploy; lock down with
# SECURESIGHT_CORS_ORIGINS="https://a.com,https://b.com" when splitting origins.
_origins = os.environ.get("SECURESIGHT_CORS_ORIGINS", "*")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if _origins.strip() == "*" else [o.strip() for o in _origins.split(",")],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")


@app.get("/api")
def api_root():
    return {"app": settings.app_name, "version": settings.app_version, "docs": "/docs"}


# ---- serve the built SPA (single-URL deploy) ----
_FRONTEND_DIR = os.environ.get("FRONTEND_DIR", "")
_dist = Path(_FRONTEND_DIR) if _FRONTEND_DIR else None
if _dist and _dist.exists():
    _assets = _dist / "assets"
    if _assets.exists():
        app.mount("/assets", StaticFiles(directory=str(_assets)), name="assets")

    @app.get("/{full_path:path}")
    def spa(full_path: str):
        # API + docs are matched by their routes above; everything else is the SPA.
        candidate = _dist / full_path
        if full_path and candidate.is_file():
            return FileResponse(str(candidate))
        return FileResponse(str(_dist / "index.html"))
else:
    @app.get("/")
    def root():
        return {"app": settings.app_name, "version": settings.app_version,
                "docs": "/docs", "api": "/api", "note": "frontend not bundled"}
