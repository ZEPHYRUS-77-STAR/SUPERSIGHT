"""Share Functionality — temporary secure links with expiry.

Generates an unguessable URL-safe token bound to a scan + share kind + owner.
Expiry options: 1h · 24h · 7d · permanent. Links can be revoked. Resolution
checks revocation + expiry before granting access. Ownership is validated on
creation (you can only share your own scans).
"""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models.scan import Scan
from ..models.share_link import ShareLink, ShareKind

EXPIRY_SECONDS: dict[str, int | None] = {
    "1h": 3600, "24h": 86400, "7d": 604800, "permanent": None,
}


class ShareError(Exception):
    pass


def create_link(db: Session, owner_id: str, scan_id: str, kind: str,
                expiry: str) -> ShareLink:
    scan = db.get(Scan, scan_id)
    if scan is None or scan.owner_id != owner_id:
        raise ShareError("scan not found or not owned by you")
    if kind not in {k.value for k in ShareKind}:
        raise ShareError(f"invalid kind: {kind}")
    if expiry not in EXPIRY_SECONDS:
        raise ShareError(f"invalid expiry: {expiry}")

    seconds = EXPIRY_SECONDS[expiry]
    expires_at = (datetime.now(timezone.utc) + timedelta(seconds=seconds)
                  if seconds is not None else None)
    link = ShareLink(token=secrets.token_urlsafe(24), scan_id=scan_id,
                     owner_id=owner_id, kind=ShareKind(kind), expires_at=expires_at)
    db.add(link)
    db.commit()
    db.refresh(link)
    return link


def resolve(db: Session, token: str) -> ShareLink | None:
    link = db.scalar(select(ShareLink).where(ShareLink.token == token))
    if link is None or link.revoked:
        return None
    if link.expires_at is not None:
        exp = link.expires_at
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) >= exp:
            return None
    return link


def revoke(db: Session, owner_id: str, token: str) -> bool:
    link = db.scalar(select(ShareLink).where(ShareLink.token == token))
    if link is None or link.owner_id != owner_id:
        return False
    link.revoked = True
    db.commit()
    return True


def list_for_owner(db: Session, owner_id: str) -> list[ShareLink]:
    return list(db.scalars(select(ShareLink).where(ShareLink.owner_id == owner_id)
                           .order_by(ShareLink.created_at.desc())))
