"""User persistence/business logic, separated from the API layer."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..core.security import hash_password
from ..models.user import User, UserRole


def get_by_email(db: Session, email: str) -> User | None:
    return db.scalar(select(User).where(User.email == email))


def create_user(db: Session, email: str, password: str,
                full_name: str | None = None,
                role: UserRole = UserRole.USER) -> User:
    user = User(email=email, full_name=full_name,
                hashed_password=hash_password(password), role=role)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def list_users(db: Session) -> list[User]:
    return list(db.scalars(select(User).order_by(User.created_at.desc())))


def set_role(db: Session, user: User, role: UserRole) -> User:
    user.role = role
    db.commit()
    db.refresh(user)
    return user


def ensure_first_admin(db: Session, email: str, password: str) -> None:
    """Bootstrap an admin account if the users table is empty."""
    if db.scalar(select(User).limit(1)) is None:
        create_user(db, email, password, full_name="Administrator",
                    role=UserRole.ADMIN)
