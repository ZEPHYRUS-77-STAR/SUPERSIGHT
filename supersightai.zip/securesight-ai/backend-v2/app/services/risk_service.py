"""Risk Assessment Engine (4-band, additive) for the v2 platform.

Each detected category contributes a weight; the score is the sum of distinct
category contributions, capped at 100. Bands:
    0-20 LOW · 21-50 MEDIUM · 51-80 HIGH · 81-100 CRITICAL

Returns an explainable breakdown (per-category contribution) for the dashboard.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..vision.types import Detection

WEIGHTS: dict[str, int] = {
    "military_document": 50, "firearm": 50, "weapon": 45,
    "passport": 40, "aadhaar": 35, "government_document": 35,
    "pan": 30, "driving_licence": 30, "bank_document": 30, "medical_document": 30,
    "signature": 25, "face": 20, "employee_id": 20, "monitor": 20,
    "mobile_phone": 15, "document": 10, "laptop": 10, "qr_code": 10, "barcode": 10,
    # PII text categories (from OCR/Presidio)
    "name": 10, "address": 10, "email": 5, "phone": 5,
}


@dataclass
class RiskResult:
    score: int
    category: str
    explanation: str
    contributions: list[dict]

    def to_dict(self) -> dict:
        return {"score": self.score, "category": self.category,
                "explanation": self.explanation, "contributions": self.contributions}


def classify(score: int) -> str:
    if score >= 81:
        return "CRITICAL"
    if score >= 51:
        return "HIGH"
    if score >= 21:
        return "MEDIUM"
    return "LOW"


def weight_for(category: str) -> int:
    return WEIGHTS.get(category, 0)


def assess(detections: list[Detection],
           pii_entities: list[dict] | None = None) -> RiskResult:
    # distinct category -> max single contribution (avoid double counting dupes)
    per_cat: dict[str, int] = {}
    for d in detections:
        w = weight_for(d.category)
        d.risk_contribution = w
        if w:
            per_cat[d.category] = max(per_cat.get(d.category, 0), w)
    for e in pii_entities or []:
        cat = e.get("category", "")
        w = weight_for(cat)
        if w:
            per_cat[cat] = max(per_cat.get(cat, 0), w)

    score = min(100, sum(per_cat.values()))
    category = classify(score)
    contributions = [{"category": c, "weight": w}
                     for c, w in sorted(per_cat.items(), key=lambda kv: -kv[1])]
    if contributions:
        top = ", ".join(f"{c['category']} (+{c['weight']})" for c in contributions[:4])
        explanation = f"{category} risk ({score}/100). Top contributors: {top}."
    else:
        explanation = "LOW risk (0/100). No sensitive content detected."
    return RiskResult(score, category, explanation, contributions)
