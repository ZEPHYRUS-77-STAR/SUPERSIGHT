"""PII Detection Engine — Microsoft Presidio when available, regex fallback.

Returns entities with a severity level (LOW/MEDIUM/HIGH/CRITICAL) and a mapped
risk category so the risk engine can weight them.
"""
from __future__ import annotations

import re

_SEVERITY = {
    "aadhaar": "CRITICAL", "pan": "CRITICAL", "passport": "CRITICAL",
    "bank_document": "HIGH", "phone": "MEDIUM", "name": "MEDIUM",
    "address": "MEDIUM", "email": "LOW",
}

# regex fallback patterns
_PATTERNS = {
    "aadhaar": re.compile(r"\b(\d{4}\s?\d{4}\s?\d{4})\b"),
    "pan": re.compile(r"\b([A-Z]{5}\d{4}[A-Z])\b"),
    "passport": re.compile(r"\b([A-PR-WYa-pr-wy][1-9]\d\s?\d{4}[1-9])\b"),
    "email": re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"),
    "phone": re.compile(r"(?<!\d)(?:\+?91[\-\s]?)?[6-9]\d{9}(?!\d)"),
}
# Presidio entity type -> our category
_PRESIDIO_MAP = {
    "IN_AADHAAR": "aadhaar", "IN_PAN": "pan", "IN_PASSPORT": "passport",
    "EMAIL_ADDRESS": "email", "PHONE_NUMBER": "phone", "PERSON": "name",
    "LOCATION": "address", "IN_VEHICLE_REGISTRATION": "driving_licence",
}


class PiiService:
    def __init__(self):
        self._analyzer = None
        try:
            from presidio_analyzer import AnalyzerEngine
            self._analyzer = AnalyzerEngine()
        except Exception:
            self._analyzer = None

    @property
    def backend(self) -> str:
        return "presidio" if self._analyzer else "regex"

    def analyze(self, text: str) -> list[dict]:
        if not text:
            return []
        return self._presidio(text) if self._analyzer else self._regex(text)

    def _presidio(self, text: str) -> list[dict]:
        results = self._analyzer.analyze(text=text, language="en")
        out = []
        for r in results:
            cat = _PRESIDIO_MAP.get(r.entity_type)
            if cat is None:
                continue
            out.append({"category": cat, "type": r.entity_type,
                        "text": text[r.start:r.end], "score": float(r.score),
                        "severity": _SEVERITY.get(cat, "LOW")})
        return out

    def _regex(self, text: str) -> list[dict]:
        out = []
        for cat, pat in _PATTERNS.items():
            for m in pat.finditer(text):
                out.append({"category": cat, "type": cat.upper(),
                            "text": m.group(0), "score": 0.8,
                            "severity": _SEVERITY.get(cat, "LOW")})
        return out
