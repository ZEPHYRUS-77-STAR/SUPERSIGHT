"""Persist hybrid-detection results to the DB (Scan + RiskAssessment).

Stores the uploaded image to a per-user local storage dir (encryption-at-rest +
cloud storage arrive in Phase 3). No raw PII text is written to the Scan row —
only the structured detection/risk summary.
"""
from __future__ import annotations

import json
import uuid
from pathlib import Path

from sqlalchemy.orm import Session

from ..models.scan import Scan, ScanStatus
from ..models.risk_assessment import RiskAssessment
from ..core.config import settings

_STORAGE = Path(__file__).resolve().parents[2] / "storage"


def _save_bytes(owner_id: str, filename: str, data: bytes) -> str:
    d = _STORAGE / owner_id
    d.mkdir(parents=True, exist_ok=True)
    safe = f"{uuid.uuid4().hex}_{Path(filename).name}"
    path = d / safe
    path.write_bytes(data)
    return str(path)


def persist_scan(db: Session, owner_id: str, filename: str, content_type: str | None,
                 image_bytes: bytes, result: dict, category: str = "uploaded") -> Scan:
    storage_path = _save_bytes(owner_id, filename, image_bytes)
    risk = result["risk"]
    scan = Scan(
        owner_id=owner_id, filename=filename, content_type=content_type,
        storage_path=storage_path, category=category, status=ScanStatus.COMPLETED,
        risk_score=risk["score"], risk_category=risk["category"],
        detections_json=json.dumps({"detections": result["detections"],
                                    "pii": result["pii"],
                                    "ocr_backend": result["ocr"]["backend"]}),
    )
    db.add(scan)
    db.flush()  # get scan.id
    db.add(RiskAssessment(
        scan_id=scan.id, score=risk["score"], category=risk["category"],
        explanation=risk["explanation"],
        contributions_json=json.dumps(risk["contributions"]),
    ))
    db.commit()
    db.refresh(scan)
    return scan
