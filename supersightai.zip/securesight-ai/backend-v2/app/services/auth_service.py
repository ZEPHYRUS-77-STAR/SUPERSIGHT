"""Authentication logic: registration, credential verification, token issuance."""
from __future__ import annotations

from sqlalchemy.orm import Session

from ..core.security import create_access_token, create_refresh_token, verify_password
from ..models.user import User, UserRole
from . import user_service


class AuthError(Exception):
    pass


def register(db: Session, email: str, password: str, full_name: str | None) -> User:
    if user_service.get_by_email(db, email):
        raise AuthError("email already registered")
    return user_service.create_user(db, email, password, full_name, UserRole.USER)


def authenticate(db: Session, email: str, password: str) -> User:
    user = user_service.get_by_email(db, email)
    if user is None or not verify_password(password, user.hashed_password):
        raise AuthError("invalid email or password")
    if not user.is_active:
        raise AuthError("account disabled")
    return user


def issue_tokens(user: User) -> dict[str, str]:
    return {
        "access_token": create_access_token(user.id, user.role.value),
        "refresh_token": create_refresh_token(user.id, user.role.value),
        "token_type": "bearer",
    }
