"""Hybrid Detection Pipeline — the SecureSight AI v2 detection orchestrator.

Flow:
  image -> [YOLOv11, YOLO-World, Grounding DINO] -> Fusion -> SAM 2 masks
        -> OCR -> PII (Presidio) -> Risk assessment -> explainable result.

All heavy models are optional; the pipeline degrades gracefully (Tesseract OCR +
regex PII + bbox masks) so it always returns a result.
"""
from __future__ import annotations

import numpy as np

from ..vision.detectors.yolov11 import YoloV11Detector
from ..vision.detectors.yolo_world import YoloWorldDetector
from ..vision.detectors.grounding_dino import GroundingDinoDetector
from ..vision.fusion import DetectionFusionEngine
from ..vision.segmentation_sam2 import Sam2Segmenter
from ..vision.device import device_info
from ..vision.types import Detection
from . import risk_service
from .ocr_service import OcrService
from .pii_service import PiiService
from .redaction_service import RedactionService


class HybridDetectionPipeline:
    _instance: "HybridDetectionPipeline | None" = None

    def __init__(self):
        self.yolov11 = YoloV11Detector()
        self.yolo_world = YoloWorldDetector()
        self.grounding_dino = GroundingDinoDetector()
        self.fusion = DetectionFusionEngine()
        self.sam2 = Sam2Segmenter()
        self.ocr = OcrService()
        self.pii = PiiService()
        self.redactor = RedactionService()

    @classmethod
    def get(cls) -> "HybridDetectionPipeline":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def engine_status(self) -> dict:
        return {
            "device": device_info(),
            "detectors": {
                "yolov11": self.yolov11.available,
                "yolo_world": self.yolo_world.available,
                "grounding_dino": self.grounding_dino.available,
            },
            "segmentation": "sam2" if self.sam2.available else "bbox_fallback",
            "ocr": self.ocr.backend,
            "pii": self.pii.backend,
        }

    def analyze(self, image: np.ndarray) -> dict:
        # Stage 1+1b+2: run all available detectors
        d11 = self.yolov11.detect(image)
        dyw = self.yolo_world.detect(image)
        dgd = self.grounding_dino.detect(image)

        # Fusion: merge, hybrid confidence, source attribution
        fused: list[Detection] = self.fusion.fuse(d11, dyw, dgd)

        # SAM 2 precise masks (adds mask_area)
        fused = self.sam2.segment(image, fused)

        # OCR + PII
        ocr = self.ocr.read(image)
        pii_entities = self.pii.analyze(ocr["text"])

        # Risk assessment (objects + PII) — sets per-detection risk_contribution
        risk = risk_service.assess(fused, pii_entities)

        return {
            "engine": self.engine_status(),
            "detections": [d.to_dict() for d in fused],
            "ocr": {"backend": ocr["backend"], "text": ocr["text"],
                    "word_count": len(ocr["words"])},
            "pii": pii_entities,
            "risk": risk.to_dict(),
            "_detections": fused,   # internal handle for redaction (not serialized out)
        }

    def redact(self, image: np.ndarray, detections: list[Detection], *,
               method: str = "blackbox", categories: set[str] | None = None) -> np.ndarray:
        out, _ = self.redactor.redact(image, detections, method=method, categories=categories)
        return out
