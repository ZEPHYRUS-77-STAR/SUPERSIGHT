"""Audit logging service — writes immutable security events to the DB + Loguru."""
from __future__ import annotations

import json

from sqlalchemy.orm import Session

from ..core.logging import log_security_event
from ..models.audit_log import AuditLog


def record(db: Session, event: str, user_id: str | None = None,
           ip: str | None = None, **detail) -> AuditLog:
    entry = AuditLog(user_id=user_id, event=event, ip_address=ip,
                     detail=json.dumps(detail) if detail else None)
    db.add(entry)
    db.commit()
    db.refresh(entry)
    log_security_event(event, user_id=user_id, ip=ip, **detail)
    return entry
