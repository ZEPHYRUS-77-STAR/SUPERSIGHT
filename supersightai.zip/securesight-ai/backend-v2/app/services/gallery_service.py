"""Personal Gallery — query/search a user's scans.

Categories: uploaded · captured · processed · redacted · reports.
Search by: filename, scan id, risk score range, date range.
Ownership is always enforced (a user only sees their own scans).
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models.scan import Scan
from ..models.report import Report

CATEGORIES = ["uploaded", "captured", "processed", "redacted", "reports"]


def query(db: Session, owner_id: str, *, category: str | None = None,
          q: str | None = None, min_risk: int | None = None,
          max_risk: int | None = None, date_from: datetime | None = None,
          date_to: datetime | None = None, limit: int = 100,
          offset: int = 0) -> list[Scan]:
    stmt = select(Scan).where(Scan.owner_id == owner_id)

    if category == "reports":
        stmt = stmt.join(Report, Report.scan_id == Scan.id)
    elif category in CATEGORIES:
        stmt = stmt.where(Scan.category == category)

    if q:
        like = f"%{q}%"
        stmt = stmt.where((Scan.filename.ilike(like)) | (Scan.id == q))
    if min_risk is not None:
        stmt = stmt.where(Scan.risk_score >= min_risk)
    if max_risk is not None:
        stmt = stmt.where(Scan.risk_score <= max_risk)
    if date_from is not None:
        stmt = stmt.where(Scan.created_at >= date_from)
    if date_to is not None:
        stmt = stmt.where(Scan.created_at <= date_to)

    stmt = stmt.order_by(Scan.created_at.desc()).limit(limit).offset(offset)
    return list(db.scalars(stmt))


def get_owned(db: Session, owner_id: str, scan_id: str) -> Scan | None:
    scan = db.get(Scan, scan_id)
    if scan is None or scan.owner_id != owner_id:
        return None
    return scan
