"""OCR Engine — PaddleOCR primary, Tesseract fallback. Returns text + boxes."""
from __future__ import annotations

import numpy as np


class OcrService:
    def __init__(self):
        self._paddle = None
        self._tess = None
        try:
            from paddleocr import PaddleOCR
            self._paddle = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)
        except Exception:
            self._paddle = None
        try:
            import pytesseract  # noqa
            self._tess = pytesseract
        except Exception:
            self._tess = None

    @property
    def backend(self) -> str:
        return "paddleocr" if self._paddle else ("tesseract" if self._tess else "none")

    def read(self, image: np.ndarray) -> dict:
        words = self._read_words(image)
        return {"backend": self.backend,
                "text": " ".join(w["text"] for w in words),
                "words": words}

    def _read_words(self, image) -> list[dict]:
        if self._paddle is not None:
            out = []
            for page in self._paddle.ocr(image, cls=True) or []:
                for line in page or []:
                    box, (text, conf) = line
                    xs = [p[0] for p in box]; ys = [p[1] for p in box]
                    out.append({"text": text, "confidence": float(conf),
                                "box": [int(min(xs)), int(min(ys)),
                                        int(max(xs) - min(xs)), int(max(ys) - min(ys))]})
            return out
        if self._tess is not None:
            import cv2
            from pytesseract import Output
            data = self._tess.image_to_data(cv2.cvtColor(image, cv2.COLOR_BGR2GRAY),
                                            output_type=Output.DICT)
            out = []
            for i, t in enumerate(data["text"]):
                if not t.strip():
                    continue
                conf = float(data["conf"][i]) / 100.0 if data["conf"][i] not in ("-1", -1) else 0.0
                out.append({"text": t, "confidence": conf,
                            "box": [data["left"][i], data["top"][i],
                                    data["width"][i], data["height"][i]]})
            return out
        return []
