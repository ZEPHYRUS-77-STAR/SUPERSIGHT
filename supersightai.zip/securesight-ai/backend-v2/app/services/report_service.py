"""Security Report Generator — JSON always, PDF via reportlab when available.

Builds a structured report from a completed Scan (+ its RiskAssessment) and
persists a Report row. The JSON report is the source of truth; the PDF is a
rendered view of the same data.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy.orm import Session

from ..models.scan import Scan
from ..models.report import Report

_REPORT_DIR = Path(__file__).resolve().parents[2] / "storage" / "reports"


def build_json(scan: Scan) -> dict:
    detail = json.loads(scan.detections_json) if scan.detections_json else {}
    detections = detail.get("detections", [])
    pii = detail.get("pii", [])
    ra = scan.risk_assessment
    sensitive_regions = [
        {"category": d["category"], "source": d.get("source"),
         "confidence": d.get("confidence"), "box": d.get("box"),
         "risk_contribution": d.get("risk_contribution", 0)}
        for d in detections if d.get("risk_contribution", 0) > 0
    ]
    return {
        "scan_id": scan.id,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "filename": scan.filename,
        "category": scan.category,
        "risk": {
            "score": scan.risk_score,
            "category": scan.risk_category,
            "explanation": ra.explanation if ra else None,
            "contributions": json.loads(ra.contributions_json) if ra and ra.contributions_json else [],
        },
        "detected_entities": detections,
        "pii_entities": pii,
        "sensitive_regions": sensitive_regions,
        "redaction_summary": {
            "regions_redactable": len(sensitive_regions),
            "categories": sorted({r["category"] for r in sensitive_regions}),
            "methods_available": ["blackbox", "blur", "pixelate"],
        },
        "ocr_backend": detail.get("ocr_backend"),
    }


def render_pdf(report: dict, out_path: Path) -> Path:
    """Render the JSON report to a PDF. Requires reportlab."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.lib import colors
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                    TableStyle)
    from reportlab.lib.styles import getSampleStyleSheet

    out_path.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(out_path), pagesize=A4,
                            title=f"SecureSight Report {report['scan_id']}")
    risk = report["risk"]
    band_color = {"CRITICAL": colors.red, "HIGH": colors.orangered,
                  "MEDIUM": colors.orange, "LOW": colors.green}.get(
                      risk.get("category"), colors.grey)

    story = [
        Paragraph("SecureSight AI — Security Report", styles["Title"]),
        Paragraph(f"Scan ID: {report['scan_id']}", styles["Normal"]),
        Paragraph(f"Generated: {report['generated_at']}", styles["Normal"]),
        Paragraph(f"File: {report['filename']}", styles["Normal"]),
        Spacer(1, 6 * mm),
        Paragraph(f"<b>Risk Score: {risk['score']}/100 "
                  f"(<font color='{band_color}'>{risk['category']}</font>)</b>",
                  styles["Heading2"]),
        Paragraph(risk.get("explanation") or "", styles["Normal"]),
        Spacer(1, 4 * mm),
        Paragraph("Detected Entities", styles["Heading3"]),
    ]
    rows = [["Category", "Source", "Confidence", "Risk +"]]
    for d in report["detected_entities"]:
        rows.append([d.get("category"), d.get("source"),
                     f"{d.get('confidence', 0):.2f}", str(d.get("risk_contribution", 0))])
    if len(rows) == 1:
        rows.append(["(none)", "", "", ""])
    table = Table(rows, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f6fe0")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
    ]))
    story += [table, Spacer(1, 4 * mm),
              Paragraph("Redaction Summary", styles["Heading3"]),
              Paragraph(f"{report['redaction_summary']['regions_redactable']} sensitive "
                        f"region(s): {', '.join(report['redaction_summary']['categories']) or 'none'}",
                        styles["Normal"])]
    doc.build(story)
    return out_path


def create_report(db: Session, scan: Scan, with_pdf: bool = True) -> Report:
    summary = build_json(scan)
    pdf_path = None
    if with_pdf:
        try:
            p = _REPORT_DIR / f"{scan.id}.pdf"
            render_pdf(summary, p)
            pdf_path = str(p)
        except Exception:
            pdf_path = None  # reportlab unavailable -> JSON-only report
    report = scan.report or Report(scan_id=scan.id, summary_json="")
    report.summary_json = json.dumps(summary)
    report.pdf_path = pdf_path
    db.add(report)
    db.commit()
    db.refresh(report)
    return report
