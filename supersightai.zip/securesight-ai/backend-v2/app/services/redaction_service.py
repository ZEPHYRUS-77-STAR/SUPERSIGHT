"""Redaction Engine (OpenCV): gaussian blur, pixelation, black-box.

Black-box is permanent (solid fill). Blur/pixelate are reversible-resistant but
softer. Uses SAM 2 masks when available so redaction hugs the object; otherwise
fills the (padded) bounding box. Returns the sanitized image + which regions were
redacted.
"""
from __future__ import annotations

import cv2
import numpy as np

from ..vision.types import Detection
from ..vision.segmentation_sam2 import Sam2Segmenter


def _pad(box, frac, shape):
    x, y, w, h = box
    px, py = int(w * frac), int(h * frac)
    H, W = shape[:2]
    nx, ny = max(0, x - px), max(0, y - py)
    return nx, ny, min(W - nx, w + 2 * px), min(H - ny, h + 2 * py)


def _blur_patch(patch, method, strength):
    if patch.size == 0:
        return patch
    if method == "pixelate":
        h, w = patch.shape[:2]
        blocks = max(1, strength)
        small = cv2.resize(patch, (max(1, w // blocks), max(1, h // blocks)),
                           interpolation=cv2.INTER_LINEAR)
        return cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)
    if method == "blackbox":
        return np.zeros_like(patch)
    k = strength if strength % 2 == 1 else strength + 1
    return cv2.GaussianBlur(patch, (k, k), 0)


class RedactionService:
    def __init__(self):
        self._seg = Sam2Segmenter()

    def redact(self, image: np.ndarray, detections: list[Detection], *,
               method: str = "blackbox", strength: int = 35, pad_frac: float = 0.05,
               categories: set[str] | None = None,
               use_mask: bool = True) -> tuple[np.ndarray, list[str]]:
        out = image.copy()
        done: list[str] = []
        for d in detections:
            if categories is not None and d.category not in categories:
                continue
            x, y, w, h = _pad(d.box, pad_frac, image.shape)
            if w <= 0 or h <= 0:
                continue
            roi = out[y:y + h, x:x + w]
            patch = _blur_patch(roi, method, strength)
            if use_mask and self._seg.available:
                mask = self._seg.mask_for_box(image, (x, y, w, h))[y:y + h, x:x + w]
                m3 = np.repeat(mask[:, :, None], 3, axis=2)
                out[y:y + h, x:x + w] = np.where(m3, patch, roi)
            else:
                out[y:y + h, x:x + w] = patch
            done.append(d.category)
        return out, sorted(set(done))

    def annotate(self, image: np.ndarray, detections: list[Detection]) -> np.ndarray:
        colors = {"LOW": (120, 200, 120), "MEDIUM": (60, 180, 255),
                  "HIGH": (40, 90, 240), "CRITICAL": (40, 40, 220)}
        out = image.copy()
        for d in detections:
            x, y, w, h = d.box
            cv2.rectangle(out, (x, y), (x + w, y + h), (40, 90, 240), 2)
            cv2.putText(out, f"{d.category} {d.confidence:.2f} [{d.source.value}]",
                        (x, max(12, y - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                        (40, 90, 240), 1, cv2.LINE_AA)
        return out
