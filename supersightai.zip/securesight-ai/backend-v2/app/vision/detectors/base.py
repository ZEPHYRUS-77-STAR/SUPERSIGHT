"""Detector interface. All detectors are optional and fail-safe (return [])."""
from __future__ import annotations

from typing import Protocol, runtime_checkable

import numpy as np

from ..types import Detection


@runtime_checkable
class Detector(Protocol):
    name: str

    @property
    def available(self) -> bool: ...

    def detect(self, image: np.ndarray) -> list[Detection]: ...
