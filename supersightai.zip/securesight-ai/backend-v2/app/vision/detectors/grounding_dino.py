"""Grounding DINO open-vocabulary detector — Stage 2 intelligence/validation.

Backends tried in order: HuggingFace Transformers, then standalone groundingdino.
Optional & offline-capable once weights are cached.
"""
from __future__ import annotations

import numpy as np

from ..types import Detection, Source
from ..device import device
from .. import prompts

_CAPTION = " . ".join(prompts.all_prompts()) + " ."


class GroundingDinoDetector:
    name = "grounding_dino"

    def __init__(self, box_threshold: float = 0.30, text_threshold: float = 0.25,
                 hf_model: str = "IDEA-Research/grounding-dino-tiny"):
        self.box_threshold = box_threshold
        self.text_threshold = text_threshold
        self._backend = None
        try:
            import torch  # noqa
            from transformers import AutoProcessor, AutoModelForZeroShotObjectDetection
            self._proc = AutoProcessor.from_pretrained(hf_model)
            self._model = AutoModelForZeroShotObjectDetection.from_pretrained(hf_model)
            self._torch = torch
            self._device = device()
            self._model.to(self._device)
            self._backend = "transformers"
        except Exception:
            self._backend = None

    @property
    def available(self) -> bool:
        return self._backend is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._backend != "transformers":
            return []
        import cv2
        from PIL import Image
        pil = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        inputs = self._proc(images=pil, text=_CAPTION, return_tensors="pt").to(self._device)
        with self._torch.no_grad():
            outputs = self._model(**inputs)
        res = self._proc.post_process_grounded_object_detection(
            outputs, inputs.input_ids, box_threshold=self.box_threshold,
            text_threshold=self.text_threshold, target_sizes=[pil.size[::-1]])[0]
        out: list[Detection] = []
        for score, label, box in zip(res["scores"], res["labels"], res["boxes"]):
            category = prompts.category_for(str(label))
            if category is None:
                continue
            x1, y1, x2, y2 = (int(v) for v in box.tolist())
            out.append(Detection(category=category, label=str(label),
                                 box=(x1, y1, x2 - x1, y2 - y1),
                                 raw_confidence=float(score),
                                 source=Source.GROUNDING_DINO, sources=[self.name]))
        return out
