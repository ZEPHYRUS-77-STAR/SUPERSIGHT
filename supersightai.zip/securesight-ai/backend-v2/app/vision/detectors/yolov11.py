"""YOLOv11 fixed-class detector (Ultralytics) — Stage 1 fast localization.

Maps the COCO/extended classes we care about to SecureSight categories. Optional:
activates only when `ultralytics` + a YOLO11 weight are present; CPU or CUDA.
"""
from __future__ import annotations

import numpy as np

from ..types import Detection, Source
from ..device import device
from ...core.config import settings  # noqa: F401 (kept for future model-path config)

# COCO label -> SecureSight category (subset relevant to privacy).
_LABEL_MAP = {
    "person": "face",            # person presence treated as face-risk proxy
    "cell phone": "mobile_phone",
    "laptop": "laptop",
    "tv": "monitor",
    "book": "document",
}


class YoloV11Detector:
    name = "yolov11"

    def __init__(self, weights: str = "yolo11n.pt", min_conf: float = 0.30):
        self.min_conf = min_conf
        self._model = None
        try:
            from ultralytics import YOLO
            self._model = YOLO(weights)
            self._device = device()
        except Exception:
            self._model = None

    @property
    def available(self) -> bool:
        return self._model is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._model is None:
            return []
        out: list[Detection] = []
        try:
            results = self._model.predict(image, conf=self.min_conf, verbose=False,
                                          device=getattr(self, "_device", None))
        except Exception:
            return []
        for r in results:
            names = r.names
            for b in r.boxes:
                label = str(names.get(int(b.cls[0]), "")).lower()
                category = _LABEL_MAP.get(label)
                if category is None:
                    continue
                x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
                out.append(Detection(category=category, label=label,
                                     box=(x1, y1, x2 - x1, y2 - y1),
                                     raw_confidence=float(b.conf[0]),
                                     source=Source.YOLOV11, sources=[self.name]))
        return out
