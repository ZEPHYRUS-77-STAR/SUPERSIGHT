"""YOLO-World open-vocabulary detector — fast, prompt-driven (Stage 1b)."""
from __future__ import annotations

import numpy as np

from ..types import Detection, Source
from ..device import device
from .. import prompts


class YoloWorldDetector:
    name = "yolo_world"

    def __init__(self, weights: str = "yolov8s-worldv2.pt", min_conf: float = 0.10):
        self.min_conf = min_conf
        self._model = None
        self._prompts = prompts.all_prompts()
        try:
            from ultralytics import YOLOWorld
            self._model = YOLOWorld(weights)
            self._model.set_classes(self._prompts)
            self._device = device()
        except Exception:
            self._model = None

    @property
    def available(self) -> bool:
        return self._model is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._model is None:
            return []
        out: list[Detection] = []
        try:
            results = self._model.predict(image, conf=self.min_conf, verbose=False,
                                          device=getattr(self, "_device", None))
        except Exception:
            return []
        for r in results:
            names = r.names
            for b in r.boxes:
                label = str(names.get(int(b.cls[0]), "")).lower()
                category = prompts.category_for(label)
                if category is None:
                    continue
                x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
                out.append(Detection(category=category, label=label,
                                     box=(x1, y1, x2 - x1, y2 - y1),
                                     raw_confidence=float(b.conf[0]),
                                     source=Source.YOLO_WORLD, sources=[self.name]))
        return out
