"""SAM 2 segmentation — precise pixel masks for detected regions.

Turns each detection's bounding box into a tight mask for accurate redaction.
Optional: uses `sam2` when installed (CUDA/CPU); otherwise returns a rectangular
box-mask fallback so redaction still works.
"""
from __future__ import annotations

import numpy as np

from .types import Detection
from .device import device


class Sam2Segmenter:
    name = "sam2"

    def __init__(self, checkpoint: str | None = None,
                 model_cfg: str = "sam2_hiera_s.yaml"):
        self._predictor = None
        try:
            import torch  # noqa
            from sam2.build_sam import build_sam2
            from sam2.sam2_image_predictor import SAM2ImagePredictor
            if checkpoint:
                model = build_sam2(model_cfg, checkpoint, device=device())
                self._predictor = SAM2ImagePredictor(model)
        except Exception:
            self._predictor = None

    @property
    def available(self) -> bool:
        return self._predictor is not None

    def mask_for_box(self, image: np.ndarray, box: tuple[int, int, int, int]) -> np.ndarray:
        h, w = image.shape[:2]
        x, y, bw, bh = box
        if self._predictor is None:
            mask = np.zeros((h, w), dtype=bool)
            mask[max(0, y):min(h, y + bh), max(0, x):min(w, x + bw)] = True
            return mask
        self._predictor.set_image(image[:, :, ::-1])  # BGR->RGB
        masks, scores, _ = self._predictor.predict(
            box=np.array([x, y, x + bw, y + bh])[None, :], multimask_output=False)
        return masks[0].astype(bool)

    def segment(self, image: np.ndarray, detections: list[Detection]) -> list[Detection]:
        """Attach mask_area to each detection (mask itself kept transient)."""
        for d in detections:
            mask = self.mask_for_box(image, d.box)
            d.mask_area = int(mask.sum())
        return detections
