"""Open-vocabulary prompts (YOLO-World / Grounding DINO) -> risk category map.

Single source of truth so all detectors and the risk engine agree on categories.
"""
from __future__ import annotations

CATEGORY_PROMPTS: dict[str, list[str]] = {
    "military_document": ["a military document", "a defense document", "a classified document"],
    "government_document": ["a government document", "an official government form"],
    "passport": ["a passport"],
    "aadhaar": ["an aadhaar card"],
    "pan": ["a pan card"],
    "driving_licence": ["a driving license", "a driving licence"],
    "bank_document": ["a bank statement", "a financial statement", "a cheque",
                      "a credit card", "a debit card"],
    "employee_id": ["an employee id card", "an identity card", "a student id card"],
    "signature": ["a handwritten signature"],
    "medical_document": ["a medical record", "a medical document", "a prescription"],
    "firearm": ["a gun", "a handgun", "a rifle", "a firearm"],
    "weapon": ["a knife", "a weapon"],
    "qr_code": ["a qr code"],
    "barcode": ["a barcode"],
    "mobile_phone": ["a mobile phone", "a smartphone"],
    "laptop": ["a laptop"],
    "monitor": ["a computer monitor", "a screen displaying sensitive data"],
    "document": ["a document", "a printed paper"],
    "face": ["a human face"],
}


def all_prompts() -> list[str]:
    return [p for ps in CATEGORY_PROMPTS.values() for p in ps]


def _lookup() -> dict[str, str]:
    out: dict[str, str] = {}
    for cat, ps in CATEGORY_PROMPTS.items():
        for p in ps:
            key = p.lower()
            out[key] = cat
            for art in ("a ", "an ", "the "):
                if key.startswith(art):
                    out[key[len(art):]] = cat
    return out


_LK = _lookup()


def category_for(text: str) -> str | None:
    key = text.strip().lower().rstrip(".")
    if key in _LK:
        return _LK[key]
    for phrase, cat in _LK.items():
        if phrase in key or key in phrase:
            return cat
    return None
