"""Compute-device selection: NVIDIA GPU/CUDA when available, else CPU fallback."""
from __future__ import annotations

from functools import lru_cache


@lru_cache
def device_info() -> dict:
    info = {"device": "cpu", "cuda": False, "gpu_name": None, "torch": None}
    try:
        import torch
        info["torch"] = torch.__version__
        if torch.cuda.is_available():
            info["device"] = "cuda"
            info["cuda"] = True
            info["gpu_name"] = torch.cuda.get_device_name(0)
    except Exception:
        pass
    return info


def device() -> str:
    return device_info()["device"]
