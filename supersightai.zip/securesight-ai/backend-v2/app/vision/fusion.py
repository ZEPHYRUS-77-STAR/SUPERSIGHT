"""Detection Fusion Engine — combines YOLOv11 + YOLO-World + Grounding DINO.

Rules (per spec):
  1. Same object detected by multiple models  -> merge; raise confidence; mark
     source = hybrid_verified, list all contributing models.
  2. Detected by only one model               -> keep as single-source.
  3. Always preserve source attribution.

Hybrid confidence uses a probabilistic OR (noisy-or) of the per-model confidences:
    hybrid = 1 - Π(1 - c_i)
so two independent detectors at 0.82 and 0.88 yield ~0.978 — strictly higher than
either alone, capped at 0.99. "Same object" = same category AND IoU >= threshold.
"""
from __future__ import annotations

from .types import Detection, Source


def _iou(a, b) -> float:
    ax, ay, aw, ah = a; bx, by, bw, bh = b
    x1, y1 = max(ax, bx), max(ay, by)
    x2, y2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    inter = max(0, x2 - x1) * max(0, y2 - y1)
    union = aw * ah + bw * bh - inter
    return inter / union if union else 0.0


def _merge_box(a, b):
    # confidence-agnostic union box (tightest box covering both)
    ax, ay, aw, ah = a; bx, by, bw, bh = b
    x1, y1 = min(ax, bx), min(ay, by)
    x2, y2 = max(ax + aw, bx + bw), max(ay + ah, by + bh)
    return (x1, y1, x2 - x1, y2 - y1)


def _noisy_or(confs: list[float]) -> float:
    prod = 1.0
    for c in confs:
        prod *= (1.0 - max(0.0, min(1.0, c)))
    return min(0.99, 1.0 - prod)


class DetectionFusionEngine:
    def __init__(self, iou_threshold: float = 0.5):
        self.iou_threshold = iou_threshold

    def fuse(self, *detection_lists: list[Detection]) -> list[Detection]:
        all_dets: list[Detection] = [d for lst in detection_lists for d in lst]
        clusters: list[list[Detection]] = []

        for det in sorted(all_dets, key=lambda d: -d.raw_confidence):
            placed = False
            for cluster in clusters:
                head = cluster[0]
                if head.category == det.category and _iou(head.box, det.box) >= self.iou_threshold:
                    cluster.append(det)
                    placed = True
                    break
            if not placed:
                clusters.append([det])

        fused: list[Detection] = []
        for cluster in clusters:
            fused.append(self._collapse(cluster))
        return fused

    def _collapse(self, cluster: list[Detection]) -> Detection:
        primary = max(cluster, key=lambda d: d.raw_confidence)
        sources = sorted({s for d in cluster for s in (d.sources or [d.source.value])})
        confs = [d.raw_confidence for d in cluster]

        if len(cluster) == 1:
            # single-source: keep original source + confidence
            primary.hybrid_confidence = primary.raw_confidence
            primary.sources = sources
            return primary

        # multi-source: merge box, raise confidence, mark hybrid_verified
        box = primary.box
        for d in cluster:
            box = _merge_box(box, d.box)
        primary.box = box
        primary.hybrid_confidence = _noisy_or(confs)
        primary.source = Source.HYBRID_VERIFIED
        primary.sources = sources
        primary.meta = {**primary.meta, "merged_count": len(cluster),
                        "member_confidences": [round(c, 3) for c in confs]}
        return primary
