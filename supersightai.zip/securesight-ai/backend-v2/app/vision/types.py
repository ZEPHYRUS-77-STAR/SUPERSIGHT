"""Detection types for the hybrid engine (explainable-AI ready)."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class Source(str, Enum):
    YOLOV11 = "yolov11"
    YOLO_WORLD = "yolo_world"
    GROUNDING_DINO = "grounding_dino"
    HYBRID_VERIFIED = "hybrid_verified"


@dataclass
class Detection:
    category: str                      # SecureSight risk category (e.g. "passport")
    label: str                         # raw model label / prompt
    box: tuple[int, int, int, int]     # x, y, w, h (absolute px)
    raw_confidence: float              # confidence from the originating model
    source: Source = Source.YOLOV11
    hybrid_confidence: float | None = None   # set by the fusion engine
    risk_contribution: int = 0         # weight this detection adds to the score
    sources: list[str] = field(default_factory=list)  # all contributing models
    mask_area: int | None = None       # px area of SAM 2 mask, if segmented
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def confidence(self) -> float:
        return self.hybrid_confidence if self.hybrid_confidence is not None else self.raw_confidence

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["source"] = self.source.value
        d["confidence"] = round(self.confidence, 4)
        d["raw_confidence"] = round(self.raw_confidence, 4)
        if self.hybrid_confidence is not None:
            d["hybrid_confidence"] = round(self.hybrid_confidence, 4)
        return d
