"""Personal gallery endpoints (owner-scoped) with search + categories."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from ...core.deps import get_current_user
from ...db.session import get_db
from ...models.user import User
from ...schemas.gallery import GalleryItem
from ...services import gallery_service

router = APIRouter(prefix="/gallery", tags=["gallery"])


@router.get("", response_model=list[GalleryItem])
def list_items(db: Session = Depends(get_db), user: User = Depends(get_current_user),
               category: str | None = None, q: str | None = None,
               min_risk: int | None = Query(None, ge=0, le=100),
               max_risk: int | None = Query(None, ge=0, le=100),
               date_from: datetime | None = None, date_to: datetime | None = None,
               limit: int = Query(100, le=500), offset: int = 0):
    return gallery_service.query(db, user.id, category=category, q=q,
                                 min_risk=min_risk, max_risk=max_risk,
                                 date_from=date_from, date_to=date_to,
                                 limit=limit, offset=offset)


@router.get("/categories")
def categories(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    out = []
    for cat in gallery_service.CATEGORIES:
        out.append({"category": cat,
                    "count": len(gallery_service.query(db, user.id, category=cat, limit=500))})
    return out


@router.get("/{scan_id}", response_model=GalleryItem)
def detail(scan_id: str, db: Session = Depends(get_db),
           user: User = Depends(get_current_user)):
    scan = gallery_service.get_owned(db, user.id, scan_id)
    if scan is None:
        raise HTTPException(status_code=404, detail="not found")
    return scan


@router.get("/{scan_id}/image")
def image(scan_id: str, db: Session = Depends(get_db),
          user: User = Depends(get_current_user)):
    scan = gallery_service.get_owned(db, user.id, scan_id)
    if scan is None or not scan.storage_path or not Path(scan.storage_path).exists():
        raise HTTPException(status_code=404, detail="image not found")
    return FileResponse(scan.storage_path)
