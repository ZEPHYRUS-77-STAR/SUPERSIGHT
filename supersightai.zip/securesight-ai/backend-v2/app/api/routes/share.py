"""Share endpoints. Create/list/revoke require auth; token resolution is PUBLIC.

The public endpoint `/api/s/{token}` returns the shared artifact (image, redacted
image, full report, or risk report) only if the link is valid (not revoked, not
expired). Tokens are unguessable; ownership is enforced at creation.
"""
from __future__ import annotations

import io
import json
from pathlib import Path

import cv2
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy.orm import Session

from ...core.deps import get_current_user
from ...db.session import get_db
from ...models.user import User
from ...models.share_link import ShareKind
from ...schemas.share import ShareCreate, ShareOut
from ...services import share_service, report_service

router = APIRouter(tags=["share"])


def _public_url(request: Request, token: str) -> str:
    base = str(request.base_url).rstrip("/")
    return f"{base}/api/s/{token}"


@router.post("/share", response_model=ShareOut)
def create_share(body: ShareCreate, request: Request, db: Session = Depends(get_db),
                 user: User = Depends(get_current_user)):
    try:
        link = share_service.create_link(db, user.id, body.scan_id, body.kind, body.expiry)
    except share_service.ShareError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return ShareOut(token=link.token, kind=link.kind.value, expires_at=link.expires_at,
                    revoked=link.revoked, url=_public_url(request, link.token))


@router.get("/share", response_model=list[ShareOut])
def list_shares(request: Request, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)):
    return [ShareOut(token=l.token, kind=l.kind.value, expires_at=l.expires_at,
                     revoked=l.revoked, url=_public_url(request, l.token))
            for l in share_service.list_for_owner(db, user.id)]


@router.delete("/share/{token}")
def revoke_share(token: str, db: Session = Depends(get_db),
                 user: User = Depends(get_current_user)):
    if not share_service.revoke(db, user.id, token):
        raise HTTPException(status_code=404, detail="link not found")
    return {"revoked": True, "token": token}


@router.get("/s/{token}")
def resolve_share(token: str, db: Session = Depends(get_db)):
    """PUBLIC — no auth. Serves the shared artifact if the link is valid."""
    link = share_service.resolve(db, token)
    if link is None:
        raise HTTPException(status_code=404, detail="link expired, revoked, or not found")
    scan = link.scan
    if scan is None:
        raise HTTPException(status_code=404, detail="content unavailable")

    if link.kind in (ShareKind.REPORT, ShareKind.RISK_REPORT):
        report = report_service.build_json(scan)
        if link.kind == ShareKind.RISK_REPORT:
            report = {"scan_id": report["scan_id"], "risk": report["risk"],
                      "generated_at": report["generated_at"]}
        return JSONResponse(report)

    # image-based kinds
    if not scan.storage_path or not Path(scan.storage_path).exists():
        raise HTTPException(status_code=404, detail="image unavailable")
    img = cv2.imread(scan.storage_path)
    if img is None:
        raise HTTPException(status_code=404, detail="unreadable image")

    if link.kind == ShareKind.REDACTED:
        from ...services.detection_pipeline import HybridDetectionPipeline
        pipe = HybridDetectionPipeline.get()
        result = pipe.analyze(img)
        img = pipe.redact(img, result["_detections"], method="blackbox")

    ok, buf = cv2.imencode(".jpg", img)
    if not ok:
        raise HTTPException(status_code=500, detail="encode failed")
    return StreamingResponse(io.BytesIO(buf.tobytes()), media_type="image/jpeg")
