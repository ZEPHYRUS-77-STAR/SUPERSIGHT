"""Health + readiness endpoints (DB connectivity check)."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from ...core.config import settings
from ...db.session import get_db

router = APIRouter(tags=["health"])


@router.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name, "version": settings.app_version,
            "env": settings.env}


@router.get("/health/ready")
def ready(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ready", "database": "sqlite" if settings.is_sqlite else "postgresql"}


@router.get("/health/services")
def services(db: Session = Depends(get_db)):
    """Auto-startup readiness dashboard: DB, storage, detection engine, GPU."""
    import json
    from pathlib import Path
    status = {"database": "down", "storage": "down", "engine": None, "gpu": None}
    try:
        db.execute(text("SELECT 1")); status["database"] = "ready"
    except Exception:
        status["database"] = "down"
    try:
        store = Path(__file__).resolve().parents[3] / "storage"
        store.mkdir(parents=True, exist_ok=True)
        probe = store / ".probe"; probe.write_text("ok"); probe.unlink()
        status["storage"] = "ready"
    except Exception:
        status["storage"] = "down"
    try:
        from ...services.detection_pipeline import HybridDetectionPipeline
        status["engine"] = HybridDetectionPipeline.get().engine_status()
        status["gpu"] = status["engine"].get("device")
    except Exception as e:
        status["engine"] = {"error": type(e).__name__}
    status["ready"] = status["database"] == "ready" and status["storage"] == "ready"
    return status
