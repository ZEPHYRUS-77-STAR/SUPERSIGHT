"""Security report endpoints (JSON + PDF), owner-scoped."""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy.orm import Session

from ...core.deps import get_current_user
from ...db.session import get_db
from ...models.user import User
from ...services import gallery_service, report_service

router = APIRouter(prefix="/reports", tags=["reports"])


@router.post("/{scan_id}")
def generate(scan_id: str, db: Session = Depends(get_db),
             user: User = Depends(get_current_user)):
    scan = gallery_service.get_owned(db, user.id, scan_id)
    if scan is None:
        raise HTTPException(status_code=404, detail="scan not found")
    report = report_service.create_report(db, scan, with_pdf=True)
    return JSONResponse(json.loads(report.summary_json))


@router.get("/{scan_id}")
def get_report(scan_id: str, db: Session = Depends(get_db),
               user: User = Depends(get_current_user)):
    scan = gallery_service.get_owned(db, user.id, scan_id)
    if scan is None:
        raise HTTPException(status_code=404, detail="scan not found")
    if scan.report and scan.report.summary_json:
        return JSONResponse(json.loads(scan.report.summary_json))
    return JSONResponse(report_service.build_json(scan))


@router.get("/{scan_id}/pdf")
def get_pdf(scan_id: str, db: Session = Depends(get_db),
            user: User = Depends(get_current_user)):
    scan = gallery_service.get_owned(db, user.id, scan_id)
    if scan is None:
        raise HTTPException(status_code=404, detail="scan not found")
    report = scan.report or report_service.create_report(db, scan, with_pdf=True)
    if not report.pdf_path or not Path(report.pdf_path).exists():
        report = report_service.create_report(db, scan, with_pdf=True)
    if not report.pdf_path or not Path(report.pdf_path).exists():
        raise HTTPException(status_code=503, detail="PDF rendering unavailable (install reportlab)")
    return FileResponse(report.pdf_path, media_type="application/pdf",
                        filename=f"securesight_{scan_id}.pdf")
