"""Hybrid detection endpoints (JWT-protected).

POST /api/detect   -> analyze only (no persistence), returns explainable result.
POST /api/scan     -> analyze + persist Scan/RiskAssessment, returns scan id + decision.
POST /api/redact   -> return the sanitized (redacted) image.
GET  /api/detect/engine -> device + model/backend availability.
"""
from __future__ import annotations

import io

import cv2
import numpy as np
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from ...core.deps import get_current_user
from ...db.session import get_db
from ...models.user import User
from ...schemas.detection import AnalyzeResponse, ScanResponse
from ...services.detection_pipeline import HybridDetectionPipeline
from ...services import scan_service, risk_service

router = APIRouter(tags=["detection"])

_DECISION = {"LOW": "ALLOW_UPLOAD", "MEDIUM": "ALLOW_UPLOAD_OF_REDACTED_VERSION_ONLY",
             "HIGH": "BLOCK_UPLOAD", "CRITICAL": "BLOCK_UPLOAD"}


def _read(data: bytes) -> np.ndarray:
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(status_code=400, detail="unreadable image")
    return img


@router.get("/detect/engine")
def engine_status(_: User = Depends(get_current_user)):
    return HybridDetectionPipeline.get().engine_status()


@router.post("/detect", response_model=AnalyzeResponse)
async def detect(file: UploadFile = File(...), _: User = Depends(get_current_user)):
    img = _read(await file.read())
    result = HybridDetectionPipeline.get().analyze(img)
    result.pop("_detections", None)
    return result


@router.post("/scan", response_model=ScanResponse)
async def scan(file: UploadFile = File(...), category: str = Form("uploaded"),
               db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    data = await file.read()
    img = _read(data)
    pipe = HybridDetectionPipeline.get()
    result = pipe.analyze(img)
    saved = scan_service.persist_scan(db, user.id, file.filename or "upload",
                                      file.content_type, data, result, category)
    return {"scan_id": saved.id, "risk_score": result["risk"]["score"],
            "risk_category": result["risk"]["category"],
            "decision": _DECISION.get(result["risk"]["category"], "ALLOW_UPLOAD"),
            "detections": result["detections"], "risk": result["risk"]}


@router.post("/redact")
async def redact(file: UploadFile = File(...), method: str = Form("blackbox"),
                 _: User = Depends(get_current_user)):
    img = _read(await file.read())
    pipe = HybridDetectionPipeline.get()
    result = pipe.analyze(img)
    redacted = pipe.redact(img, result["_detections"], method=method)
    ok, buf = cv2.imencode(".jpg", redacted)
    if not ok:
        raise HTTPException(status_code=500, detail="encode failed")
    return StreamingResponse(io.BytesIO(buf.tobytes()), media_type="image/jpeg",
                             headers={"X-SecureSight-Risk": result["risk"]["category"],
                                      "X-SecureSight-Score": str(result["risk"]["score"])})
