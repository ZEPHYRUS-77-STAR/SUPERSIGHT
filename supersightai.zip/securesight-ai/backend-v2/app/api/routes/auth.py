"""Auth endpoints: register, login (OAuth2 password flow), refresh, me."""
from __future__ import annotations

import jwt
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from ...core.deps import get_current_user
from ...core.security import create_access_token, create_refresh_token, decode_token
from ...db.session import get_db
from ...models.user import User
from ...schemas.auth import RefreshRequest, RegisterRequest, TokenPair
from ...schemas.user import UserOut
from ...services import auth_service, audit_service

router = APIRouter(prefix="/auth", tags=["auth"])


def _client_ip(request: Request) -> str | None:
    return request.client.host if request.client else None


@router.post("/register", response_model=UserOut, status_code=201)
def register(body: RegisterRequest, request: Request, db: Session = Depends(get_db)):
    try:
        user = auth_service.register(db, body.email, body.password, body.full_name)
    except auth_service.AuthError as e:
        raise HTTPException(status_code=400, detail=str(e))
    audit_service.record(db, "user_registered", user_id=user.id, ip=_client_ip(request))
    return user


@router.post("/login", response_model=TokenPair)
def login(request: Request, form: OAuth2PasswordRequestForm = Depends(),
          db: Session = Depends(get_db)):
    # OAuth2 form: `username` carries the email.
    try:
        user = auth_service.authenticate(db, form.username, form.password)
    except auth_service.AuthError as e:
        audit_service.record(db, "login_failed", ip=_client_ip(request), email=form.username)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(e))
    audit_service.record(db, "login_success", user_id=user.id, ip=_client_ip(request))
    return auth_service.issue_tokens(user)


@router.post("/refresh", response_model=TokenPair)
def refresh(body: RefreshRequest, db: Session = Depends(get_db)):
    try:
        payload = decode_token(body.refresh_token)
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="not a refresh token")
        user = db.get(User, payload.get("sub"))
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="invalid refresh token")
    if user is None or not user.is_active:
        raise HTTPException(status_code=401, detail="invalid user")
    return {"access_token": create_access_token(user.id, user.role.value),
            "refresh_token": create_refresh_token(user.id, user.role.value),
            "token_type": "bearer"}


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user
