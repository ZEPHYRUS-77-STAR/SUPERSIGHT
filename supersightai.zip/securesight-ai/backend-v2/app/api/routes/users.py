"""User administration (Admin only): list users, change roles."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from ...core.deps import require_role
from ...db.session import get_db
from ...models.user import User, UserRole
from ...schemas.user import RoleUpdate, UserOut
from ...services import user_service, audit_service

router = APIRouter(prefix="/users", tags=["users"])


@router.get("", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db),
               _: User = Depends(require_role(UserRole.ADMIN))):
    return user_service.list_users(db)


@router.patch("/{user_id}/role", response_model=UserOut)
def update_role(user_id: str, body: RoleUpdate, request: Request,
                db: Session = Depends(get_db),
                admin: User = Depends(require_role(UserRole.ADMIN))):
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="user not found")
    user_service.set_role(db, target, body.role)
    audit_service.record(db, "role_changed", user_id=admin.id,
                         target=user_id, new_role=body.role.value)
    return target
