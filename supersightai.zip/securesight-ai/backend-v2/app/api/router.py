"""Aggregate all API routers under /api."""
from __future__ import annotations

from fastapi import APIRouter

from .routes import auth, detection, gallery, health, reports, share, users

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(users.router)
api_router.include_router(detection.router)
api_router.include_router(reports.router)
api_router.include_router(gallery.router)
api_router.include_router(share.router)
