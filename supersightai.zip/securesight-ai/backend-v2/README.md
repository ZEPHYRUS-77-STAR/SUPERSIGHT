# SecureSight AI — v2 Backend (clean architecture)

Production foundation: **FastAPI · SQLAlchemy 2.0 · PostgreSQL · JWT/RBAC · Loguru**,
with an automatic **SQLite fallback** for offline/dev use.

## Layout
```
backend-v2/
├── app/
│   ├── main.py            FastAPI app (lifespan: schema/admin bootstrap)
│   ├── core/              config · logging(loguru) · security(jwt+bcrypt) · deps(RBAC)
│   ├── db/                base(DeclarativeBase) · session(engine/SessionLocal)
│   ├── models/            User · Scan · Report · RiskAssessment · AuditLog
│   ├── schemas/           pydantic auth/user/scan contracts
│   ├── services/          auth · user · audit (business logic)
│   ├── api/routes/        auth · users · health   (+ router.py aggregator)
│   └── workers/           (Celery — Phase 4)
├── alembic/               migration env + 0001_initial
├── tests/                 auth · rbac · models (pytest + TestClient)
├── requirements.txt  .env.example  Dockerfile  docker-compose.yml
```

## Run (dev, SQLite, zero infra)
```bash
cd backend-v2
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # leave DATABASE_URL empty for SQLite
uvicorn app.main:app --reload --port 8088
# docs: http://127.0.0.1:8088/docs
```
A first admin (`FIRST_ADMIN_EMAIL`/`PASSWORD`) is created automatically if no users exist.

## Run (prod, Postgres + migrations)
```bash
docker compose up --build       # api on :8088, postgres, redis
# or manually:
export DATABASE_URL=postgresql+psycopg2://securesight:securesight@localhost:5432/securesight
alembic upgrade head
uvicorn app.main:app --port 8088
```

## Auth & RBAC
- `POST /api/auth/register` → create a USER.
- `POST /api/auth/login` (OAuth2 form: `username`=email) → access + refresh tokens.
- `POST /api/auth/refresh` → new access token.
- `GET  /api/auth/me` → current user.
- `GET  /api/users` / `PATCH /api/users/{id}/role` → **Admin only** (RBAC).
Roles: `admin` (full), `analyst`, `user`. Guard routes with `require_role(...)`.

## Tests
```bash
pip install pytest httpx
pytest -q
```


## Phase 2 — Hybrid Detection Engine (built)
Pipeline: image → **YOLOv11 ⊕ YOLO-World ⊕ Grounding DINO** → **Fusion** (merge +
hybrid confidence + source attribution) → **SAM 2** masks → **OCR** (PaddleOCR/Tesseract)
→ **PII** (Presidio/regex) → **Risk** (4-band additive) → explainable result.

Endpoints (JWT-protected):
- `GET  /api/detect/engine` — device (CUDA/CPU) + model/backend availability.
- `POST /api/detect` — analyze only; returns per-detection {category, source,
  confidence, hybrid_confidence, risk_contribution, box} + risk + PII (explainable AI).
- `POST /api/scan` — analyze **and persist** Scan + RiskAssessment; returns scan id,
  risk score/category, and upload decision.
- `POST /api/redact?method=blackbox|blur|pixelate` — returns the sanitized image.

Install the models: `pip install -r requirements-ml.txt` (auto-detects GPU/CUDA,
falls back to CPU). Without them the engine still runs on Tesseract + regex + bbox masks.

Fusion confidence: probabilistic OR `1 - Π(1 - cᵢ)` → e.g. 0.82 ⊕ 0.88 = 0.978
(`hybrid_verified`), strictly higher than either model alone.

## Phase 3 — Reports · Gallery · Share (built)
**Reports** (JSON always; PDF via reportlab):
- `POST /api/reports/{scan_id}` — generate + persist report.
- `GET  /api/reports/{scan_id}` — JSON report (entities, risk, sensitive regions, redaction summary, timestamp, scan id).
- `GET  /api/reports/{scan_id}/pdf` — rendered PDF.

**Gallery** (owner-scoped; categories uploaded/captured/processed/redacted/reports):
- `GET /api/gallery?category=&q=&min_risk=&max_risk=&date_from=&date_to=` — search by name, scan id, risk range, date range.
- `GET /api/gallery/categories` — counts per category.
- `GET /api/gallery/{scan_id}` · `GET /api/gallery/{scan_id}/image`.

**Share** (expiring secure links; create/revoke need auth, resolve is public):
- `POST /api/share` `{scan_id, kind: image|redacted|report|risk_report, expiry: 1h|24h|7d|permanent}` → `{token, url, expires_at}`.
- `GET /api/share` (mine) · `DELETE /api/share/{token}` (revoke).
- `GET /api/s/{token}` — **PUBLIC**: serves image / redacted image / report / risk report if the link is valid (not revoked, not expired). Tokens are unguessable; ownership enforced at creation.

## Roadmap
2. Hybrid detection (YOLO-World ⊕ Grounding DINO ⊕ YOLOv11) + SAM 2 + Presidio
3. Reports (JSON/PDF) · Gallery · expiring share links
4. Celery + Redis async (batch / PDF / large images)
5. Deployment package (compose + HTTPS)
6. Offline desktop + one-click installer + auto-startup
