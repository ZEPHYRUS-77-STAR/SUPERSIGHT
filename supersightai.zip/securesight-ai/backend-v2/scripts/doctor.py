"""SecureSight AI v2 — environment doctor.

Verifies the local setup without starting the server: Python deps, DB URL,
storage dir, and optional ML stack. Prints a readiness report and exits non-zero
if a required component is missing. Used by the desktop bootstrap and CI.
"""
from __future__ import annotations

import importlib
import sys
from pathlib import Path

REQUIRED = ["fastapi", "uvicorn", "sqlalchemy", "pydantic", "jwt", "passlib", "loguru"]
OPTIONAL_ML = ["torch", "ultralytics", "transformers", "paddleocr", "presidio_analyzer",
               "cv2", "reportlab"]


def _check(mods):
    out = {}
    for m in mods:
        try:
            importlib.import_module(m); out[m] = True
        except Exception:
            out[m] = False
    return out


def main() -> int:
    print("SecureSight AI v2 — doctor\n" + "-" * 32)
    req = _check(REQUIRED)
    opt = _check(OPTIONAL_ML)
    for m, ok in req.items():
        print(f"  [{'OK ' if ok else 'MISSING'}] {m}  (required)")
    for m, ok in opt.items():
        print(f"  [{'OK ' if ok else '— '}] {m}  (optional)")

    storage = Path(__file__).resolve().parents[1] / "storage"
    try:
        storage.mkdir(parents=True, exist_ok=True)
        (storage / ".probe").write_text("ok"); (storage / ".probe").unlink()
        print("  [OK ] storage writable")
    except Exception as e:
        print(f"  [FAIL] storage: {e}")

    missing = [m for m, ok in req.items() if not ok]
    if missing:
        print(f"\nNOT READY — install: pip install -r requirements.txt  (missing: {', '.join(missing)})")
        return 1
    print("\nREADY — core stack present. (Install requirements-ml.txt for full detection.)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
