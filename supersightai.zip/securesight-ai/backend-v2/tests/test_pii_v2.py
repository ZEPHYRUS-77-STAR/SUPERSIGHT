from app.services.pii_service import PiiService


def test_regex_fallback_detects():
    svc = PiiService()
    hits = svc.analyze("PAN ABCDE1234F email a@b.com phone 9876543210")
    cats = {h["category"] for h in hits}
    assert "pan" in cats and "email" in cats and "phone" in cats


def test_severity_assigned():
    svc = PiiService()
    hits = svc.analyze("ABCDE1234F")
    assert hits and hits[0]["severity"] in {"LOW", "MEDIUM", "HIGH", "CRITICAL"}
