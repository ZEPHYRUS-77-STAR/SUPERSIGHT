"""Shared helpers for Phase 3 tests."""
from __future__ import annotations

import json

from app.models.scan import Scan, ScanStatus
from app.models.risk_assessment import RiskAssessment
from app.services.user_service import create_user


def make_user(db, email="owner@x.com"):
    return create_user(db, email, "password123")


def token_for(client, email="owner@x.com"):
    client.post("/api/auth/register", json={"email": email, "password": "password123"})
    return client.post("/api/auth/login",
                       data={"username": email, "password": "password123"}).json()["access_token"]


def make_scan(db, owner_id, *, score=95, category="uploaded", filename="id.jpg",
              storage_path=None):
    detail = {"detections": [{"category": "passport", "source": "hybrid_verified",
                              "confidence": 0.97, "box": [10, 10, 40, 30],
                              "risk_contribution": 40}],
              "pii": [{"category": "passport", "severity": "CRITICAL"}],
              "ocr_backend": "tesseract"}
    scan = Scan(owner_id=owner_id, filename=filename, category=category,
                status=ScanStatus.COMPLETED, risk_score=score, risk_category="CRITICAL",
                storage_path=storage_path, detections_json=json.dumps(detail))
    db.add(scan); db.flush()
    db.add(RiskAssessment(scan_id=scan.id, score=score, category="CRITICAL",
                          explanation="CRITICAL risk", contributions_json=json.dumps(
                              [{"category": "passport", "weight": 40}])))
    db.commit(); db.refresh(scan)
    return scan
