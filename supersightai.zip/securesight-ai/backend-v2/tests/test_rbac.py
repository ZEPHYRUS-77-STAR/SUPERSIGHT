def _user_token(client, email, role_promote=False, db=None):
    client.post("/api/auth/register",
                json={"email": email, "password": "password123"})
    return client.post("/api/auth/login",
                       data={"username": email, "password": "password123"}).json()["access_token"]


def test_plain_user_cannot_list_users(client):
    t = _user_token(client, "u1@x.com")
    r = client.get("/api/users", headers={"Authorization": f"Bearer {t}"})
    assert r.status_code == 403


def test_admin_can_list_users(client, db_session):
    from app.services.user_service import create_user
    from app.models.user import UserRole
    create_user(db_session, "admin@x.com", "password123", role=UserRole.ADMIN)
    t = client.post("/api/auth/login",
                    data={"username": "admin@x.com", "password": "password123"}).json()["access_token"]
    r = client.get("/api/users", headers={"Authorization": f"Bearer {t}"})
    assert r.status_code == 200 and isinstance(r.json(), list)


def test_no_token_unauthorized(client):
    assert client.get("/api/auth/me").status_code == 401
