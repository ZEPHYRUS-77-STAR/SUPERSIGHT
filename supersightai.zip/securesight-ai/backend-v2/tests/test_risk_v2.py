from app.services import risk_service
from app.vision.types import Detection, Source


def _d(cat):
    return Detection(category=cat, label=cat, box=(0, 0, 10, 10),
                     raw_confidence=0.9, source=Source.YOLOV11)


def test_bands():
    assert risk_service.classify(10) == "LOW"
    assert risk_service.classify(45) == "MEDIUM"
    assert risk_service.classify(70) == "HIGH"
    assert risk_service.classify(95) == "CRITICAL"


def test_additive_capped_and_critical():
    r = risk_service.assess([_d("passport"), _d("aadhaar"), _d("pan")])
    assert r.score == 100 and r.category == "CRITICAL"   # 40+35+30 -> cap 100


def test_single_face_low():
    r = risk_service.assess([_d("face")])
    assert r.score == 20 and r.category == "LOW"


def test_pii_contributes():
    r = risk_service.assess([], [{"category": "email"}, {"category": "phone"}])
    assert r.score == 10 and r.category == "LOW"


def test_per_detection_contribution_set():
    dets = [_d("passport")]
    risk_service.assess(dets)
    assert dets[0].risk_contribution == 40
