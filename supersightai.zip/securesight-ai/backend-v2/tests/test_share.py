from datetime import datetime, timedelta, timezone

from tests.conftest_helpers import make_user, token_for, make_scan
from app.models.share_link import ShareLink


def _auth(client, email):
    return {"Authorization": f"Bearer {token_for(client, email)}"}


def test_create_and_resolve_report_link(client, db_session):
    u = make_user(db_session, "s@x.com")
    scan = make_scan(db_session, u.id)
    h = _auth(client, "s@x.com")
    r = client.post("/api/share", json={"scan_id": scan.id, "kind": "risk_report",
                                        "expiry": "24h"}, headers=h)
    assert r.status_code == 200
    token = r.json()["token"]
    assert r.json()["url"].endswith(f"/api/s/{token}")

    # public resolve — no auth header
    pub = client.get(f"/api/s/{token}")
    assert pub.status_code == 200 and pub.json()["risk"]["score"] == 95


def test_revoke_blocks_access(client, db_session):
    u = make_user(db_session, "s2@x.com")
    scan = make_scan(db_session, u.id)
    h = _auth(client, "s2@x.com")
    token = client.post("/api/share", json={"scan_id": scan.id, "kind": "report",
                                            "expiry": "permanent"}, headers=h).json()["token"]
    assert client.get(f"/api/s/{token}").status_code == 200
    client.delete(f"/api/share/{token}", headers=h)
    assert client.get(f"/api/s/{token}").status_code == 404


def test_expired_link_rejected(client, db_session):
    u = make_user(db_session, "s3@x.com")
    scan = make_scan(db_session, u.id)
    h = _auth(client, "s3@x.com")
    token = client.post("/api/share", json={"scan_id": scan.id, "kind": "report",
                                            "expiry": "1h"}, headers=h).json()["token"]
    link = db_session.query(ShareLink).filter(ShareLink.token == token).first()
    link.expires_at = datetime.now(timezone.utc) - timedelta(hours=2)
    db_session.commit()
    assert client.get(f"/api/s/{token}").status_code == 404


def test_cannot_share_unowned_scan(client, db_session):
    owner = make_user(db_session, "owner2@x.com")
    scan = make_scan(db_session, owner.id)
    h = _auth(client, "intruder@x.com")
    r = client.post("/api/share", json={"scan_id": scan.id, "kind": "image",
                                        "expiry": "24h"}, headers=h)
    assert r.status_code == 400
