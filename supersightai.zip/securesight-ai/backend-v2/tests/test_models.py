from app.models.user import User, UserRole
from app.models.scan import Scan, ScanStatus
from app.services.user_service import create_user


def test_user_scan_relationship(db_session):
    u = create_user(db_session, "owner@x.com", "password123")
    s = Scan(owner_id=u.id, filename="a.jpg", category="uploaded",
             status=ScanStatus.PENDING)
    db_session.add(s); db_session.commit(); db_session.refresh(u)
    assert u.scans[0].filename == "a.jpg"
    assert u.scans[0].owner.email == "owner@x.com"


def test_role_default_is_user(db_session):
    u = create_user(db_session, "x@x.com", "password123")
    assert u.role == UserRole.USER
