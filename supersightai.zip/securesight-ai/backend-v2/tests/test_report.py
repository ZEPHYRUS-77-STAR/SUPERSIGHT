import json
from tests.conftest_helpers import make_user, token_for, make_scan
from app.services import report_service


def test_build_json_structure(db_session):
    u = make_user(db_session)
    scan = make_scan(db_session, u.id)
    rep = report_service.build_json(scan)
    assert rep["scan_id"] == scan.id
    assert rep["risk"]["category"] == "CRITICAL"
    assert rep["sensitive_regions"] and rep["sensitive_regions"][0]["category"] == "passport"
    assert "redaction_summary" in rep and rep["redaction_summary"]["regions_redactable"] == 1


def test_report_endpoint(client, db_session):
    u = make_user(db_session, "r@x.com")
    scan = make_scan(db_session, u.id)
    t = token_for(client, "r@x.com")
    r = client.get(f"/api/reports/{scan.id}", headers={"Authorization": f"Bearer {t}"})
    assert r.status_code == 200 and r.json()["risk"]["score"] == 95
