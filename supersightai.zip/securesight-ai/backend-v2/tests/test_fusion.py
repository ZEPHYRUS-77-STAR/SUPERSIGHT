from app.vision.fusion import DetectionFusionEngine
from app.vision.types import Detection, Source


def _d(cat, box, conf, src):
    return Detection(category=cat, label=cat, box=box, raw_confidence=conf,
                     source=src, sources=[src.value])


def test_overlapping_detections_merge_to_hybrid():
    yw = [_d("passport", (50, 50, 100, 60), 0.82, Source.YOLO_WORLD)]
    gd = [_d("passport", (52, 48, 98, 62), 0.88, Source.GROUNDING_DINO)]
    fused = DetectionFusionEngine().fuse(yw, gd)
    assert len(fused) == 1
    d = fused[0]
    assert d.source == Source.HYBRID_VERIFIED
    assert set(d.sources) == {"yolo_world", "grounding_dino"}
    # hybrid confidence strictly higher than either input
    assert d.hybrid_confidence > 0.88
    assert d.hybrid_confidence <= 0.99


def test_single_source_preserved():
    yw = [_d("aadhaar", (10, 10, 50, 30), 0.7, Source.YOLO_WORLD)]
    fused = DetectionFusionEngine().fuse(yw, [])
    assert len(fused) == 1
    assert fused[0].source == Source.YOLO_WORLD
    assert fused[0].hybrid_confidence == 0.7


def test_distinct_objects_not_merged():
    a = [_d("passport", (0, 0, 40, 40), 0.8, Source.YOLO_WORLD)]
    b = [_d("passport", (300, 300, 40, 40), 0.8, Source.GROUNDING_DINO)]
    fused = DetectionFusionEngine().fuse(a, b)
    assert len(fused) == 2
