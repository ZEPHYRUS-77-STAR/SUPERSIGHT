from tests.conftest_helpers import make_user, token_for, make_scan


def test_gallery_lists_owned_and_filters(client, db_session):
    u = make_user(db_session, "g@x.com")
    make_scan(db_session, u.id, category="uploaded", score=90, filename="aadhaar.jpg")
    make_scan(db_session, u.id, category="captured", score=10, filename="cat.jpg")
    t = token_for(client, "g@x.com")
    h = {"Authorization": f"Bearer {t}"}

    allitems = client.get("/api/gallery", headers=h).json()
    assert len(allitems) == 2

    high = client.get("/api/gallery?min_risk=50", headers=h).json()
    assert len(high) == 1 and high[0]["filename"] == "aadhaar.jpg"

    cap = client.get("/api/gallery?category=captured", headers=h).json()
    assert len(cap) == 1 and cap[0]["category"] == "captured"

    byname = client.get("/api/gallery?q=aadhaar", headers=h).json()
    assert len(byname) == 1


def test_gallery_isolation(client, db_session):
    a = make_user(db_session, "a@x.com"); make_scan(db_session, a.id)
    t = token_for(client, "b@x.com")   # different user
    items = client.get("/api/gallery", headers={"Authorization": f"Bearer {t}"}).json()
    assert items == []
