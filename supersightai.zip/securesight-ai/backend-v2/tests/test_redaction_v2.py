import numpy as np
from app.services.redaction_service import RedactionService
from app.vision.types import Detection, Source


def _d(cat, box):
    return Detection(category=cat, label=cat, box=box, raw_confidence=0.9,
                     source=Source.HYBRID_VERIFIED)


def test_blackbox_solid_and_region_only():
    img = np.random.randint(60, 255, (200, 300, 3), dtype=np.uint8)
    det = _d("passport", (40, 40, 80, 50))
    out, cats = RedactionService().redact(img, [det], method="blackbox",
                                          pad_frac=0.0, use_mask=False)
    assert (out[40:90, 40:120] == 0).all()
    assert np.array_equal(img[0:10, 0:10], out[0:10, 0:10])
    assert "passport" in cats


def test_pixelate_changes_region():
    img = np.random.randint(60, 255, (120, 160, 3), dtype=np.uint8)
    out, _ = RedactionService().redact(img, [_d("face", (10, 10, 60, 60))],
                                       method="pixelate", pad_frac=0.0, use_mask=False)
    assert not np.array_equal(img[10:70, 10:70], out[10:70, 10:70])
