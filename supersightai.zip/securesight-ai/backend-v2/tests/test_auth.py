def _register(client, email="user@x.com", pw="password123"):
    return client.post("/api/auth/register",
                       json={"email": email, "password": pw, "full_name": "U"})


def test_register_then_login_and_me(client):
    r = _register(client)
    assert r.status_code == 201
    assert r.json()["role"] == "user"

    tok = client.post("/api/auth/login",
                      data={"username": "user@x.com", "password": "password123"})
    assert tok.status_code == 200
    access = tok.json()["access_token"]

    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {access}"})
    assert me.status_code == 200 and me.json()["email"] == "user@x.com"


def test_duplicate_email_rejected(client):
    _register(client)
    assert _register(client).status_code == 400


def test_login_wrong_password(client):
    _register(client)
    r = client.post("/api/auth/login",
                    data={"username": "user@x.com", "password": "wrong"})
    assert r.status_code == 401


def test_refresh_rotates_access(client):
    _register(client)
    tok = client.post("/api/auth/login",
                      data={"username": "user@x.com", "password": "password123"}).json()
    r = client.post("/api/auth/refresh", json={"refresh_token": tok["refresh_token"]})
    assert r.status_code == 200 and "access_token" in r.json()
