"""initial schema: users, scans, risk_assessments, reports, audit_logs

Revision ID: 0001_initial
Revises:
Create Date: 2026-06-08
"""
from alembic import op
import sqlalchemy as sa

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

_role = sa.Enum("ADMIN", "ANALYST", "USER", name="userrole")
_status = sa.Enum("PENDING", "PROCESSING", "COMPLETED", "FAILED", name="scanstatus")


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("full_name", sa.String(255)),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("role", _role, nullable=False, server_default="USER"),
        sa.Column("is_active", sa.Boolean, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_users_email", "users", ["email"])

    op.create_table(
        "scans",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("filename", sa.String(512), nullable=False),
        sa.Column("content_type", sa.String(128)),
        sa.Column("storage_path", sa.String(1024)),
        sa.Column("category", sa.String(32), server_default="uploaded"),
        sa.Column("status", _status, server_default="PENDING"),
        sa.Column("risk_score", sa.Integer),
        sa.Column("risk_category", sa.String(16)),
        sa.Column("detections_json", sa.Text),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_scans_owner_id", "scans", ["owner_id"])

    op.create_table(
        "risk_assessments",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("scan_id", sa.String(36), sa.ForeignKey("scans.id"), nullable=False),
        sa.Column("score", sa.Integer, nullable=False),
        sa.Column("category", sa.String(16), nullable=False),
        sa.Column("explanation", sa.Text),
        sa.Column("contributions_json", sa.Text),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_risk_assessments_scan_id", "risk_assessments", ["scan_id"])

    op.create_table(
        "reports",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("scan_id", sa.String(36), sa.ForeignKey("scans.id"), nullable=False),
        sa.Column("summary_json", sa.Text, nullable=False),
        sa.Column("pdf_path", sa.String(1024)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_reports_scan_id", "reports", ["scan_id"])

    op.create_table(
        "audit_logs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), sa.ForeignKey("users.id")),
        sa.Column("event", sa.String(128), nullable=False),
        sa.Column("ip_address", sa.String(64)),
        sa.Column("detail", sa.Text),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_audit_logs_user_id", "audit_logs", ["user_id"])


def downgrade() -> None:
    for t in ("audit_logs", "reports", "risk_assessments", "scans", "users"):
        op.drop_table(t)
    _status.drop(op.get_bind(), checkfirst=True)
    _role.drop(op.get_bind(), checkfirst=True)
