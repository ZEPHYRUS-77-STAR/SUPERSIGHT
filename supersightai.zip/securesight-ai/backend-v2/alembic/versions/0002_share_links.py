"""share_links table

Revision ID: 0002_share_links
Revises: 0001_initial
Create Date: 2026-06-08
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_share_links"
down_revision = "0001_initial"
branch_labels = None
depends_on = None

_kind = sa.Enum("IMAGE", "REDACTED", "REPORT", "RISK_REPORT", name="sharekind")


def upgrade() -> None:
    op.create_table(
        "share_links",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("token", sa.String(64), nullable=False, unique=True),
        sa.Column("scan_id", sa.String(36), sa.ForeignKey("scans.id"), nullable=False),
        sa.Column("owner_id", sa.String(36), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("kind", _kind, server_default="IMAGE"),
        sa.Column("expires_at", sa.DateTime(timezone=True)),
        sa.Column("revoked", sa.Boolean, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_share_links_token", "share_links", ["token"], unique=True)
    op.create_index("ix_share_links_scan_id", "share_links", ["scan_id"])
    op.create_index("ix_share_links_owner_id", "share_links", ["owner_id"])


def downgrade() -> None:
    op.drop_table("share_links")
    _kind.drop(op.get_bind(), checkfirst=True)
