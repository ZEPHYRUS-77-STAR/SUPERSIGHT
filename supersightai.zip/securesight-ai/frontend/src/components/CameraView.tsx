// Browser-side camera preview. Uses getUserMedia for the live view and posts a
// captured frame to the backend /scan endpoint. (Hardware camera capture with
// HDR/flash is also available server-side via /api/camera/* for desktop builds.)
import { useEffect, useRef, useState } from "react";
import { api, ScanResult } from "../api/client";

export function CameraView() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => () => { stream?.getTracks().forEach((t) => t.stop()); }, [stream]);

  async function start() {
    const s = await navigator.mediaDevices.getUserMedia({ video: true });
    setStream(s);
    if (videoRef.current) { videoRef.current.srcObject = s; await videoRef.current.play(); }
  }
  async function capture() {
    const v = videoRef.current; if (!v) return;
    const canvas = document.createElement("canvas");
    canvas.width = v.videoWidth; canvas.height = v.videoHeight;
    canvas.getContext("2d")!.drawImage(v, 0, 0);
    setBusy(true);
    canvas.toBlob(async (blob) => {
      if (!blob) { setBusy(false); return; }
      try { setResult(await api.scan(new File([blob], "capture.jpg", { type: "image/jpeg" }))); }
      finally { setBusy(false); }
    }, "image/jpeg", 0.95);
  }

  return (
    <div className="card">
      <strong>Camera</strong>
      <div className="row">
        <button className="btn ghost" onClick={start}>Start camera</button>
        <button className="btn" disabled={!stream || busy} onClick={capture}>Capture & scan</button>
      </div>
      <video ref={videoRef} className="prev" muted playsInline style={{ marginTop: 8 }} />
      {result && <p className="muted">{result.warning || `No sensitive content (${result.risk}).`}</p>}
    </div>
  );
}
