import { useEffect, useState } from "react";
import { api, RISK_COLOR } from "../api/client";

interface Row { id: number; ts: number; source: string; risk: string; n_regions: number; }

export function HistoryTable() {
  const [rows, setRows] = useState<Row[]>([]);
  useEffect(() => { api.history().then((d) => setRows(d.scans || [])).catch(() => {}); }, []);
  if (!rows.length) return <p className="muted">No scans yet.</p>;
  return (
    <table>
      <thead><tr><th>When</th><th>Source</th><th>Risk</th><th>Regions</th></tr></thead>
      <tbody>
        {rows.map((r) => (
          <tr key={r.id}>
            <td>{new Date(r.ts * 1000).toLocaleString()}</td>
            <td>{r.source}</td>
            <td><span className="pill" style={{ background: RISK_COLOR[r.risk], color: "#0d1117" }}>{r.risk}</span></td>
            <td>{r.n_regions}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
