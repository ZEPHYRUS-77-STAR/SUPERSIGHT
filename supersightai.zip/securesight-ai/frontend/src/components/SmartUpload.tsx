// Smart Risk Assessment & Upload Control flow.
import { useState } from "react";
import { api, UploadDecision } from "../api/client";
import { Dropzone } from "./Dropzone";
import { RiskNotice } from "./RiskNotice";

export function SmartUpload() {
  const [file, setFile] = useState<File | null>(null);
  const [src, setSrc] = useState<string | null>(null);
  const [decision, setDecision] = useState<UploadDecision | null>(null);
  const [secureUrl, setSecureUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  function pick(f: File) {
    setFile(f); setDecision(null); setSecureUrl(null); setErr(null);
    setSrc(URL.createObjectURL(f));
  }
  async function assess() {
    if (!file) return; setBusy(true); setErr(null);
    try {
      const d = await api.assessRisk(file);
      setDecision(d);
      if (d.decision === "ALLOW_UPLOAD_OF_REDACTED_VERSION_ONLY") {
        setSecureUrl(URL.createObjectURL(await api.redacted(file)));
      }
    } catch (e) { setErr((e as Error).message + " — is the backend running on :8077?"); }
    finally { setBusy(false); }
  }
  async function makeRedacted() {
    if (!file) return;
    setSecureUrl(URL.createObjectURL(await api.redacted(file)));
  }

  const canUploadOriginal = decision?.decision === "ALLOW_UPLOAD";
  const blocked = decision?.decision === "BLOCK_UPLOAD";

  return (
    <div className="grid">
      <div className="card">
        <strong>Smart Upload Control</strong>
        <Dropzone file={file} onPick={pick} />
        {src && <img className="prev" src={secureUrl || src} alt="preview" />}
        <div className="row">
          <button className="btn" disabled={!file || busy} onClick={assess}>Assess risk</button>
          {/* LOW-risk optional privacy */}
          {decision?.optional_privacy && !secureUrl &&
            <button className="btn ghost" onClick={makeRedacted}>Apply privacy redaction</button>}
          {/* upload buttons reflect the decision */}
          {canUploadOriginal &&
            <a className="btn ghost" href={src!} download>Upload original</a>}
          {secureUrl &&
            <a className="btn" href={secureUrl} download="secure.jpg">Upload secure version</a>}
          {blocked && <button className="btn" disabled>Upload blocked</button>}
        </div>
        {err && <div style={{ color: "var(--high)", marginTop: 10 }}>{err}</div>}
      </div>
      <div>
        {decision ? <RiskNotice d={decision} />
          : <div className="card"><p className="muted">Choose an image and assess its risk.</p></div>}
      </div>
    </div>
  );
}
