import { UploadDecision, RISK_CATEGORY_COLOR } from "../api/client";

export function RiskNotice({ d }: { d: UploadDecision }) {
  const color = RISK_CATEGORY_COLOR[d.risk_category] || "var(--mut)";
  const blocked = d.decision === "BLOCK_UPLOAD";
  return (
    <div className="card" style={{ borderColor: color }}>
      <div className="row" style={{ justifyContent: "space-between" }}>
        <strong style={{ color }}>{d.notification}</strong>
        {d.sensitive && (
          <span className="pill" style={{ background: color, color: "#0d1117" }}>
            {d.risk_category} · {d.risk_score}/100
          </span>
        )}
      </div>
      <p className="muted">{d.reason}</p>
      {d.threats.length > 0 && (
        <div className="row">
          {d.threats.map((t) => <span className="badge" key={t}>{t}</span>)}
        </div>
      )}
      <div className="muted" style={{ marginTop: 8 }}>
        Decision: <strong>{d.decision}</strong>
        {blocked && " — no override (high-risk policy)"}
        {d.redacted && " · secure redacted version generated"}
      </div>
    </div>
  );
}
