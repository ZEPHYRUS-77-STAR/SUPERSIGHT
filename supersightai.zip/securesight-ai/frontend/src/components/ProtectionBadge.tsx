import { useEffect, useState } from "react";
import { api, ProtectionStatus } from "../api/client";

export function ProtectionBadge() {
  const [prot, setProt] = useState<ProtectionStatus | null>(null);
  const [open, setOpen] = useState(false);
  const [dur, setDur] = useState("7d");
  const [pass, setPass] = useState("");

  const refresh = () => api.protectionStatus().then(setProt).catch(() => {});
  useEffect(() => { refresh(); }, []);

  async function activate() {
    await api.activate(dur, pass); setOpen(false); setPass(""); refresh();
  }
  async function deactivate() {
    const p = prompt("Enter recovery passphrase to turn off protection:");
    if (!p) return;
    try { await api.deactivate(p); } catch { alert("Incorrect passphrase"); }
    refresh();
  }
  const days = prot?.remaining_seconds ? Math.ceil(prot.remaining_seconds / 86400) : 0;

  return (
    <div style={{ textAlign: "right" }}>
      <span className="pill" style={{ background: prot?.active ? "var(--low)" : "var(--line)",
        color: prot?.active ? "#0d1117" : "var(--mut)" }}>
        {prot?.active ? `Protection on · ${days}d left` : "Protection off"}
      </span>
      <div className="row" style={{ justifyContent: "flex-end" }}>
        {!prot?.active && <button className="btn ghost" onClick={() => setOpen(!open)}>Enable…</button>}
        {prot?.active && <button className="btn ghost" onClick={deactivate}>Owner override…</button>}
      </div>
      {open && !prot?.active && (
        <div className="card" style={{ marginTop: 8, textAlign: "left" }}>
          <div className="muted">Choose duration & a recovery passphrase (you can always turn it off with this).</div>
          <div className="row">
            <select value={dur} onChange={(e) => setDur(e.target.value)}>
              <option value="1d">1 day</option><option value="7d">7 days</option>
              <option value="15d">15 days</option><option value="30d">30 days</option>
              <option value="90d">90 days</option>
            </select>
            <input type="password" placeholder="recovery passphrase" value={pass}
              onChange={(e) => setPass(e.target.value)} />
            <button className="btn" disabled={pass.length < 6} onClick={activate}>Activate</button>
          </div>
        </div>
      )}
    </div>
  );
}
