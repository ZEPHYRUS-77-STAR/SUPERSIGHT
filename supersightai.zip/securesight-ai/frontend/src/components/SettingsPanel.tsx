import { useEffect, useState } from "react";
import { api } from "../api/client";

export function SettingsPanel() {
  const [pii, setPii] = useState(false);
  const [saved, setSaved] = useState(false);
  useEffect(() => { api.getPrivacy().then((s) => setPii(s.treat_pii_as_sensitive)).catch(() => {}); }, []);
  async function toggle() {
    const next = !pii;
    setPii(next);
    await api.setPrivacy(next);
    setSaved(true); setTimeout(() => setSaved(false), 1500);
  }
  return (
    <div className="card">
      <strong>Privacy Settings</strong>
      <div className="row" style={{ justifyContent: "space-between" }}>
        <div style={{ maxWidth: 520 }}>
          <div>Treat Personal Identifiable Information (PII) as Sensitive Content</div>
          <div className="muted">
            When enabled, PII (names, phones, emails, addresses, account numbers) adds to the
            risk score. When disabled (default), PII is shown but does not raise the score.
          </div>
        </div>
        <button className="btn" onClick={toggle}>{pii ? "Enabled" : "Disabled"}</button>
      </div>
      {saved && <div className="muted" style={{ color: "var(--low)" }}>Saved.</div>}
    </div>
  );
}
