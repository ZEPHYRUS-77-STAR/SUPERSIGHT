import { ScanResult, RISK_COLOR } from "../api/client";

export function RiskReport({ scan }: { scan: ScanResult | null }) {
  if (!scan) return <p className="muted">Run a scan to see detected sensitive regions.</p>;
  return (
    <div>
      <div className="row">
        <span className="pill" style={{ background: RISK_COLOR[scan.risk], color: "#0d1117" }}>{scan.risk}</span>
        <span className="muted">{scan.count} region(s) · {scan.width}×{scan.height}</span>
      </div>
      {scan.warning && <p style={{ color: "var(--medium)" }}>{scan.warning}</p>}
      {scan.detections.map((d, i) => (
        <div className="det" key={i}>
          <div>
            <span className="pill" style={{ background: RISK_COLOR[d.risk], color: "#0d1117", marginRight: 8 }}>{d.risk}</span>
            <strong>{d.category}</strong>
            <div className="muted">{d.explanation}</div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div className="badge">{(d.confidence * 100).toFixed(0)}%</div>
            <div className="muted">{d.source}</div>
          </div>
        </div>
      ))}
      <div className="muted" style={{ marginTop: 8 }}>
        Backends: {Object.entries(scan.backends).map(([k, v]) => `${k}=${v}`).join(" · ")}
      </div>
    </div>
  );
}
