// Typed client for the local SecureSight AI API (localhost only).
const BASE = "http://127.0.0.1:8077/api";

export interface Detection {
  category: string; confidence: number; box: [number, number, number, number];
  source: string; risk: string; explanation: string; text?: string | null;
}
export interface ScanResult {
  width: number; height: number; risk: string; count: number;
  detections: Detection[]; backends: Record<string, string>; warning: string | null;
}
export interface ProtectionStatus {
  active: boolean; started: number | null; expires: number | null;
  remaining_seconds: number; has_recovery: boolean;
}


export interface UploadDecision {
  sensitive: boolean; risk_score: number; risk_category: string;
  decision: string; override_allowed: boolean; threats: string[];
  reason: string; notification: string; redacted: boolean;
  redacted_path: string | null; optional_privacy: boolean;
  detections: Detection[]; contributions: { category: string; weight: number; counted: boolean; pii: boolean }[];
}
export interface PrivacySettings { treat_pii_as_sensitive: boolean; }

async function jpost<T>(path: string, body: unknown): Promise<T> {
  const r = await fetch(BASE + path, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error((await safeErr(r)) || `request failed (${r.status})`);
  return r.json() as Promise<T>;
}
async function safeErr(r: Response): Promise<string> {
  try { const j = await r.json(); return j.error || j.detail || ""; } catch { return ""; }
}

export const api = {
  async scan(file: File): Promise<ScanResult> {
    const fd = new FormData(); fd.append("file", file);
    const r = await fetch(BASE + "/scan", { method: "POST", body: fd });
    if (!r.ok) throw new Error(`scan failed (${r.status})`);
    return r.json();
  },
  async protect(file: File): Promise<Blob> {
    const fd = new FormData(); fd.append("file", file);
    const r = await fetch(BASE + "/protect", { method: "POST", body: fd });
    if (!r.ok) throw new Error(`protect failed (${r.status})`);
    return r.blob();
  },
  async assessRisk(file: File): Promise<UploadDecision> {
    const fd = new FormData(); fd.append("file", file);
    const r = await fetch(BASE + "/risk/assess", { method: "POST", body: fd });
    if (!r.ok) throw new Error(`assess failed (${r.status})`);
    return r.json();
  },
  async redacted(file: File): Promise<Blob> {
    const fd = new FormData(); fd.append("file", file);
    const r = await fetch(BASE + "/risk/redacted", { method: "POST", body: fd });
    if (!r.ok) throw new Error(`redaction failed (${r.status})`);
    return r.blob();
  },
  getPrivacy: () => fetch(BASE + "/privacy/settings").then((r) => r.json()) as Promise<PrivacySettings>,
  setPrivacy: (treat_pii_as_sensitive: boolean) =>
    jpost<PrivacySettings>("/privacy/settings", { treat_pii_as_sensitive }),
  history: () => fetch(BASE + "/history").then((r) => r.json()),
  protectionStatus: () => fetch(BASE + "/protection/status").then((r) => r.json()) as Promise<ProtectionStatus>,
  activate: (duration: string, recovery_passphrase: string) =>
    jpost<ProtectionStatus>("/protection/activate", { duration, recovery_passphrase }),
  deactivate: (recovery_passphrase: string) =>
    jpost<ProtectionStatus>("/protection/deactivate", { recovery_passphrase }),
};

export const RISK_CATEGORY_COLOR: Record<string, string> = {
  HIGH: "var(--critical)", MEDIUM: "var(--medium)", LOW: "var(--low)", NONE: "var(--low)",
};
export const RISK_COLOR: Record<string, string> = {
  low: "var(--low)", medium: "var(--medium)", high: "var(--high)", critical: "var(--critical)",
};
