import { useState, useCallback } from "react";
import { api, ScanResult } from "../api/client";

export function useScan() {
  const [scan, setScan] = useState<ScanResult | null>(null);
  const [protectedUrl, setProtectedUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const runScan = useCallback(async (file: File) => {
    setBusy(true); setError(null); setProtectedUrl(null);
    try { setScan(await api.scan(file)); }
    catch (e) { setError((e as Error).message + " — is the backend running on :8077?"); }
    finally { setBusy(false); }
  }, []);

  const runProtect = useCallback(async (file: File) => {
    setBusy(true); setError(null);
    try { setProtectedUrl(URL.createObjectURL(await api.protect(file))); }
    catch (e) { setError((e as Error).message); }
    finally { setBusy(false); }
  }, []);

  const reset = useCallback(() => { setScan(null); setProtectedUrl(null); setError(null); }, []);
  return { scan, protectedUrl, busy, error, runScan, runProtect, reset };
}
