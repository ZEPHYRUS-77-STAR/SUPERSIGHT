import { useState } from "react";
import { Dropzone } from "./components/Dropzone";
import { RiskReport } from "./components/RiskReport";
import { ProtectionBadge } from "./components/ProtectionBadge";
import { HistoryTable } from "./components/HistoryTable";
import { CameraView } from "./components/CameraView";
import { SmartUpload } from "./components/SmartUpload";
import { SettingsPanel } from "./components/SettingsPanel";
import { useScan } from "./hooks/useScan";

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [src, setSrc] = useState<string | null>(null);
  const { scan, protectedUrl, busy, error, runScan, runProtect, reset } = useScan();
  const [tab, setTab] = useState<"smart" | "upload" | "camera" | "history" | "settings">("smart");

  function pick(f: File) { setFile(f); reset(); setSrc(URL.createObjectURL(f)); }

  return (
    <div className="wrap">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <h1>🛡️ SecureSight AI</h1>
          <div className="sub">Local-first image privacy protection · nothing leaves your device</div>
        </div>
        <ProtectionBadge />
      </div>

      <div className="row">
        <button className="btn ghost" onClick={() => setTab("smart")}>Smart Upload</button>
        <button className="btn ghost" onClick={() => setTab("upload")}>Manual</button>
        <button className="btn ghost" onClick={() => setTab("camera")}>Camera</button>
        <button className="btn ghost" onClick={() => setTab("history")}>History</button>
        <button className="btn ghost" onClick={() => setTab("settings")}>Settings</button>
      </div>

      {tab === "smart" && <div style={{ marginTop: 16 }}><SmartUpload /></div>}
      {tab === "upload" && (
        <div className="grid">
          <div className="card">
            <strong>1 · Choose an image</strong>
            <Dropzone file={file} onPick={pick} />
            {src && <img className="prev" src={protectedUrl || src} alt="preview" />}
            <div className="row">
              <button className="btn" disabled={!file || busy} onClick={() => file && runScan(file)}>Scan</button>
              <button className="btn ghost" disabled={!scan || busy} onClick={() => file && runProtect(file)}>Blur sensitive regions</button>
              {protectedUrl && <a className="btn ghost" href={protectedUrl} download="protected.jpg">Download protected</a>}
            </div>
            {error && <div style={{ color: "var(--high)", marginTop: 10 }}>{error}</div>}
          </div>
          <div className="card">
            <strong>2 · Risk report</strong>
            <RiskReport scan={scan} />
          </div>
        </div>
      )}
      {tab === "camera" && <div style={{ marginTop: 16 }}><CameraView /></div>}
      {tab === "history" && <div className="card" style={{ marginTop: 16 }}><HistoryTable /></div>}
      {tab === "settings" && <div style={{ marginTop: 16 }}><SettingsPanel /></div>}
    </div>
  );
}
