// Secure context bridge: exposes only a tiny, explicit API to the renderer.
const { contextBridge } = require("electron");
contextBridge.exposeInMainWorld("securesight", {
  apiBase: "http://127.0.0.1:8077/api",
  version: "0.1.0",
});
