// System tray with protection status. Lets the user open the dashboard or quit.
const { Tray, Menu, nativeImage } = require("electron");
const path = require("path");
const http = require("http");

function fetchStatus(cb) {
  http.get("http://127.0.0.1:8077/api/protection/status", (res) => {
    let data = ""; res.on("data", (c) => (data += c));
    res.on("end", () => { try { cb(JSON.parse(data)); } catch { cb(null); } });
  }).on("error", () => cb(null));
}

function createTray(onOpen, onQuit) {
  const icon = nativeImage.createFromPath(path.join(__dirname, "resources", "icon.png"));
  const tray = new Tray(icon.isEmpty() ? nativeImage.createEmpty() : icon);
  const render = () => fetchStatus((s) => {
    const label = s?.active ? "Protection: ON" : "Protection: off";
    tray.setToolTip("SecureSight AI");
    tray.setContextMenu(Menu.buildFromTemplate([
      { label, enabled: false },
      { type: "separator" },
      { label: "Open dashboard", click: onOpen },
      { label: "Quit", click: onQuit },
    ]));
  });
  render();
  setInterval(render, 15000);
  return tray;
}
module.exports = { createTray };
