// Electron desktop shell for SecureSight AI.
// Spawns the local FastAPI backend, loads the built dashboard, adds a tray.
// All local — no remote endpoints.
const { app, BrowserWindow } = require("electron");
const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");
const { createTray } = require("./tray");

let backend = null;
let tray = null;
let win = null;

function startBackend() {
  const cwd = path.join(__dirname, "..", "..", "backend");
  // Prefer a bundled venv python if present, else system python.
  const candidates = [
    path.join(cwd, ".venv", "bin", "python"),
    path.join(cwd, ".venv", "Scripts", "python.exe"),
    "python3",
    "python",
  ];
  const py = candidates.find((p) => p.endsWith("python") || p.endsWith("python.exe")
    ? (fs.existsSync(p) || !p.includes(path.sep)) : false) || "python";
  backend = spawn(py, ["-m", "app.main"], { cwd, stdio: "inherit" });
  backend.on("error", (e) => console.error("backend failed to start:", e));
}

function dashboardEntry() {
  // Load the built bundle in production; fall back to the dev file if unbuilt.
  const built = path.join(__dirname, "..", "dist", "index.html");
  const dev = path.join(__dirname, "..", "index.html");
  return fs.existsSync(built) ? built : dev;
}

function createWindow() {
  win = new BrowserWindow({
    width: 1180,
    height: 820,
    title: "SecureSight AI",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.loadFile(dashboardEntry());
}

function showWindow() {
  if (!win || win.isDestroyed()) createWindow();
  else win.show();
}

app.whenReady().then(() => {
  startBackend();
  setTimeout(() => {
    createWindow();
    tray = createTray(showWindow, () => app.quit());
  }, 1500);
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  // Keep running in the tray on macOS; quit elsewhere when the window closes.
  if (process.platform !== "darwin") {
    if (backend) backend.kill();
    app.quit();
  }
});

app.on("before-quit", () => {
  if (backend) backend.kill();
});
