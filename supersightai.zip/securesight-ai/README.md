# SecureSight AI

**AI-based local-first image privacy protection.**

SecureSight AI inspects an image *before* it leaves your device and detects sensitive
content — faces, government IDs (Aadhaar / PAN / passport / driving licence), signatures,
bank documents, screenshot PII, weapons and NSFW content. When something risky is found it
**warns you, explains the risk, and blurs only the sensitive pixels** — never the whole
image — so you can safely share the rest.

Everything runs **locally**. No image ever leaves the machine. Online mode is optional and
only used to download model / threat-intel updates.

---

## Design boundary (read this first)

This project deliberately does **not** implement "cannot be uninstalled / cannot be disabled /
anti-bypass / admin-lock / self-recovering watchdog" behaviour. Software that resists removal
by the device owner is indistinguishable from malware / stalkerware and is unsafe to ship.

Instead, **Protection Mode** is a *consent-based, owner-recoverable* control: the user enables
it for a chosen duration and it stays on for that period, but the device owner can **always**
recover/override it with the recovery passphrase and can always uninstall the software.
See `docs/SECURITY.md`.

---

## Layout

```
securesight-ai/
├── backend/            FastAPI service + AI pipeline + DB + security
│   ├── app/
│   │   ├── ai/         detection, OCR/PII, segmentation, region-blur
│   │   ├── api/        REST endpoints
│   │   ├── core/       config, crypto, protection-mode, watcher
│   │   └── db/         encrypted SQLite layer
│   ├── tests/          pytest suite
│   └── requirements.txt
├── frontend/           React dashboard (single-file, runnable)
├── docs/               ARCHITECTURE / SECURITY / INSTALL / DEPLOY
└── scripts/            install / run helpers
```

## Quick start

```bash
cd securesight-ai/backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m app.main                 # API on http://127.0.0.1:8077
```

CLI scan (no server needed):

```bash
python -m app.ai.pipeline path/to/image.jpg --out protected.jpg
```

Optional heavy models (YOLOv8, SAM, PaddleOCR, NudeNet, face_recognition, MediaPipe) are
auto-detected if installed; otherwise the pipeline falls back to bundled OpenCV detectors so
it always runs. See `docs/INSTALL.md`.

## Tool integration map

| Tool | Role | Module |
|------|------|--------|
| OpenCV | image IO, Haar face detect, blur/pixelate engine | `ai/blur.py`, `ai/detectors/opencv_face.py` |
| YOLOv8 (Ultralytics) | person / object / document detection | `ai/detectors/yolo.py` |
| Segment Anything (SAM) | precise pixel masks | `ai/segment.py` |
| MediaPipe | face landmarks / body | `ai/detectors/mediapipe_face.py` |
| PaddleOCR | primary OCR | `ai/ocr.py` |
| Tesseract | backup OCR + validation | `ai/ocr.py` |
| NudeNet | NSFW detection | `ai/detectors/nsfw.py` |
| face_recognition | identity matching | `ai/detectors/face_match.py` |
| Watchdog | folder auto-scan | `core/watcher.py` |
| FastAPI | backend API | `api/`, `main.py` |
| React / Electron | dashboard + desktop shell | `frontend/` |
| PyTorch | inference backend | runtime dep |

> Runnable scaffold, not a finished commercial product. The OpenCV/Tesseract/regex path works
> out of the box; deep-learning detectors activate when their weights are present.
