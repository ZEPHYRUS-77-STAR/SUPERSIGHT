# SecureSight AI — Team Onboarding

Welcome. This repo is a local-first AI image privacy tool. Everything runs on the
developer's machine; no image data leaves the device.

## Get running in one command
```bash
# Linux / macOS
bash scripts/bootstrap.sh                 # backend venv + deps + smoke test
bash scripts/bootstrap.sh --frontend      # also install dashboard deps
bash scripts/bootstrap.sh --optional      # also install heavy AI models (large)
```
```powershell
# Windows
powershell -ExecutionPolicy Bypass -File scripts\bootstrap.ps1
```

## Run it
| What | Command |
|------|---------|
| API server | `cd backend && source .venv/bin/activate && python -m app.main` → http://127.0.0.1:8077 |
| CLI scan | `python -m app.ai.pipeline image.jpg --out protected.jpg` |
| Dashboard (dev) | `cd frontend && npm install && npm run dev` → http://127.0.0.1:5173 |
| Desktop app | `cd frontend && npm run build && cd electron && npm install && npm start` |
| Tests | `cd backend && pip install pytest httpx && pytest -q` |

## Where things live
- `backend/app/ai/` — detection + blur engine
- `backend/app/services/` — Smart Risk Assessment & Upload Control
- `backend/app/api/` — REST endpoints (see `docs/API.md`)
- `frontend/src/` — React/TypeScript dashboard
- `docs/` — ARCHITECTURE, SECURITY, RISK_ENGINE, API, CAMERA, DEPLOY
- `MANIFEST.md` — full file index

## Conventions & guardrails
- The app is **defensive only**. Protection Mode is consent-based and always
  owner-recoverable; never add anti-uninstall / anti-bypass behaviour (see
  `docs/SECURITY.md`).
- Heavy AI models are optional and auto-detected; code must degrade gracefully
  when they're absent.
- No image bytes are ever stored in the DB or sent off-device.

## Branch & review
- Branch from `main`, keep PRs focused, run `pytest -q` and `scripts/smoke_test.sh`
  before requesting review.
