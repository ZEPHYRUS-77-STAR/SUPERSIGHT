-- Canonical SecureSight AI local schema (mirrors backend/app/db/models.py).
-- Sensitive columns (*_enc) hold AES-256-GCM ciphertext; no image bytes stored.
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    source TEXT,
    risk TEXT NOT NULL,
    n_regions INTEGER NOT NULL,
    detail_enc BLOB
);

CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    event TEXT NOT NULL,
    detail_enc BLOB
);

CREATE TABLE IF NOT EXISTS protection (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    active INTEGER NOT NULL DEFAULT 0,
    started REAL,
    expires REAL,
    recovery_salt TEXT,
    recovery_hash TEXT
);

CREATE TABLE IF NOT EXISTS known_faces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    encoding_enc BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE INDEX IF NOT EXISTS idx_scans_ts ON scans(ts);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit(ts);
