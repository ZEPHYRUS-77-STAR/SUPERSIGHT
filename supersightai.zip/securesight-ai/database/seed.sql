-- Optional defaults.
INSERT OR IGNORE INTO protection (id, active) VALUES (1, 0);
INSERT OR IGNORE INTO meta (key, value) VALUES ('schema_version', '1');
