# SecureSight AI — Repository Manifest

_Generated 2026-06-08 · 143 files_

Complete inventory of every source file in the repository. Full code for each file is included in the repo/zip; this is the index for reviewers and new team members.


## backend

- `backend/.env.example`
- `backend/Dockerfile`
- `backend/app/__init__.py`
- `backend/app/ai/__init__.py`
- `backend/app/ai/blur.py` — Reversible region-only blur engine + annotate
- `backend/app/ai/detectors/__init__.py`
- `backend/app/ai/detectors/document_id.py` — ID/document detector (YOLO model or OpenCV quad fallback)
- `backend/app/ai/detectors/face_match.py` — face_recognition identity matching (optional)
- `backend/app/ai/detectors/mediapipe_face.py` — MediaPipe face detector (optional)
- `backend/app/ai/detectors/nsfw.py` — NudeNet NSFW detector (optional)
- `backend/app/ai/detectors/opencv_face.py` — Haar face detector (always-on fallback)
- `backend/app/ai/detectors/weapon.py` — Dedicated weapon detector (model-gated)
- `backend/app/ai/detectors/yolo.py` — YOLOv8 person/object/weapon/document (optional)
- `backend/app/ai/model_registry.py` — Resolve/report weight files under ai_models/
- `backend/app/ai/ocr.py` — PaddleOCR/Tesseract OCR + sensitive-text extraction
- `backend/app/ai/pii.py` — PII patterns + Verhoeff/Luhn validation
- `backend/app/ai/pipeline.py` — Detector orchestrator + CLI; aggregates detections, overall risk
- `backend/app/ai/segment.py` — SAM box->mask (bbox fallback)
- `backend/app/ai/types.py` — Detection/RiskLevel dataclasses + category->risk map
- `backend/app/api/__init__.py`
- `backend/app/api/deps.py` — Upload size guard + in-process rate limiting
- `backend/app/api/errors.py` — Unified exception handlers
- `backend/app/api/routes.py` — Core endpoints: /scan /protect /preview /history /audit /protection/*
- `backend/app/api/routes_camera.py` — Camera endpoints: device list, AI-gated capture, video record start/stop
- `backend/app/api/routes_risk.py` — Smart Risk: /risk/assess /risk/redacted + /privacy/settings
- `backend/app/api/routes_updates.py` — Model availability + opt-in online update endpoints
- `backend/app/api/routes_upload.py` — Upload-guard endpoints: per-platform scan-before-attach
- `backend/app/api/schemas.py` — Pydantic request models (protection activate/deactivate)
- `backend/app/camera/__init__.py`
- `backend/app/camera/capture.py` — Still capture: HDR fusion, software flash, AI save-gate
- `backend/app/camera/devices.py` — Camera enumeration/open (OpenCV)
- `backend/app/camera/live_scan.py` — Real-time annotated frame generator
- `backend/app/camera/video.py` — Video recorder with periodic scanning
- `backend/app/core/__init__.py`
- `backend/app/core/config.py` — Settings, paths, thresholds loader (thresholds.yaml)
- `backend/app/core/crypto.py` — AES-256-GCM + PBKDF2 passphrase hashing
- `backend/app/core/logging.py` — Encrypted audit log + redacted file log
- `backend/app/core/protection.py` — Consent-based, owner-recoverable Protection Mode
- `backend/app/core/service.py` — Background service: folder watch lifecycle
- `backend/app/core/updater.py` — Opt-in model/threat-intel updater (checksum-verified)
- `backend/app/core/watcher.py` — Watchdog folder auto-scan
- `backend/app/db/__init__.py`
- `backend/app/db/database.py` — Encrypted SQLite layer (scans/audit/protection/meta/known_faces)
- `backend/app/db/models.py` — Canonical SCHEMA_SQL (single source of truth) + row dataclasses
- `backend/app/integrations/__init__.py`
- `backend/app/integrations/base.py` — UploadGuard framework (scan->protect->validate->approved copy)
- `backend/app/integrations/registry.py` — Per-platform policies (WhatsApp/Telegram/Gmail/IG/FB/X/LinkedIn/browser)
- `backend/app/main.py` — FastAPI entrypoint; mounts all routers, CORS, error handlers, startup/shutdown
- `backend/app/services/__init__.py`
- `backend/app/services/privacy_settings_service.py` — PII-as-sensitive toggle (persisted in DB meta)
- `backend/app/services/redaction_service.py` — Permanent black-box redaction (non-recoverable)
- `backend/app/services/risk_scoring_service.py` — Stage 2: weighted 0-100 score + HIGH/MEDIUM/LOW
- `backend/app/services/sensitive_content_detector.py` — Stage 1: detection + OCR-keyword (military/restricted/govt/employee)
- `backend/app/services/upload_decision_engine.py` — Orchestrator: BLOCK / ALLOW_REDACTED_ONLY / ALLOW
- `backend/pytest.ini`
- `backend/requirements-optional.txt`
- `backend/requirements.txt`
- `backend/tests/__init__.py`
- `backend/tests/test_api.py`
- `backend/tests/test_blur.py`
- `backend/tests/test_crypto.py`
- `backend/tests/test_database.py`
- `backend/tests/test_pii.py`
- `backend/tests/test_pipeline.py`
- `backend/tests/test_protection.py`
- `backend/tests/test_risk.py`

## frontend

- `frontend/electron/main.js` — Electron shell: spawns backend, loads dist, tray + preload
- `frontend/electron/package.json`
- `frontend/electron/preload.js`
- `frontend/electron/resources/icon-256.png`
- `frontend/electron/resources/icon-512.png`
- `frontend/electron/resources/icon.icns`
- `frontend/electron/resources/icon.ico`
- `frontend/electron/resources/icon.png`
- `frontend/electron/resources/icon.svg`
- `frontend/electron/tray.js`
- `frontend/index.html`
- `frontend/package.json`
- `frontend/public/favicon.svg`
- `frontend/public/icon.png`
- `frontend/src/App.tsx` — Dashboard shell + tabs (Smart Upload/Manual/Camera/History/Settings)
- `frontend/src/api/client.ts` — Typed API client (scan/protect/risk/privacy/protection)
- `frontend/src/components/CameraView.tsx`
- `frontend/src/components/Dropzone.tsx`
- `frontend/src/components/HistoryTable.tsx`
- `frontend/src/components/ProtectionBadge.tsx`
- `frontend/src/components/RiskNotice.tsx` — Risk score/category/threats banner
- `frontend/src/components/RiskReport.tsx`
- `frontend/src/components/SettingsPanel.tsx` — Privacy settings (PII toggle)
- `frontend/src/components/SmartUpload.tsx` — Risk-assessment flow with decision-aware upload buttons
- `frontend/src/hooks/useScan.ts`
- `frontend/src/main.tsx`
- `frontend/src/styles/theme.css`
- `frontend/tsconfig.json`
- `frontend/vite.config.ts`

## ai_models

- `ai_models/README.md`
- `ai_models/configs/thresholds.yaml`
- `ai_models/download_models.py`
- `ai_models/training/datasets/.gitkeep`
- `ai_models/training/label_studio_config.xml`
- `ai_models/training/prepare_dataset.py`
- `ai_models/training/train_yolo.py`

## database

- `database/backup/.gitkeep`
- `database/schema.sql`
- `database/seed.sql`

## installer

- `installer/linux/appimage.yml`
- `installer/linux/securesight.desktop`
- `installer/macos/entitlements.plist`
- `installer/macos/notarize.js`
- `installer/service/securesight.service`
- `installer/service/windows_service.md`
- `installer/windows/electron-builder.yml`
- `installer/windows/securesight.nsi`

## scripts

- `scripts/bootstrap.ps1`
- `scripts/bootstrap.sh`
- `scripts/build_all.sh`
- `scripts/build_desktop.sh`
- `scripts/build_frontend.sh`
- `scripts/install.sh`
- `scripts/package_installers.sh`
- `scripts/run.sh`
- `scripts/smoke_test.sh`

## docs

- `docs/API.md`
- `docs/ARCHITECTURE.md`
- `docs/CAMERA.md`
- `docs/DEPLOY.md`
- `docs/INSTALL.md`
- `docs/RISK_ENGINE.md`
- `docs/SECURITY.md`
- `docs/STRUCTURE.md`
- `docs/TESTING.md`

## samples

- `samples/sample_detected.png`
- `samples/sample_input.png`
- `samples/sample_protected.png`

## .github

- `.github/workflows/ci.yml`
- `.github/workflows/release.yml`

## .editorconfig

- `.editorconfig`

## .gitignore

- `.gitignore`

## CHANGELOG.md

- `CHANGELOG.md`

## LICENSE

- `LICENSE`

## NOTICE.md

- `NOTICE.md`

## README.md

- `README.md`

## pyproject.toml

- `pyproject.toml`
