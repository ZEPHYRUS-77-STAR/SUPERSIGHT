# Changelog

## 0.1.0
- AI pipeline: faces, objects/weapons, NSFW, document/ID, sensitive-text PII.
- Region-only blur (OpenCV + optional SAM masks).
- FastAPI backend: scan/protect/preview/history/audit/protection/camera/upload/updates.
- Camera subsystem: HDR capture, software flash, video w/ periodic scan, live scan.
- Upload guard: per-platform scan-before-attach (no app injection).
- Encrypted SQLite store; consent-based, owner-recoverable Protection Mode.
- React/TypeScript dashboard; Electron shell with tray.
- Installer (Win/mac/Linux), build scripts, CI/release workflows.
