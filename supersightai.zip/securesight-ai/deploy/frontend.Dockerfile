# Multi-stage: build the v2 SPA, serve via nginx with /api proxied to the api service.
FROM node:20-alpine AS build
WORKDIR /app
COPY frontend-v2/package.json frontend-v2/package-lock.json* ./
RUN npm install
COPY frontend-v2/ ./
RUN npm run build

FROM nginx:1.27-alpine
COPY deploy/nginx/nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /app/dist /usr/share/nginx/html
EXPOSE 80
