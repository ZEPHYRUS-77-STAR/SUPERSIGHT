# SecureSight AI — Deployment Guide

Four ways to run, from local to public to fully offline.

## 1. Docker Compose (self-hosted, recommended)
```bash
cp deploy/.env.prod.example deploy/.env.prod
# edit secrets; generate JWT_SECRET:
python -c "import secrets;print(secrets.token_urlsafe(48))"
docker compose -f deploy/docker-compose.prod.yml --env-file deploy/.env.prod up --build -d
```
Services: `db` (Postgres), `redis`, `api` (FastAPI/gunicorn, runs `alembic upgrade head`),
`web` (nginx serving the built SPA + proxying `/api`). Open `http://SERVER_IP:8080`.
First admin is created from `FIRST_ADMIN_EMAIL/PASSWORD`.

### HTTPS
- **Caddy (automatic Let's Encrypt):** point a domain at the host, set `DOMAIN`,
  run `caddy run --config deploy/caddy/Caddyfile` in front of the stack.
- **Cloud LB / Cloudflare:** terminate TLS upstream; nginx stays on :80 internally.

## 2. Cloud platforms
- **Render:** push the repo → New > Blueprint → `deploy/cloud/render.yaml`
  (provisions API + web + managed Postgres + Redis; HTTPS automatic).
- **Fly.io:** see header of `deploy/cloud/fly.toml` (launch, attach Postgres/Redis,
  set secrets, `fly deploy`).
- **Railway:** `deploy/cloud/railway.json` (add Postgres + Redis plugins; set
  `JWT_SECRET`, `FIRST_ADMIN_PASSWORD`).

> Public deployment requires *you* to run the deploy under your own account — these
> files make it one command, but the hosting + domain are yours.

## 3. Offline desktop app
See `desktop-v2/README.md` — an installable app (Electron) that bundles the API on
the **SQLite** fallback so it runs with **no internet, no Postgres, no Docker**.
Local OCR / PII / detection / redaction, CPU or GPU.

## 4. One-click installer
`desktop-v2` builds a signed installer via electron-builder (NSIS on Windows,
dmg/AppImage on macOS/Linux). The installer: installs deps, configures the DB,
detects GPU/CUDA (CPU fallback), creates a desktop shortcut, and auto-starts —
no terminal required. See `desktop-v2/installer/`.

## Production checklist
- Strong `JWT_SECRET` + `POSTGRES_PASSWORD`; rotate `FIRST_ADMIN_PASSWORD` after first login.
- Put TLS in front (Caddy/LB); never expose Postgres publicly.
- Back up the `pgdata` and `storage` volumes.
- Set `API_WORKERS` to ~2×vCPU; raise `client_max_body_size` if needed.
- Install `backend-v2/requirements-ml.txt` on a GPU host for full detection accuracy.
