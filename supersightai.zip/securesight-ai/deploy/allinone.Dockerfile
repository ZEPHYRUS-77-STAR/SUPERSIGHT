# Single-image deploy: build the SPA, then run FastAPI which serves BOTH the API
# (/api) and the built SPA (/). One service, one URL, no CORS headaches.
# Build context = repo root.

# ---- stage 1: build the React frontend (vite only; skips tsc to avoid type-fail) ----
FROM node:20-alpine AS web
WORKDIR /web
COPY frontend-v2/package.json frontend-v2/package-lock.json* ./
RUN npm install
COPY frontend-v2/ ./
# same-origin API: leave VITE_API_BASE empty so the SPA calls /api on its own host
RUN npx vite build

# ---- stage 2: python backend + bundled frontend ----
FROM python:3.11-slim
ENV PYTHONUNBUFFERED=1 FRONTEND_DIR=/app/frontend_dist
WORKDIR /app
RUN apt-get update && apt-get install -y --no-install-recommends \
    libpq5 libgl1 libglib2.0-0 && rm -rf /var/lib/apt/lists/*
COPY backend-v2/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY backend-v2/ /app/
COPY --from=web /web/dist /app/frontend_dist
EXPOSE 8088
# migrate, then serve. $PORT is provided by most PaaS; default 8088 locally.
CMD ["sh", "-c", "alembic upgrade head && gunicorn app.main:app -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:${PORT:-8088} --workers ${API_WORKERS:-2} --timeout 120"]
