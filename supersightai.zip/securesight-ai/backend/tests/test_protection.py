import time
import pytest
from app.core import protection


def test_activate_and_owner_override(tmp_path, monkeypatch):
    # isolate DB
    from app.core import config
    monkeypatch.setattr(config.settings, "data_dir", tmp_path)
    monkeypatch.setattr(config.settings, "_Settings__dict__", {}, raising=False)
    import app.db.database as dbmod
    dbmod._db = None
    monkeypatch.setattr(config.settings.__class__, "db_path",
                        property(lambda s: tmp_path / "t.db"))
    monkeypatch.setattr(config.settings.__class__, "key_path",
                        property(lambda s: tmp_path / "k.bin"))

    st = protection.activate("1d", "secretpass")
    assert st["active"] is True and st["has_recovery"] is True

    with pytest.raises(PermissionError):
        protection.deactivate("wrongpass")

    st2 = protection.deactivate("secretpass")
    assert st2["active"] is False


def test_custom_duration_validation():
    with pytest.raises(ValueError):
        protection.activate("custom", "secretpass", custom_seconds=0)
