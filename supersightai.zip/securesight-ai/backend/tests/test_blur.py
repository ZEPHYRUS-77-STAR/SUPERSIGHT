import numpy as np
from app.ai.blur import apply_region_blur
from app.ai.types import Detection


def _img():
    return np.random.randint(0, 255, (200, 300, 3), dtype=np.uint8)


def test_region_blur_only_touches_region():
    img = _img()
    det = Detection("face", 0.9, (50, 40, 60, 60), source="test")
    out = apply_region_blur(img, [det], method="gaussian", strength=21, pad_frac=0.0)
    # pixels far outside the box are unchanged
    assert np.array_equal(img[0:10, 0:10], out[0:10, 0:10])
    # pixels inside the box changed
    assert not np.array_equal(img[50:100, 50:100], out[50:100, 50:100])


def test_no_detections_returns_identical():
    img = _img()
    out = apply_region_blur(img, [], method="gaussian", strength=21)
    assert np.array_equal(img, out)


def test_category_filter():
    img = _img()
    dets = [Detection("face", 0.9, (10, 10, 40, 40)),
            Detection("person", 0.9, (100, 100, 40, 40))]
    out = apply_region_blur(img, dets, categories={"face"}, pad_frac=0.0)
    # person region untouched, face region changed
    assert np.array_equal(img[100:140, 100:140], out[100:140, 100:140])
    assert not np.array_equal(img[10:50, 10:50], out[10:50, 10:50])
