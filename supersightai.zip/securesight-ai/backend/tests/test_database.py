from app.db.database import Database


def test_scan_and_history(tmp_path, monkeypatch):
    from app.core import config
    monkeypatch.setattr(config.settings.__class__, "key_path",
                        property(lambda s: tmp_path / "k.bin"))
    db = Database(tmp_path / "t.db")
    sid = db.add_scan("img.jpg", "high", 2, {"detections": [{"category": "pan"}]})
    assert sid > 0
    rows = db.recent_scans()
    assert rows and rows[0]["risk"] == "high"
    assert rows[0]["detail"]["detections"][0]["category"] == "pan"


def test_protection_state(tmp_path, monkeypatch):
    from app.core import config
    monkeypatch.setattr(config.settings.__class__, "key_path",
                        property(lambda s: tmp_path / "k2.bin"))
    db = Database(tmp_path / "t2.db")
    db.set_protection(active=1, started=1.0, expires=2.0)
    p = db.get_protection()
    assert p["active"] == 1 and p["expires"] == 2.0
