"""API smoke tests via FastAPI TestClient. Requires fastapi + httpx installed."""
import io
import numpy as np
import cv2
import pytest

try:
    from fastapi.testclient import TestClient
    from app.main import app
    _client = TestClient(app)
except Exception:  # deps not installed -> skip cleanly
    _client = None

pytestmark = pytest.mark.skipif(_client is None, reason="fastapi/httpx not installed")


def _png_bytes():
    img = np.full((200, 320, 3), 240, np.uint8)
    cv2.putText(img, "ABCDE1234F", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
    return cv2.imencode(".png", img)[1].tobytes()


def test_health():
    r = _client.get("/api/health")
    assert r.status_code == 200 and "backends" in r.json()


def test_scan_endpoint():
    files = {"file": ("t.png", io.BytesIO(_png_bytes()), "image/png")}
    r = _client.post("/api/scan", files=files)
    assert r.status_code == 200
    assert r.json()["risk"] in {"low", "medium", "high", "critical"}


def test_protection_flow():
    r = _client.post("/api/protection/activate",
                     json={"duration": "1d", "recovery_passphrase": "secretpass"})
    assert r.status_code == 200 and r.json()["active"] is True
    bad = _client.post("/api/protection/deactivate",
                       json={"recovery_passphrase": "nope"})
    assert bad.status_code == 403
    ok = _client.post("/api/protection/deactivate",
                      json={"recovery_passphrase": "secretpass"})
    assert ok.status_code == 200 and ok.json()["active"] is False
