from app.ai import pii


def test_aadhaar_valid_verhoeff():
    hits = pii.classify_text("My number is 2341 7650 0399")  # placeholder
    cats = {h["category"] for h in hits}
    assert "aadhaar" in cats


def test_pan_format():
    hits = pii.classify_text("PAN: ABCDE1234F")
    assert any(h["category"] == "pan" for h in hits)


def test_email_and_phone():
    hits = pii.classify_text("reach me at a@b.com or +91 9876543210")
    cats = {h["category"] for h in hits}
    assert "pii_text" in cats


def test_luhn_card():
    # 4111 1111 1111 1111 is a Luhn-valid test card
    hits = pii.classify_text("card 4111 1111 1111 1111")
    assert any(h["category"] == "bank_document" for h in hits)


def test_clean_text_no_pii():
    assert not pii.has_pii("just a normal sentence about cats")
