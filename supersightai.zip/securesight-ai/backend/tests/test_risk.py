import numpy as np
import cv2
import pytest

from app.services import risk_scoring_service as rss
from app.services import redaction_service
from app.ai.types import Detection


def _det(cat, box=(10, 10, 60, 30)):
    return Detection(cat, 0.9, box, source="test")


def test_classify_bands():
    assert rss.classify(85) == "HIGH"
    assert rss.classify(55) == "MEDIUM"
    assert rss.classify(20) == "LOW"


def test_single_weapon_is_high(monkeypatch):
    monkeypatch.setattr(rss.privacy_settings_service, "treat_pii_as_sensitive", lambda: False)
    a = rss.score_detections([_det("weapon")])
    assert a.score >= 70 and a.category == "HIGH"


def test_single_face_is_low(monkeypatch):
    monkeypatch.setattr(rss.privacy_settings_service, "treat_pii_as_sensitive", lambda: False)
    a = rss.score_detections([_det("face")])
    assert a.score < 40 and a.category == "LOW"


def test_pii_toggle_changes_score(monkeypatch):
    monkeypatch.setattr(rss.privacy_settings_service, "treat_pii_as_sensitive", lambda: False)
    off = rss.score_detections([_det("pii_text")])
    monkeypatch.setattr(rss.privacy_settings_service, "treat_pii_as_sensitive", lambda: True)
    on = rss.score_detections([_det("pii_text")])
    assert off.score == 0 and on.score == 20


def test_black_box_is_solid_black():
    img = np.random.randint(60, 255, (120, 200, 3), dtype=np.uint8)
    det = _det("aadhaar", (20, 20, 80, 40))
    out, cats = redaction_service.apply_black_box(img, [det], use_mask=False, pad_frac=0.0)
    region = out[20:60, 20:100]
    assert (region == 0).all()        # permanent, non-recoverable
    assert "aadhaar" in cats


def test_aggregation_multiple(monkeypatch):
    monkeypatch.setattr(rss.privacy_settings_service, "treat_pii_as_sensitive", lambda: False)
    a = rss.score_detections([_det("face"), _det("signature")])
    # top 40 + 0.3*15 = 44.5 -> 45 -> MEDIUM
    assert a.category == "MEDIUM"
