from pathlib import Path
from app.core.crypto import Cipher, hash_passphrase, verify_passphrase


def test_roundtrip(tmp_path):
    c = Cipher(tmp_path / "k.bin")
    data = b"sensitive bytes \x00\x01"
    assert c.decrypt(c.encrypt(data)) == data


def test_str_roundtrip(tmp_path):
    c = Cipher(tmp_path / "k.bin")
    assert c.decrypt_str(c.encrypt_str("hello")) == "hello"


def test_passphrase():
    salt, h = hash_passphrase("correct horse")
    assert verify_passphrase("correct horse", salt, h)
    assert not verify_passphrase("wrong", salt, h)
