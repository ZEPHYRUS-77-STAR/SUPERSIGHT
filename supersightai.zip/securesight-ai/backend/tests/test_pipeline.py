import numpy as np
import cv2
from app.ai.pipeline import Pipeline
from app.ai.types import RiskLevel


def _id_image():
    img = np.full((300, 520, 3), 245, np.uint8)
    cv2.putText(img, "PAN ABCDE1234F", (20, 150),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 0), 2)
    return img


def test_scan_returns_valid_result():
    res = Pipeline.get().scan(_id_image())
    assert res.width == 520 and res.height == 300
    assert res.risk in set(RiskLevel)
    assert isinstance(res.detections, list)


def test_protect_is_region_only():
    img = _id_image()
    pipe = Pipeline.get()
    res = pipe.scan(img)
    out = pipe.protect(img, res)
    if res.detections:
        frac = (np.abs(img.astype(int) - out.astype(int)).sum(2) > 10).mean()
        assert 0 < frac < 0.6  # only regions changed, never the whole image
    else:
        assert np.array_equal(img, out)


def test_backends_report():
    b = Pipeline.get().backends()
    assert "face" in b and "ocr" in b and "document" in b
