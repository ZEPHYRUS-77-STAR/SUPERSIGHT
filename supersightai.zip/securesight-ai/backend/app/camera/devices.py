"""Camera device enumeration and selection (OpenCV backend).

Probes indices 0..N and reports which open successfully, with their default
resolution. Works cross-platform via OpenCV's VideoCapture.
"""
from __future__ import annotations

import cv2


def list_devices(max_index: int = 5) -> list[dict]:
    found: list[dict] = []
    for idx in range(max_index):
        cap = cv2.VideoCapture(idx)
        if cap is not None and cap.isOpened():
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            found.append({"index": idx, "width": w, "height": h,
                          "facing": "front" if idx == 0 else "rear/external"})
        if cap is not None:
            cap.release()
    return found


def open_device(index: int = 0, width: int | None = None, height: int | None = None):
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"cannot open camera index {index}")
    if width:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    if height:
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    return cap
