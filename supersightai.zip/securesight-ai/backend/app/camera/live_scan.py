"""Real-time live detection: yields annotated frames + detections from the camera.

Used by the desktop/live preview to draw boxes and surface warnings as the user
points the camera, before anything is saved.
"""
from __future__ import annotations

from typing import Iterator

import numpy as np

from . import devices
from ..ai.pipeline import Pipeline
from ..ai.blur import annotate


def live_frames(device: int = 0, scan_every: int = 5,
                max_frames: int = 0) -> Iterator[tuple[np.ndarray, list[dict]]]:
    """Generator yielding (annotated_frame_bgr, detections_as_dicts).

    Scans every `scan_every` frames to stay real-time; reuses the last result on
    intermediate frames. Caller is responsible for displaying/encoding frames.
    """
    cap = devices.open_device(device)
    pipe = Pipeline.get()
    last = None
    i = 0
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if i % scan_every == 0:
                last = pipe.scan(frame)
            dets = last.detections if last else []
            yield annotate(frame, dets), [d.to_dict() for d in dets]
            i += 1
            if max_frames and i >= max_frames:
                break
    finally:
        cap.release()
