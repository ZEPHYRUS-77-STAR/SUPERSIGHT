"""Still capture with HDR (exposure fusion), software low-light 'flash', and an
AI scan gate: an image is only written to the gallery after the pipeline scans it.

HDR uses OpenCV's Mertens exposure fusion across bracketed frames (real HDR).
'Flash' is an honest software low-light boost for webcams whose hardware torch is
not controllable cross-platform.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from . import devices
from ..ai.pipeline import Pipeline
from ..core import logging as audit_log


@dataclass
class CaptureResult:
    saved: bool
    path: str | None
    risk: str
    regions: int
    warning: str | None
    blurred: bool


def _grab(cap, n: int = 1) -> list[np.ndarray]:
    frames = []
    for _ in range(n):
        ok, frame = cap.read()
        if ok and frame is not None:
            frames.append(frame)
    if not frames:
        raise RuntimeError("camera returned no frames")
    return frames


def _hdr(frames: list[np.ndarray]) -> np.ndarray:
    if len(frames) < 2:
        return frames[0]
    merge = cv2.createMergeMertens()
    fused = merge.process(frames)                 # float 0..1
    return np.clip(fused * 255, 0, 255).astype("uint8")


def _flash(image: np.ndarray, strength: float = 0.35) -> np.ndarray:
    # software low-light boost: gamma + brightness lift
    inv = 1.0 / (1.0 + strength)
    lut = np.array([((i / 255.0) ** inv) * 255 for i in range(256)]).astype("uint8")
    boosted = cv2.LUT(image, lut)
    return cv2.convertScaleAbs(boosted, alpha=1.0 + strength * 0.4, beta=10)


def capture_still(out_dir: str, *, device: int = 0, hdr: bool = False,
                  flash: bool = False, auto_blur: bool = True,
                  filename: str | None = None) -> CaptureResult:
    """Capture, AI-scan, optionally region-blur, then save. Save is gated on scan."""
    cap = devices.open_device(device)
    try:
        frames = _grab(cap, 3 if hdr else 1)
    finally:
        cap.release()

    image = _hdr(frames) if hdr else frames[0]
    if flash:
        image = _flash(image)

    pipe = Pipeline.get()
    result = pipe.scan(image)
    blurred = False
    if auto_blur and result.detections:
        image = pipe.protect(image, result)
        blurred = True

    out = Path(out_dir).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    name = filename or f"securesight_{int(__import__('time').time())}.jpg"
    path = out / name
    cv2.imwrite(str(path), image)
    audit_log.info("camera_capture", risk=result.risk.value,
                   regions=len(result.detections), blurred=blurred)
    return CaptureResult(True, str(path), result.risk.value,
                         len(result.detections), result.to_dict()["warning"], blurred)
