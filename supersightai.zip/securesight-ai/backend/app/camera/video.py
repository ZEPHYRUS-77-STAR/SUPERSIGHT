"""Video recording with periodic AI scanning.

Records to an .mp4/.avi while sampling frames every `scan_every` frames through the
pipeline; risky moments are logged. Recording stops on duration or stop flag.
"""
from __future__ import annotations

import threading
import time
from pathlib import Path

import cv2

from . import devices
from ..ai.pipeline import Pipeline
from ..core import logging as audit_log


class VideoRecorder:
    def __init__(self, out_path: str, device: int = 0, fps: int = 20,
                 scan_every: int = 30):
        self.out_path = str(Path(out_path).expanduser())
        self.device = device
        self.fps = fps
        self.scan_every = scan_every
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.risk_events: list[dict] = []

    def start(self, max_seconds: int = 0) -> None:
        self._thread = threading.Thread(target=self._run, args=(max_seconds,), daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _run(self, max_seconds: int) -> None:
        cap = devices.open_device(self.device)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or 640
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or 480
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(self.out_path, fourcc, self.fps, (w, h))
        pipe = Pipeline.get()
        start = time.time()
        i = 0
        try:
            while not self._stop.is_set():
                ok, frame = cap.read()
                if not ok:
                    break
                writer.write(frame)
                if i % self.scan_every == 0:
                    res = pipe.scan(frame)
                    if res.detections:
                        ev = {"t": round(time.time() - start, 2),
                              "risk": res.risk.value, "regions": len(res.detections)}
                        self.risk_events.append(ev)
                        audit_log.warn("video_risk_frame", **ev)
                i += 1
                if max_seconds and (time.time() - start) >= max_seconds:
                    break
        finally:
            cap.release()
            writer.release()
            audit_log.info("video_recorded", path=self.out_path,
                           risk_events=len(self.risk_events))
