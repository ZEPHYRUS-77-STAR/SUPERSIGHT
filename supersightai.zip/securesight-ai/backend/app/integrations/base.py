"""Upload-guard framework.

SAFETY MODEL: SecureSight AI does NOT hook into, automate, or intercept other
apps (WhatsApp, Gmail, Instagram, ...). That would require injecting into software
the user did not consent to modify. Instead, each "platform" here is a *policy*:
constraints (max size, allowed formats, recommended handling) plus a guard that
scans an image, blurs sensitive regions, validates it against the platform's
limits, and writes an APPROVED copy the user can then share themselves (e.g. via
the OS share sheet / file picker). The user stays in control of the actual send.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import cv2

from ..ai.pipeline import Pipeline
from ..core import logging as audit_log


@dataclass
class PlatformPolicy:
    name: str
    max_bytes: int
    allowed_formats: tuple[str, ...] = ("jpg", "jpeg", "png")
    # categories to always blur for this platform before sharing
    force_blur: tuple[str, ...] = ("aadhaar", "pan", "passport", "driving_licence",
                                   "bank_document", "signature", "pii_text", "nsfw")
    note: str = ""


@dataclass
class GuardResult:
    platform: str
    approved: bool
    output_path: str | None
    risk: str
    regions: int
    blurred_categories: list[str]
    reasons: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return self.__dict__


class UploadGuard:
    """Scan -> protect -> validate -> write approved copy for a given platform."""

    def __init__(self, policy: PlatformPolicy):
        self.policy = policy

    def prepare(self, image_path: str, out_dir: str | None = None) -> GuardResult:
        src = Path(image_path).expanduser()
        if not src.exists():
            return GuardResult(self.policy.name, False, None, "unknown", 0, [],
                               ["source file not found"])
        img = cv2.imread(str(src))
        if img is None:
            return GuardResult(self.policy.name, False, None, "unknown", 0, [],
                               ["unreadable image"])

        pipe = Pipeline.get()
        result = pipe.scan(img)
        present = {d.category for d in result.detections}
        to_blur = present.intersection(self.policy.force_blur)

        reasons: list[str] = []
        out_img = img
        if to_blur:
            out_img = pipe.protect(img, result, categories=to_blur)
            reasons.append(f"blurred: {', '.join(sorted(to_blur))}")

        out_dir_p = Path(out_dir).expanduser() if out_dir else src.parent / "securesight_approved"
        out_dir_p.mkdir(parents=True, exist_ok=True)
        out_path = out_dir_p / f"{src.stem}__{self.policy.name}.jpg"
        cv2.imwrite(str(out_path), out_img)

        size = out_path.stat().st_size
        approved = True
        if size > self.policy.max_bytes:
            approved = False
            reasons.append(f"exceeds {self.policy.name} size limit "
                           f"({size} > {self.policy.max_bytes} bytes)")

        # block share only if a CRITICAL identity doc remains unblurrable
        if result.risk.value == "critical" and not to_blur:
            approved = False
            reasons.append("critical content detected but no blurrable region matched")

        audit_log.info("upload_guard", platform=self.policy.name,
                       risk=result.risk.value, approved=approved,
                       blurred=len(to_blur))
        return GuardResult(self.policy.name, approved,
                           str(out_path) if approved else None,
                           result.risk.value, len(result.detections),
                           sorted(to_blur), reasons)
