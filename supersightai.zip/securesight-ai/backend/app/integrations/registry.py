"""Per-platform policies + a registry to look them up by name."""
from __future__ import annotations

from .base import PlatformPolicy, UploadGuard

MB = 1024 * 1024

POLICIES: dict[str, PlatformPolicy] = {
    "whatsapp":  PlatformPolicy("whatsapp", 16 * MB,
                                note="WhatsApp compresses images; share the approved copy."),
    "telegram":  PlatformPolicy("telegram", 2048 * MB),
    "gmail":     PlatformPolicy("gmail", 25 * MB),
    "instagram": PlatformPolicy("instagram", 30 * MB, allowed_formats=("jpg", "jpeg")),
    "facebook":  PlatformPolicy("facebook", 30 * MB),
    "x":         PlatformPolicy("x", 5 * MB),
    "linkedin":  PlatformPolicy("linkedin", 8 * MB),
    "browser":   PlatformPolicy("browser", 50 * MB,
                                note="Generic guard for web upload forms."),
    "generic":   PlatformPolicy("generic", 50 * MB),
}


def get_guard(platform: str) -> UploadGuard:
    policy = POLICIES.get(platform.lower(), POLICIES["generic"])
    return UploadGuard(policy)


def list_platforms() -> list[dict]:
    return [{"name": p.name, "max_bytes": p.max_bytes,
             "allowed_formats": list(p.allowed_formats), "note": p.note}
            for p in POLICIES.values()]
