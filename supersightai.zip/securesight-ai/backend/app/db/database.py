"""Local encrypted SQLite layer.

Stores scan history, audit logs and protection-mode state. Sensitive columns
(detection detail, file paths) are encrypted at rest with AES-256-GCM via the
device-local key. No image bytes are stored in the DB.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any

from ..core.config import settings
from ..core.crypto import Cipher
from .models import SCHEMA_SQL



class Database:
    def __init__(self, path: Path | None = None):
        self.path = Path(path or settings.db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._cipher = Cipher(settings.key_path)
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA_SQL)
        self._conn.execute("INSERT OR IGNORE INTO protection (id, active) VALUES (1, 0)")
        self._conn.commit()

    # ---- scans ----
    def add_scan(self, source: str, risk: str, n_regions: int, detail: dict) -> int:
        enc = self._cipher.encrypt(json.dumps(detail).encode())
        cur = self._conn.execute(
            "INSERT INTO scans (ts, source, risk, n_regions, detail_enc) VALUES (?,?,?,?,?)",
            (time.time(), source, risk, n_regions, enc))
        self._conn.commit()
        return cur.lastrowid

    def recent_scans(self, limit: int = 50) -> list[dict]:
        rows = self._conn.execute(
            "SELECT id, ts, source, risk, n_regions, detail_enc FROM scans "
            "ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        out = []
        for r in rows:
            detail = json.loads(self._cipher.decrypt(r["detail_enc"]).decode()) if r["detail_enc"] else {}
            out.append({"id": r["id"], "ts": r["ts"], "source": r["source"],
                        "risk": r["risk"], "n_regions": r["n_regions"], "detail": detail})
        return out

    # ---- audit ----
    def log(self, event: str, detail: dict | None = None) -> None:
        enc = self._cipher.encrypt(json.dumps(detail or {}).encode())
        self._conn.execute("INSERT INTO audit (ts, event, detail_enc) VALUES (?,?,?)",
                           (time.time(), event, enc))
        self._conn.commit()

    def audit_log(self, limit: int = 100) -> list[dict]:
        rows = self._conn.execute(
            "SELECT ts, event, detail_enc FROM audit ORDER BY id DESC LIMIT ?",
            (limit,)).fetchall()
        return [{"ts": r["ts"], "event": r["event"],
                 "detail": json.loads(self._cipher.decrypt(r["detail_enc"]).decode())}
                for r in rows]

    # ---- protection state ----
    def get_protection(self) -> dict:
        r = self._conn.execute("SELECT * FROM protection WHERE id=1").fetchone()
        return dict(r) if r else {}

    def set_protection(self, **fields: Any) -> None:
        if not fields:
            return
        cols = ", ".join(f"{k}=?" for k in fields)
        self._conn.execute(f"UPDATE protection SET {cols} WHERE id=1", tuple(fields.values()))
        self._conn.commit()

    # ---- key/value settings ----
    def get_meta(self, key: str, default: str | None = None) -> str | None:
        r = self._conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

    def set_meta(self, key: str, value: str) -> None:
        self._conn.execute("INSERT INTO meta (key, value) VALUES (?,?) "
                           "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()


_db: Database | None = None


def get_db() -> Database:
    global _db
    if _db is None:
        _db = Database()
    return _db
