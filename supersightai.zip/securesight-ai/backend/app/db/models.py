"""Canonical schema + lightweight row dataclasses for the local store.

The encrypted SQLite tables are created in database.py; this module documents the
schema in one place and provides typed wrappers used by services and tests.
"""
from __future__ import annotations

from dataclasses import dataclass

SCHEMA_VERSION = 1

# Single source of truth for the schema (mirrored by database.py / migrations).
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    source TEXT,
    risk TEXT NOT NULL,
    n_regions INTEGER NOT NULL,
    detail_enc BLOB
);
CREATE TABLE IF NOT EXISTS audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    event TEXT NOT NULL,
    detail_enc BLOB
);
CREATE TABLE IF NOT EXISTS protection (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    active INTEGER NOT NULL DEFAULT 0,
    started REAL,
    expires REAL,
    recovery_salt TEXT,
    recovery_hash TEXT
);
CREATE TABLE IF NOT EXISTS known_faces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    encoding_enc BLOB NOT NULL
);
CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


@dataclass
class ScanRow:
    id: int
    ts: float
    source: str
    risk: str
    n_regions: int
    detail: dict


@dataclass
class AuditRow:
    ts: float
    event: str
    detail: dict


@dataclass
class ProtectionRow:
    active: bool
    started: float | None
    expires: float | None
    has_recovery: bool
