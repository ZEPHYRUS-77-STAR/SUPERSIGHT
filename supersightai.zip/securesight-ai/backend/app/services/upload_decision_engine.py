"""Smart Upload Control Engine — final orchestrator.

Implements the spec pipeline:

  Image -> Stage1 detect -> if NO sensitive content: ALLOW_UPLOAD (skip scoring +
  redaction) -> else: risk scoring -> classification -> black-box redaction (if
  required) -> upload decision -> frontend notification payload.

Decisions:
  HIGH   (70-100): BLOCK_UPLOAD, no override, image redacted (permanent black box).
  MEDIUM (40-69):  ALLOW_UPLOAD_OF_REDACTED_VERSION_ONLY, auto black-box redaction.
  LOW    (0-39):   ALLOW_UPLOAD, optional privacy redaction offered.

No image containing sensitive content bypasses scoring.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np

from ..core.config import settings
from ..core import logging as audit_log
from . import sensitive_content_detector, risk_scoring_service, redaction_service
from . import privacy_settings_service

# decision constants
ALLOW_UPLOAD = "ALLOW_UPLOAD"
ALLOW_REDACTED_ONLY = "ALLOW_UPLOAD_OF_REDACTED_VERSION_ONLY"
BLOCK_UPLOAD = "BLOCK_UPLOAD"

_NOTICE = {
    "HIGH": "Upload Blocked. High-Risk Sensitive Content Detected.",
    "MEDIUM": "Sensitive content detected. Secure version generated.",
    "LOW": "Low-Risk Image Detected.",
    "NONE": "No sensitive content detected.",
}


@dataclass
class UploadDecision:
    sensitive: bool
    risk_score: int
    risk_category: str            # HIGH | MEDIUM | LOW | NONE
    decision: str                 # ALLOW_UPLOAD | ALLOW_REDACTED_ONLY | BLOCK_UPLOAD
    override_allowed: bool
    threats: list[str]
    reason: str
    notification: str
    redacted: bool
    redacted_path: str | None
    optional_privacy: bool        # LOW-risk optional redaction offered
    detections: list[dict] = field(default_factory=list)
    contributions: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = self.__dict__.copy()
        return d


def _save_redacted(image: np.ndarray, tag: str) -> str:
    settings.quarantine_dir.mkdir(parents=True, exist_ok=True)
    path = settings.quarantine_dir / f"redacted_{tag}_{int(time.time()*1000)}.jpg"
    cv2.imwrite(str(path), image)
    return str(path)


def assess(image: np.ndarray, *, save_redacted: bool = True) -> UploadDecision:
    # ---- STAGE 1: detection (conditional gate) ----
    sensitive, detections = sensitive_content_detector.detect(image)
    det_dicts = [d.to_dict() for d in detections]

    if not sensitive:
        audit_log.info("risk_assess", category="NONE", decision=ALLOW_UPLOAD)
        return UploadDecision(
            sensitive=False, risk_score=0, risk_category="NONE",
            decision=ALLOW_UPLOAD, override_allowed=True, threats=[],
            reason="No sensitive content detected.", notification=_NOTICE["NONE"],
            redacted=False, redacted_path=None, optional_privacy=False,
            detections=det_dicts, contributions=[])

    # ---- STAGE 2: scoring + classification ----
    risk = risk_scoring_service.score_detections(detections)
    include_pii = privacy_settings_service.treat_pii_as_sensitive()

    redacted_path = None
    redacted_flag = False
    threats = risk.threats

    if risk.category == "HIGH":
        red_img, red_cats = redaction_service.apply_black_box(
            image, detections, include_pii=include_pii)
        redacted_flag = bool(red_cats)
        if save_redacted and redacted_flag:
            redacted_path = _save_redacted(red_img, "high")
        decision = BLOCK_UPLOAD
        override = False
        reason = ("High-risk sensitive content (" + ", ".join(threats) +
                  ") — upload, sharing, cloud sync and social posting are blocked.")
        optional_privacy = False

    elif risk.category == "MEDIUM":
        red_img, red_cats = redaction_service.apply_black_box(
            image, detections, include_pii=include_pii)
        redacted_flag = bool(red_cats)
        redacted_path = _save_redacted(red_img, "medium") if (save_redacted and redacted_flag) else None
        decision = ALLOW_REDACTED_ONLY
        override = False
        reason = ("Sensitive regions detected (" + ", ".join(threats) +
                  ") — only the auto-redacted secure version may be uploaded.")
        optional_privacy = False

    else:  # LOW
        decision = ALLOW_UPLOAD
        override = True
        reason = "Low-risk image. Optional privacy redaction available."
        optional_privacy = True

    audit_log.info("risk_assess", score=risk.score, category=risk.category,
                   decision=decision, threats=threats)
    return UploadDecision(
        sensitive=True, risk_score=risk.score, risk_category=risk.category,
        decision=decision, override_allowed=override, threats=threats,
        reason=reason, notification=_NOTICE[risk.category], redacted=redacted_flag,
        redacted_path=redacted_path, optional_privacy=optional_privacy,
        detections=det_dicts, contributions=risk.contributions)


def assess_file(path: str, *, save_redacted: bool = True) -> UploadDecision:
    img = cv2.imread(path)
    if img is None:
        raise ValueError(f"unreadable image: {path}")
    return assess(img, save_redacted=save_redacted)
