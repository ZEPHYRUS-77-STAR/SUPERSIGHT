"""STAGE 1 — lightweight sensitive-content detection.

Runs the existing detector stack (YOLOv8, PaddleOCR/Tesseract, MediaPipe, NudeNet,
face_recognition + OpenCV fallbacks) via the shared Pipeline, then augments it with
keyword-based detection of military / restricted-area / government-secret /
employee-ID content from OCR text — categories that have no off-the-shelf model.

Returns (has_sensitive, detections). If has_sensitive is False the caller must
short-circuit and allow normal upload (skip scoring + redaction) per spec.
"""
from __future__ import annotations

import re

import numpy as np

from ..ai.pipeline import Pipeline
from ..ai.types import Detection

# categories that, if present, mean "sensitive content exists"
SENSITIVE_CATEGORIES = {
    "face", "child_face", "aadhaar", "pan", "passport", "driving_licence",
    "bank_document", "signature", "pii_text", "screenshot_pii", "weapon",
    "firearm", "nsfw", "military_sensitive", "restricted_area",
    "government_secret", "employee_id", "sensitive_ocr",
}
# 'document' and 'person' are contextual, not sensitive on their own.

_KEYWORDS = {
    "military_sensitive": [
        "ministry of defence", "ministry of defense", "indian army", "indian navy",
        "indian air force", "armed forces", "defence intelligence", "for official use only",
        "fouo", "classified - defence", "military intelligence",
    ],
    "restricted_area": [
        "restricted area", "prohibited area", "no photography", "photography prohibited",
        "military zone", "high security zone", "entry restricted",
    ],
    "government_secret": [
        "top secret", "classified", "secret//", "confidential//", "official secrets",
        "not for circulation", "eyes only",
    ],
    "employee_id": [
        "employee id", "employee no", "emp id", "emp no", "staff id",
        "employee identification", "id card", "company id",
    ],
    "sensitive_ocr": [
        "confidential", "private and confidential", "do not share", "internal use only",
        "password", "otp", "pin number",
    ],
}


def _keyword_detections(pipe: Pipeline, image: np.ndarray) -> list[Detection]:
    """Scan OCR words for sensitive keywords; emit Detections at their boxes."""
    words = pipe.ocr.read_words(image)
    if not words:
        return []
    full = " ".join(w[0] for w in words).lower()
    # bounding region of all text (used when a phrase spans multiple words)
    xs = [b[0] for _, b, _ in words]; ys = [b[1] for _, b, _ in words]
    xe = [b[0] + b[2] for _, b, _ in words]; ye = [b[1] + b[3] for _, b, _ in words]
    text_region = (min(xs), min(ys), max(xe) - min(xs), max(ye) - min(ys))

    dets: list[Detection] = []
    for category, phrases in _KEYWORDS.items():
        for phrase in phrases:
            if phrase in full:
                # try to locate a single word of the phrase for a tighter box
                token = phrase.split()[0]
                box = text_region
                for text, b, _ in words:
                    if token in text.lower():
                        box = b
                        break
                dets.append(Detection(category, 0.8, box, source="ocr_keyword",
                                      text=phrase))
                break  # one detection per category is enough
    return dets


def detect(image: np.ndarray) -> tuple[bool, list[Detection]]:
    pipe = Pipeline.get()
    detections = list(pipe.scan(image).detections)
    detections += _keyword_detections(pipe, image)
    # de-duplicate identical category+box
    seen = set()
    unique: list[Detection] = []
    for d in detections:
        key = (d.category, d.box)
        if key not in seen:
            seen.add(key)
            unique.append(d)
    has_sensitive = any(d.category in SENSITIVE_CATEGORIES for d in unique)
    return has_sensitive, unique
