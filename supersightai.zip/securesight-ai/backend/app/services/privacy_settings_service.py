"""User privacy settings (persisted in the encrypted local DB meta table).

The only setting required by the Smart Risk system is whether PII detections
(names, phones, emails, addresses, account identifiers) count toward the risk
score. Default is DISABLED per spec: PII is still shown to the user but does not
raise the score unless the user opts in.
"""
from __future__ import annotations

from ..db.database import get_db

_KEY_PII = "treat_pii_as_sensitive"


def get_settings() -> dict:
    raw = get_db().get_meta(_KEY_PII, "0")
    return {"treat_pii_as_sensitive": raw == "1"}


def set_treat_pii_as_sensitive(enabled: bool) -> dict:
    get_db().set_meta(_KEY_PII, "1" if enabled else "0")
    return get_settings()


def treat_pii_as_sensitive() -> bool:
    return get_settings()["treat_pii_as_sensitive"]
