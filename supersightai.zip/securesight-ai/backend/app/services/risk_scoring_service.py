"""STAGE 2 — Risk Scoring Engine.

Aggregates detected categories into a 0–100 risk score using the weight table from
the spec, then classifies HIGH (70–100) / MEDIUM (40–69) / LOW (0–39).

PII categories only contribute when the user has enabled
'Treat PII as Sensitive Content' (default off): they are always reported but only
counted in the score when enabled.

Aggregation: the score is driven by the single strongest signal (its full weight),
plus a diminishing contribution from the remaining signals, capped at 100:
    score = min(100, max_weight + 0.3 * sum(other_weights))
This keeps one firearm (90) HIGH and a lone face (15) LOW, while letting multiple
moderate signals add up (face 15 + signature 40 -> MEDIUM).
"""
from __future__ import annotations

from dataclasses import dataclass

from ..ai.types import Detection
from . import privacy_settings_service

# category -> weight (spec). driving_licence not given an explicit weight in the
# spec; treated like passport (70) as a full identity document.
WEIGHTS: dict[str, int] = {
    "military_sensitive": 100,
    "government_secret": 100,
    "restricted_area": 95,
    "weapon": 90,
    "firearm": 90,
    "aadhaar": 80,
    "pan": 75,
    "bank_document": 75,
    "nsfw": 70,
    "passport": 70,
    "driving_licence": 70,
    "sensitive_ocr": 60,
    "signature": 40,
    "employee_id": 40,
    "pii_text": 20,        # PII — counted only if enabled
    "screenshot_pii": 20,  # PII — counted only if enabled
    "face": 15,
    "child_face": 15,
}
PII_CATEGORIES = {"pii_text", "screenshot_pii"}

HIGH_MIN = 70
MEDIUM_MIN = 40


@dataclass
class RiskAssessment:
    score: int
    category: str               # HIGH | MEDIUM | LOW
    threats: list[str]          # distinct sensitive categories detected
    contributions: list[dict]   # per-category weight breakdown (incl. ignored PII)
    pii_counted: bool

    def to_dict(self) -> dict:
        return {"score": self.score, "category": self.category,
                "threats": self.threats, "contributions": self.contributions,
                "pii_counted": self.pii_counted}


def classify(score: int) -> str:
    if score >= HIGH_MIN:
        return "HIGH"
    if score >= MEDIUM_MIN:
        return "MEDIUM"
    return "LOW"


def score_detections(detections: list[Detection]) -> RiskAssessment:
    pii_counted = privacy_settings_service.treat_pii_as_sensitive()

    # one weight per distinct category (strongest instance), record breakdown
    per_category: dict[str, int] = {}
    for d in detections:
        w = WEIGHTS.get(d.category)
        if w is None:
            continue
        per_category[d.category] = max(per_category.get(d.category, 0), w)

    contributions: list[dict] = []
    counted_weights: list[int] = []
    for cat, w in sorted(per_category.items(), key=lambda kv: -kv[1]):
        is_pii = cat in PII_CATEGORIES
        counts = (not is_pii) or pii_counted
        contributions.append({"category": cat, "weight": w,
                              "counted": counts, "pii": is_pii})
        if counts:
            counted_weights.append(w)

    if not counted_weights:
        score = 0
    else:
        counted_weights.sort(reverse=True)
        top = counted_weights[0]
        rest = sum(counted_weights[1:])
        score = min(100, int(round(top + 0.3 * rest)))

    threats = [c["category"] for c in contributions if c["counted"]]
    return RiskAssessment(score, classify(score), threats, contributions, pii_counted)
