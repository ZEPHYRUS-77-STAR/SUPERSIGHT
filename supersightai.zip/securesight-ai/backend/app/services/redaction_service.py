"""Redaction Engine — permanent BLACK BOX redaction (non-recoverable).

Unlike the reversible blur engine, this paints solid black over each sensitive
region so the underlying pixels are destroyed and cannot be reconstructed. Exact
coordinates come from the detectors (YOLOv8 / OCR / face) and are optionally
tightened with a SAM mask; the redaction itself is always a solid fill (black box)
to guarantee the content is gone.
"""
from __future__ import annotations

import cv2
import numpy as np

from ..ai.types import Detection
from ..ai.segment import Segmenter
from ..core.config import settings

# Everything sensitive enough to carry a weight gets redacted. 'document'/'person'
# are contextual and not redacted on their own.
from .risk_scoring_service import WEIGHTS, PII_CATEGORIES

_segmenter: Segmenter | None = None


def _get_segmenter() -> Segmenter:
    global _segmenter
    if _segmenter is None:
        _segmenter = Segmenter()
    return _segmenter


def _pad(box, frac, shape):
    x, y, w, h = box
    px, py = int(w * frac), int(h * frac)
    H, W = shape[:2]
    nx, ny = max(0, x - px), max(0, y - py)
    return nx, ny, min(W - nx, w + 2 * px), min(H - ny, h + 2 * py)


def redactable_categories(include_pii: bool) -> set[str]:
    cats = {c for c in WEIGHTS if c not in PII_CATEGORIES}
    if include_pii:
        cats |= PII_CATEGORIES
    return cats


def apply_black_box(image: np.ndarray, detections: list[Detection], *,
                    include_pii: bool = True, use_mask: bool = True,
                    pad_frac: float | None = None) -> tuple[np.ndarray, list[str]]:
    """Return (redacted_image, list_of_redacted_categories).

    Solid black fill over each sensitive region. If SAM is available and use_mask
    is True the black fill follows the object mask inside the (padded) box;
    otherwise the whole box is filled black. Either way the result is permanent.
    """
    out = image.copy()
    pad = settings.region_padding if pad_frac is None else pad_frac
    cats = redactable_categories(include_pii)
    seg = _get_segmenter() if use_mask else None
    redacted: list[str] = []

    for d in detections:
        if d.category not in cats:
            continue
        x, y, w, h = _pad(d.box, pad, image.shape)
        if w <= 0 or h <= 0:
            continue
        if seg is not None and seg.available:
            mask = seg.mask_for_box(image, (x, y, w, h))
            out[mask] = (0, 0, 0)
        else:
            cv2.rectangle(out, (x, y), (x + w, y + h), (0, 0, 0), thickness=-1)
        redacted.append(d.category)

    return out, sorted(set(redacted))
