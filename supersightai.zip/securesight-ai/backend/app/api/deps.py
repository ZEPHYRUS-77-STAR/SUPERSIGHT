"""Shared API dependencies: upload size guard and simple in-process rate limiting.

Keeps the local service resilient. Limits are conservative defaults suitable for a
single-user desktop deployment.
"""
from __future__ import annotations

import time
from collections import deque

from fastapi import HTTPException, Request

MAX_UPLOAD_BYTES = 25 * 1024 * 1024     # 25 MB per image
RATE_MAX = 60                            # requests
RATE_WINDOW = 60.0                       # seconds

_hits: dict[str, deque] = {}


async def enforce_size(request: Request) -> None:
    cl = request.headers.get("content-length")
    if cl and int(cl) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="image exceeds 25 MB limit")


async def rate_limit(request: Request) -> None:
    key = request.client.host if request.client else "local"
    now = time.time()
    dq = _hits.setdefault(key, deque())
    while dq and now - dq[0] > RATE_WINDOW:
        dq.popleft()
    if len(dq) >= RATE_MAX:
        raise HTTPException(status_code=429, detail="rate limit exceeded")
    dq.append(now)


def validate_image_bytes(data: bytes) -> None:
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="image exceeds 25 MB limit")
    if not data:
        raise HTTPException(status_code=400, detail="empty upload")
