"""Pydantic request/response models."""
from __future__ import annotations

from pydantic import BaseModel, Field


class ActivateRequest(BaseModel):
    duration: str = Field(..., description="1d|7d|15d|30d|90d|custom")
    recovery_passphrase: str = Field(..., min_length=6)
    custom_seconds: int | None = None


class DeactivateRequest(BaseModel):
    recovery_passphrase: str


class ProtectOptions(BaseModel):
    categories: list[str] | None = Field(
        None, description="If set, blur only these categories; else blur all detected.")
    method: str | None = Field(None, description="gaussian|pixelate|fill")
