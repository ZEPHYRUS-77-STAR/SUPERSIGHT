"""REST endpoints for SecureSight AI.

All processing is local. Endpoints accept image bytes, return JSON or the
protected image bytes — nothing is persisted to any remote server.
"""
from __future__ import annotations

import io

import cv2
import numpy as np
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse, StreamingResponse

from ..ai.pipeline import Pipeline
from ..core import protection
from ..core.config import APP_NAME, APP_VERSION, settings
from ..db.database import get_db
from .schemas import ActivateRequest, DeactivateRequest
from .deps import rate_limit, enforce_size, validate_image_bytes

router = APIRouter(dependencies=[Depends(rate_limit), Depends(enforce_size)])


def _read_upload(data: bytes) -> np.ndarray:
    validate_image_bytes(data)
    arr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(status_code=400, detail="unreadable image")
    return img


def _encode(img: np.ndarray, fmt: str = ".jpg") -> bytes:
    ok, buf = cv2.imencode(fmt, img)
    if not ok:
        raise HTTPException(status_code=500, detail="encode failed")
    return buf.tobytes()


@router.get("/health")
def health():
    return {"app": APP_NAME, "version": APP_VERSION,
            "backends": Pipeline.get().backends(),
            "online_mode": settings.online_mode}


@router.post("/scan")
async def scan(file: UploadFile = File(...)):
    img = _read_upload(await file.read())
    res = Pipeline.get().scan(img)
    get_db().add_scan(file.filename or "upload", res.risk.value,
                      len(res.detections), res.to_dict())
    return JSONResponse(res.to_dict())


@router.post("/protect")
async def protect(file: UploadFile = File(...), categories: str = Form(""),
                  method: str = Form("")):
    img = _read_upload(await file.read())
    pipe = Pipeline.get()
    res = pipe.scan(img)
    cats = {c.strip() for c in categories.split(",") if c.strip()} or None
    if method:
        settings.blur_method = method
    protected = pipe.protect(img, res, categories=cats)
    get_db().add_scan(file.filename or "upload", res.risk.value,
                      len(res.detections), res.to_dict())
    headers = {"X-SecureSight-Risk": res.risk.value,
               "X-SecureSight-Regions": str(len(res.detections))}
    return StreamingResponse(io.BytesIO(_encode(protected)),
                             media_type="image/jpeg", headers=headers)


@router.post("/preview")
async def preview(file: UploadFile = File(...)):
    img = _read_upload(await file.read())
    pipe = Pipeline.get()
    res = pipe.scan(img)
    return StreamingResponse(io.BytesIO(_encode(pipe.preview(img, res))),
                             media_type="image/jpeg")


@router.get("/history")
def history(limit: int = 50):
    return {"scans": get_db().recent_scans(limit)}


@router.get("/audit")
def audit(limit: int = 100):
    return {"audit": get_db().audit_log(limit)}


# ---- protection mode (consent-based, owner-recoverable) ----
@router.get("/protection/status")
def protection_status():
    return protection.status()


@router.post("/protection/activate")
def protection_activate(body: ActivateRequest):
    try:
        return protection.activate(body.duration, body.recovery_passphrase,
                                   body.custom_seconds)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/protection/deactivate")
def protection_deactivate(body: DeactivateRequest):
    try:
        return protection.deactivate(body.recovery_passphrase)
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
