"""Smart Risk Assessment & Upload Control endpoints + privacy settings."""
from __future__ import annotations

import io

import cv2
import numpy as np
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse

from ..services import upload_decision_engine as engine
from ..services import privacy_settings_service, redaction_service
from ..services import sensitive_content_detector
from .deps import rate_limit, enforce_size

router = APIRouter(tags=["risk"], dependencies=[Depends(rate_limit), Depends(enforce_size)])


def _read(data: bytes) -> np.ndarray:
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(status_code=400, detail="unreadable image")
    return img


@router.post("/risk/assess")
async def assess(file: UploadFile = File(...)):
    """Full pipeline: detect -> (conditional) score -> redact -> upload decision."""
    img = _read(await file.read())
    decision = engine.assess(img, save_redacted=True)
    return decision.to_dict()


@router.post("/risk/redacted")
async def redacted(file: UploadFile = File(...)):
    """Return the permanent black-box redacted JPEG for the given image.

    Used by MEDIUM-risk (secure version) and by LOW-risk optional privacy. For
    HIGH risk the redacted copy is for local record only — upload stays blocked.
    """
    img = _read(await file.read())
    sensitive, dets = sensitive_content_detector.detect(img)
    include_pii = privacy_settings_service.treat_pii_as_sensitive()
    red, cats = redaction_service.apply_black_box(img, dets, include_pii=include_pii)
    ok, buf = cv2.imencode(".jpg", red)
    if not ok:
        raise HTTPException(status_code=500, detail="encode failed")
    return StreamingResponse(io.BytesIO(buf.tobytes()), media_type="image/jpeg",
                             headers={"X-SecureSight-Redacted": ",".join(cats)})


@router.get("/privacy/settings")
def get_privacy_settings():
    return privacy_settings_service.get_settings()


@router.post("/privacy/settings")
def set_privacy_settings(body: dict):
    enabled = bool(body.get("treat_pii_as_sensitive", False))
    return privacy_settings_service.set_treat_pii_as_sensitive(enabled)
