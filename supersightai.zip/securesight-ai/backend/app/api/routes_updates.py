"""Update endpoints (online mode, opt-in) + model availability report."""
from __future__ import annotations

from fastapi import APIRouter

from ..ai import model_registry
from ..core import updater

router = APIRouter(prefix="/updates", tags=["updates"])


@router.get("/models")
def models():
    return model_registry.report()


@router.post("/check")
def check(body: dict | None = None):
    force = bool((body or {}).get("force", False))
    return updater.check_and_update(force=force).to_dict()
