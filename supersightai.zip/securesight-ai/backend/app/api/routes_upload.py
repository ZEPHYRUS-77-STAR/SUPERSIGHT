"""Upload-guard endpoints: scan-before-attach for each target platform."""
from __future__ import annotations

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from ..integrations import registry

router = APIRouter(prefix="/upload", tags=["upload"])


@router.get("/platforms")
def platforms():
    return {"platforms": registry.list_platforms()}


@router.post("/guard")
def guard(body: dict):
    """Prepare a single local image for a platform (by path)."""
    path = body.get("image_path")
    platform = body.get("platform", "generic")
    if not path:
        raise HTTPException(status_code=400, detail="image_path required")
    res = registry.get_guard(platform).prepare(path, body.get("out_dir"))
    return res.to_dict()


@router.post("/guard/batch")
def guard_batch(body: dict):
    """Prepare multiple local images for a platform."""
    paths = body.get("image_paths") or []
    platform = body.get("platform", "generic")
    if not paths:
        raise HTTPException(status_code=400, detail="image_paths (list) required")
    g = registry.get_guard(platform)
    return {"results": [g.prepare(p, body.get("out_dir")).to_dict() for p in paths]}
