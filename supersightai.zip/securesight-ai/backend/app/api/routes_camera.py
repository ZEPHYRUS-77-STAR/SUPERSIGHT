"""Camera endpoints: list devices, capture a still (AI-gated), record video."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ..camera import devices as cam_devices
from ..camera.capture import capture_still
from ..camera.video import VideoRecorder

router = APIRouter(prefix="/camera", tags=["camera"])
_recorders: dict[str, VideoRecorder] = {}


@router.get("/devices")
def devices():
    return {"devices": cam_devices.list_devices()}


@router.post("/capture")
def capture(body: dict):
    out_dir = body.get("out_dir")
    if not out_dir:
        raise HTTPException(status_code=400, detail="out_dir required")
    try:
        res = capture_still(out_dir, device=int(body.get("device", 0)),
                            hdr=bool(body.get("hdr", False)),
                            flash=bool(body.get("flash", False)),
                            auto_blur=bool(body.get("auto_blur", True)),
                            filename=body.get("filename"))
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    return res.__dict__


@router.post("/record/start")
def record_start(body: dict):
    out_path = body.get("out_path")
    if not out_path:
        raise HTTPException(status_code=400, detail="out_path required")
    rec = VideoRecorder(out_path, device=int(body.get("device", 0)),
                        fps=int(body.get("fps", 20)),
                        scan_every=int(body.get("scan_every", 30)))
    rec.start(max_seconds=int(body.get("max_seconds", 0)))
    _recorders[out_path] = rec
    return {"recording": out_path, "status": "started"}


@router.post("/record/stop")
def record_stop(body: dict):
    out_path = body.get("out_path")
    rec = _recorders.pop(out_path, None)
    if not rec:
        raise HTTPException(status_code=404, detail="no active recording for that path")
    rec.stop()
    return {"recording": out_path, "status": "stopped",
            "risk_events": rec.risk_events}
