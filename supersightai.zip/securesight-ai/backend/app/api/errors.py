"""Unified exception handlers for the API."""
from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from ..core import logging as audit_log


def install_handlers(app: FastAPI) -> None:
    @app.exception_handler(ValueError)
    async def _value_error(request: Request, exc: ValueError):
        return JSONResponse(status_code=400, content={"error": str(exc)})

    @app.exception_handler(PermissionError)
    async def _perm_error(request: Request, exc: PermissionError):
        return JSONResponse(status_code=403, content={"error": str(exc)})

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception):
        audit_log.error("unhandled_exception", path=str(request.url.path),
                        error=type(exc).__name__)
        return JSONResponse(status_code=500, content={"error": "internal error"})
