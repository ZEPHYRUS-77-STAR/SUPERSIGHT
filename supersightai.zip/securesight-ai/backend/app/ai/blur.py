"""Region-only blur engine (OpenCV).

CRITICAL RULE: never blur the whole image. We blur only the union of the
detected sensitive regions (optionally tightened by a SAM mask), padded slightly,
and composite them back over the untouched original.
"""
from __future__ import annotations

import cv2
import numpy as np

from .types import Detection
from .segment import Segmenter


def _pad_box(box, pad_frac, shape):
    x, y, w, h = box
    px, py = int(w * pad_frac), int(h * pad_frac)
    H, W = shape[:2]
    nx, ny = max(0, x - px), max(0, y - py)
    nw, nh = min(W - nx, w + 2 * px), min(H - ny, h + 2 * py)
    return nx, ny, nw, nh


def _blur_patch(patch: np.ndarray, method: str, strength: int) -> np.ndarray:
    if patch.size == 0:
        return patch
    if method == "pixelate":
        h, w = patch.shape[:2]
        blocks = max(1, strength)
        small = cv2.resize(patch, (max(1, w // blocks), max(1, h // blocks)),
                           interpolation=cv2.INTER_LINEAR)
        return cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)
    if method == "fill":
        return np.zeros_like(patch)
    k = strength if strength % 2 == 1 else strength + 1
    return cv2.GaussianBlur(patch, (k, k), 0)


def apply_region_blur(image: np.ndarray, detections: list[Detection], *,
                      method: str = "gaussian", strength: int = 35,
                      pad_frac: float = 0.06,
                      segmenter: Segmenter | None = None,
                      categories: set[str] | None = None) -> np.ndarray:
    """Return a copy of `image` with only the sensitive regions blurred."""
    out = image.copy()
    for d in detections:
        if categories is not None and d.category not in categories:
            continue
        x, y, w, h = _pad_box(d.box, pad_frac, image.shape)
        if w <= 0 or h <= 0:
            continue
        roi = out[y:y + h, x:x + w]
        blurred = _blur_patch(roi, method, strength)
        if segmenter is not None and segmenter.available:
            mask = segmenter.mask_for_box(image, (x, y, w, h))[y:y + h, x:x + w]
            m3 = np.repeat(mask[:, :, None], 3, axis=2)
            out[y:y + h, x:x + w] = np.where(m3, blurred, roi)
        else:
            out[y:y + h, x:x + w] = blurred
    return out


def annotate(image: np.ndarray, detections: list[Detection]) -> np.ndarray:
    """Draw labelled boxes for the UI preview (does not modify pixels under boxes)."""
    colors = {"low": (120, 200, 120), "medium": (60, 180, 255),
              "high": (40, 90, 240), "critical": (40, 40, 220)}
    out = image.copy()
    for d in detections:
        x, y, w, h = d.box
        c = colors.get(d.risk.value, (200, 200, 200))
        cv2.rectangle(out, (x, y), (x + w, y + h), c, 2)
        label = f"{d.category} {d.confidence:.2f}"
        cv2.putText(out, label, (x, max(12, y - 6)), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, c, 1, cv2.LINE_AA)
    return out
