"""Sensitive-text (PII) classification from OCR output.

Pure-python, no heavy deps. Recognises Indian government IDs and common PII,
with checksum validation where defined (Aadhaar = Verhoeff, PAN = format).
"""
from __future__ import annotations

import re

# --- patterns ---
_AADHAAR = re.compile(r"\b(\d{4}\s?\d{4}\s?\d{4})\b")
_PAN = re.compile(r"\b([A-Z]{5}\d{4}[A-Z])\b")
_PASSPORT = re.compile(r"\b([A-PR-WYa-pr-wy][1-9]\d\s?\d{4}[1-9])\b")
_DL = re.compile(r"\b([A-Z]{2}[ -]?\d{2}[ -]?\d{4}[ -]?\d{7})\b")
_EMAIL = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
_PHONE = re.compile(r"(?<!\d)(?:\+?91[\-\s]?)?[6-9]\d{9}(?!\d)")
_CARD = re.compile(r"\b(?:\d[ -]?){13,16}\b")
_IFSC = re.compile(r"\b([A-Z]{4}0[A-Z0-9]{6})\b")
_ACCOUNT = re.compile(r"\b\d{9,18}\b")

_DOC_KEYWORDS = {
    "aadhaar": ["aadhaar", "uidai", "आधार", "govt of india", "government of india"],
    "pan": ["income tax", "permanent account", "pan"],
    "passport": ["passport", "republic of india", "type p"],
    "driving_licence": ["driving licence", "driving license", "transport", "dl no"],
    "bank_document": ["ifsc", "account no", "a/c no", "branch", "statement", "balance"],
}

# Verhoeff tables for Aadhaar checksum
_D = [[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],
      [3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],
      [6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],
      [9,8,7,6,5,4,3,2,1,0]]
_P = [[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],
      [8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],
      [2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]]


def _verhoeff_ok(num: str) -> bool:
    c = 0
    for i, d in enumerate(reversed(num)):
        if not d.isdigit():
            return False
        c = _D[c][_P[i % 8][int(d)]]
    return c == 0


def _luhn_ok(num: str) -> bool:
    digits = [int(d) for d in num if d.isdigit()]
    if not 13 <= len(digits) <= 19:
        return False
    s, alt = 0, False
    for d in reversed(digits):
        if alt:
            d *= 2
            if d > 9:
                d -= 9
        s += d
        alt = not alt
    return s % 10 == 0


def classify_text(text: str) -> list[dict]:
    """Return list of {category, value, confidence} found in a text blob."""
    found: list[dict] = []
    low = text.lower()

    for m in _AADHAAR.finditer(text):
        digits = re.sub(r"\s", "", m.group(1))
        conf = 0.97 if _verhoeff_ok(digits) else 0.55
        found.append({"category": "aadhaar", "value": m.group(1), "confidence": conf})
    for m in _PAN.finditer(text):
        found.append({"category": "pan", "value": m.group(1), "confidence": 0.9})
    for m in _PASSPORT.finditer(text):
        found.append({"category": "passport", "value": m.group(1), "confidence": 0.7})
    for m in _DL.finditer(text):
        found.append({"category": "driving_licence", "value": m.group(1), "confidence": 0.7})
    for m in _CARD.finditer(text):
        if _luhn_ok(m.group(0)):
            found.append({"category": "bank_document", "value": m.group(0), "confidence": 0.85})
    for m in _IFSC.finditer(text):
        found.append({"category": "bank_document", "value": m.group(1), "confidence": 0.8})
    for m in _EMAIL.finditer(text):
        found.append({"category": "pii_text", "value": m.group(0), "confidence": 0.6})
    for m in _PHONE.finditer(text):
        found.append({"category": "pii_text", "value": m.group(0), "confidence": 0.65})

    # keyword-based document type boost
    for cat, kws in _DOC_KEYWORDS.items():
        if any(k in low for k in kws):
            found.append({"category": cat, "value": "(keyword match)", "confidence": 0.5})
    return found


def has_pii(text: str) -> bool:
    return bool(classify_text(text))
