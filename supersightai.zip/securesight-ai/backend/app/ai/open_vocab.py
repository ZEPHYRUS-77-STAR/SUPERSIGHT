"""Open-vocabulary prompt configuration for YOLO-World and Grounding DINO.

Both detectors are *zero-shot*: you give them free-text prompts and they localise
matching objects. This module is the single place that defines which prompts we
look for and how each maps back to a SecureSight risk category (so the existing
risk-scoring weights and black-box redaction apply automatically).
"""
from __future__ import annotations

# SecureSight category -> list of natural-language prompts that imply it.
CATEGORY_PROMPTS: dict[str, list[str]] = {
    "firearm": ["a gun", "a handgun", "a pistol", "a rifle", "a firearm", "a shotgun"],
    "weapon": ["a knife", "a sword", "a weapon", "a grenade", "a dagger"],
    "military_sensitive": ["a soldier in uniform", "a military tank", "a missile",
                            "a fighter jet", "a warship", "a military vehicle",
                            "a military base"],
    "restricted_area": ["a no photography sign", "a restricted area sign",
                         "a prohibited area sign"],
    "passport": ["a passport"],
    "aadhaar": ["an aadhaar card"],
    "pan": ["a pan card"],
    "driving_licence": ["a driving license", "a driving licence"],
    "bank_document": ["a credit card", "a bank card", "a cheque", "a debit card"],
    "employee_id": ["an id card", "an employee id badge"],
    "signature": ["a handwritten signature"],
    "face": ["a human face"],
}


def all_prompts() -> list[str]:
    """Flat list of every prompt (the class vocabulary handed to the detectors)."""
    return [p for prompts in CATEGORY_PROMPTS.values() for p in prompts]


def _build_lookup() -> dict[str, str]:
    out: dict[str, str] = {}
    for category, prompts in CATEGORY_PROMPTS.items():
        for p in prompts:
            out[p.lower()] = category
            # also index the prompt without a leading article for fuzzy matches
            stripped = p.lower()
            for art in ("a ", "an ", "the "):
                if stripped.startswith(art):
                    out[stripped[len(art):]] = category
    return out


_LOOKUP = _build_lookup()


def category_for(prompt: str) -> str | None:
    """Map a detected prompt/label back to a SecureSight risk category."""
    key = prompt.strip().lower().rstrip(".")
    if key in _LOOKUP:
        return _LOOKUP[key]
    # token-overlap fallback for detectors that return partial phrases
    for phrase, category in _LOOKUP.items():
        if phrase in key or key in phrase:
            return category
    return None
