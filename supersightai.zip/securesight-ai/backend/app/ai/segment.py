"""Precise pixel masks for detected regions.

Uses Segment Anything (SAM) when available to turn a bounding box into a tight
pixel mask (so blur hugs the object). Falls back to the rectangle itself.
"""
from __future__ import annotations

import numpy as np


class Segmenter:
    def __init__(self, checkpoint: str | None = None, model_type: str = "vit_b"):
        self._predictor = None
        try:
            import torch  # noqa
            from segment_anything import sam_model_registry, SamPredictor
            if checkpoint:
                sam = sam_model_registry[model_type](checkpoint=checkpoint)
                sam.to("cuda" if torch.cuda.is_available() else "cpu")
                self._predictor = SamPredictor(sam)
        except Exception:
            self._predictor = None

    @property
    def available(self) -> bool:
        return self._predictor is not None

    def mask_for_box(self, image: np.ndarray, box: tuple[int, int, int, int]) -> np.ndarray:
        """Return a boolean HxW mask for a box (x,y,w,h)."""
        h, w = image.shape[:2]
        x, y, bw, bh = box
        if self._predictor is None:
            mask = np.zeros((h, w), dtype=bool)
            mask[max(0, y):min(h, y + bh), max(0, x):min(w, x + bw)] = True
            return mask
        self._predictor.set_image(image[:, :, ::-1])  # BGR->RGB
        input_box = np.array([x, y, x + bw, y + bh])
        masks, scores, _ = self._predictor.predict(box=input_box[None, :], multimask_output=False)
        return masks[0].astype(bool)
