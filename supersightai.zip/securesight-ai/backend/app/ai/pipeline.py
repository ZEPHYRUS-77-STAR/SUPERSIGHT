"""SecureSight AI pipeline orchestrator.

Runs all available detectors on an image, aggregates Detections, computes an
overall risk, and produces a protected (region-blurred) version on request.

Designed to be import-light: heavy detectors are lazy and optional. The pipeline
always works with the bundled OpenCV face detector + regex PII.
"""
from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np

from ..core.config import settings
from .types import Detection, RiskLevel, overall_risk
from .detectors.opencv_face import OpenCVFaceDetector
from .detectors.mediapipe_face import MediaPipeFaceDetector
from .detectors.yolo import YoloDetector
from .detectors.nsfw import NsfwDetector
from .detectors.face_match import FaceMatcher
from .detectors.document_id import DocumentDetector
from .detectors.weapon import WeaponDetector
from .detectors.yolo_world import YoloWorldDetector
from .detectors.grounding_dino import GroundingDinoDetector
from .ocr import OCREngine
from .segment import Segmenter
from .blur import apply_region_blur, annotate


@dataclass
class ScanResult:
    width: int
    height: int
    detections: list[Detection]
    risk: RiskLevel
    backends: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "width": self.width,
            "height": self.height,
            "risk": self.risk.value,
            "count": len(self.detections),
            "detections": [d.to_dict() for d in self.detections],
            "backends": self.backends,
            "warning": self._warning(),
        }

    def _warning(self) -> str | None:
        if not self.detections:
            return None
        cats = sorted({d.category for d in self.detections})
        return (f"{len(self.detections)} sensitive region(s) found "
                f"[{self.risk.value.upper()}]: {', '.join(cats)}. "
                "Review before sharing — sensitive areas can be blurred automatically.")


class Pipeline:
    _instance: "Pipeline | None" = None

    def __init__(self):
        s = settings
        self.face_cv = OpenCVFaceDetector(s.face_min_conf)
        self.face_mp = MediaPipeFaceDetector(s.face_min_conf)
        self.yolo = YoloDetector(min_conf=s.object_min_conf)
        self.nsfw = NsfwDetector(s.nsfw_min_conf)
        self.matcher = FaceMatcher()
        self.document = DocumentDetector(s.object_min_conf)
        self.weapon = WeaponDetector()
        self.yolo_world = YoloWorldDetector()
        self.grounding_dino = GroundingDinoDetector()
        self.ocr = OCREngine()
        self.segmenter = Segmenter()

    @classmethod
    def get(cls) -> "Pipeline":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def backends(self) -> dict:
        return {
            "face": self.face_mp.name if self.face_mp.available else self.face_cv.name,
            "objects": self.yolo.name if self.yolo.available else "disabled",
            "nsfw": self.nsfw.name if self.nsfw.available else "disabled",
            "document": self.document.name,
            "weapon": self.weapon.name if self.weapon.available else "disabled",
            "open_vocab_yoloworld": self.yolo_world.name if self.yolo_world.available else "disabled",
            "open_vocab_groundingdino": self.grounding_dino.name if self.grounding_dino.available else "disabled",
            "ocr": self.ocr.backend,
            "segment": "sam" if self.segmenter.available else "bbox",
            "face_match": self.matcher.name if self.matcher.available else "disabled",
        }

    def scan(self, image: np.ndarray) -> ScanResult:
        dets: list[Detection] = []
        # faces: prefer MediaPipe, else Haar
        faces = self.face_mp.detect(image) if self.face_mp.available else self.face_cv.detect(image)
        faces = self.matcher.label(image, faces)
        dets += faces
        # objects / weapons / persons / documents
        dets += self.yolo.detect(image)
        dets += self.document.detect(image)
        dets += self.weapon.detect(image)
        # open-vocabulary zero-shot detection (YOLO-World + Grounding DINO)
        dets += self.yolo_world.detect(image)
        dets += self.grounding_dino.detect(image)
        # nsfw
        dets += self.nsfw.detect(image)
        # sensitive text (IDs, PII, bank docs)
        dets += self.ocr.detect_sensitive_text(image)
        dets = _merge(dets)
        return ScanResult(image.shape[1], image.shape[0], dets,
                          overall_risk(dets), self.backends())

    def protect(self, image: np.ndarray, result: ScanResult | None = None, *,
                categories: set[str] | None = None) -> np.ndarray:
        if result is None:
            result = self.scan(image)
        return apply_region_blur(
            image, result.detections,
            method=settings.blur_method, strength=settings.blur_strength,
            pad_frac=settings.region_padding, segmenter=self.segmenter,
            categories=categories,
        )

    def preview(self, image: np.ndarray, result: ScanResult | None = None) -> np.ndarray:
        if result is None:
            result = self.scan(image)
        return annotate(image, result.detections)


def _merge(dets: list[Detection], iou_thresh: float = 0.55) -> list[Detection]:
    """Drop near-duplicate boxes of the same category, keep highest confidence."""
    kept: list[Detection] = []
    for d in sorted(dets, key=lambda d: -d.confidence):
        dup = False
        for k in kept:
            if k.category == d.category and _iou(d.box, k.box) > iou_thresh:
                dup = True
                break
        if not dup:
            kept.append(d)
    return kept


def _iou(a, b) -> float:
    ax, ay, aw, ah = a; bx, by, bw, bh = b
    x1, y1 = max(ax, bx), max(ay, by)
    x2, y2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    inter = max(0, x2 - x1) * max(0, y2 - y1)
    union = aw * ah + bw * bh - inter
    return inter / union if union else 0.0


def _cli():
    ap = argparse.ArgumentParser(description="SecureSight AI — scan & protect an image")
    ap.add_argument("image")
    ap.add_argument("--out", help="write protected image here")
    ap.add_argument("--preview", help="write annotated preview here")
    args = ap.parse_args()

    img = cv2.imread(args.image)
    if img is None:
        print(f"error: cannot read {args.image}", file=sys.stderr)
        sys.exit(2)

    pipe = Pipeline.get()
    res = pipe.scan(img)
    d = res.to_dict()
    print(f"Backends: {d['backends']}")
    print(f"Risk: {d['risk'].upper()}  Regions: {d['count']}")
    for det in d["detections"]:
        print(f"  - {det['category']:16s} conf={det['confidence']:.2f} "
              f"risk={det['risk']:8s} box={det['box']}")
    if d["warning"]:
        print("\nWARNING:", d["warning"])
    if args.preview:
        cv2.imwrite(args.preview, pipe.preview(img, res))
        print("preview ->", args.preview)
    if args.out:
        cv2.imwrite(args.out, pipe.protect(img, res))
        print("protected ->", args.out)


if __name__ == "__main__":
    _cli()
