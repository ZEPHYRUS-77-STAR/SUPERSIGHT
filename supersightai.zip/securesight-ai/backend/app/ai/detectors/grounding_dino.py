"""Grounding DINO open-vocabulary detector.

Zero-shot text-conditioned detection. Two backends are supported, tried in order:
  1) HuggingFace Transformers (`AutoModelForZeroShotObjectDetection`,
     e.g. "IDEA-Research/grounding-dino-tiny")
  2) the standalone `groundingdino` package (config + checkpoint)
Detections map back to SecureSight risk categories via `open_vocab`.

Optional & offline-capable: once the model is cached locally it runs offline.
Returns an empty list when no backend/weights are present.
"""
from __future__ import annotations

import numpy as np

from ..types import Detection
from .. import open_vocab
from .. import model_registry

# Grounding DINO wants a single "a . b . c ." style caption.
_CAPTION = " . ".join(open_vocab.all_prompts()) + " ."


class GroundingDinoDetector:
    name = "grounding_dino"

    def __init__(self, box_threshold: float = 0.30, text_threshold: float = 0.25,
                 hf_model: str = "IDEA-Research/grounding-dino-tiny"):
        self.box_threshold = box_threshold
        self.text_threshold = text_threshold
        self._backend = None
        self._hf = None
        self._gd = None
        # Backend 1: transformers
        try:
            import torch  # noqa
            from transformers import AutoProcessor, AutoModelForZeroShotObjectDetection
            self._proc = AutoProcessor.from_pretrained(hf_model)
            self._hf = AutoModelForZeroShotObjectDetection.from_pretrained(hf_model)
            self._torch = torch
            self._device = "cuda" if torch.cuda.is_available() else "cpu"
            self._hf.to(self._device)
            self._backend = "transformers"
            return
        except Exception:
            self._hf = None
        # Backend 2: standalone groundingdino (needs cfg + checkpoint)
        try:
            from groundingdino.util.inference import load_model, predict  # noqa
            ckpt = model_registry.resolve("grounding_dino")
            if ckpt is not None:
                self._gd_predict = predict
                self._gd = load_model(
                    str(ckpt.parent / "GroundingDINO_SwinT_OGC.py"), str(ckpt))
                self._backend = "groundingdino"
        except Exception:
            self._gd = None

    @property
    def available(self) -> bool:
        return self._backend is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._backend == "transformers":
            return self._detect_hf(image)
        if self._backend == "groundingdino":
            return self._detect_gd(image)
        return []

    def _detect_hf(self, image: np.ndarray) -> list[Detection]:
        import cv2
        from PIL import Image
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        pil = Image.fromarray(rgb)
        inputs = self._proc(images=pil, text=_CAPTION, return_tensors="pt").to(self._device)
        with self._torch.no_grad():
            outputs = self._hf(**inputs)
        results = self._proc.post_process_grounded_object_detection(
            outputs, inputs.input_ids, box_threshold=self.box_threshold,
            text_threshold=self.text_threshold, target_sizes=[pil.size[::-1]])[0]
        out: list[Detection] = []
        for score, label, box in zip(results["scores"], results["labels"], results["boxes"]):
            category = open_vocab.category_for(str(label))
            if category is None:
                continue
            x1, y1, x2, y2 = (int(v) for v in box.tolist())
            out.append(Detection(category, float(score), (x1, y1, x2 - x1, y2 - y1),
                                 source=self.name, meta={"prompt": str(label)}))
        return out

    def _detect_gd(self, image: np.ndarray) -> list[Detection]:
        import cv2
        h, w = image.shape[:2]
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        boxes, logits, phrases = self._gd_predict(
            model=self._gd, image=rgb, caption=_CAPTION,
            box_threshold=self.box_threshold, text_threshold=self.text_threshold)
        out: list[Detection] = []
        for box, score, phrase in zip(boxes, logits, phrases):
            category = open_vocab.category_for(str(phrase))
            if category is None:
                continue
            cx, cy, bw, bh = box.tolist()       # normalized cx,cy,w,h
            x = int((cx - bw / 2) * w); y = int((cy - bh / 2) * h)
            out.append(Detection(category, float(score),
                                 (x, y, int(bw * w), int(bh * h)),
                                 source=self.name, meta={"prompt": str(phrase)}))
        return out
