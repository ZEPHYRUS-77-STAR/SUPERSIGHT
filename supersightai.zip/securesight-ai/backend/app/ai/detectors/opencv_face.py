"""Face detection via OpenCV Haar cascades — bundled with opencv, always works.

This is the always-on fallback for face detection so the pipeline never depends
on heavy DL weights being present.
"""
from __future__ import annotations

import cv2
import numpy as np

from ..types import Detection

_FRONTAL = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
_PROFILE = cv2.data.haarcascades + "haarcascade_profileface.xml"


class OpenCVFaceDetector:
    name = "opencv_haar"

    def __init__(self, min_conf: float = 0.4):
        self.min_conf = min_conf
        self._frontal = cv2.CascadeClassifier(_FRONTAL)
        self._profile = cv2.CascadeClassifier(_PROFILE)

    def detect(self, image: np.ndarray) -> list[Detection]:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        dets: list[Detection] = []
        for clf in (self._frontal, self._profile):
            if clf.empty():
                continue
            rects = clf.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5,
                                         minSize=(32, 32))
            for (x, y, w, h) in rects:
                # Haar has no probability; use a stable heuristic confidence.
                conf = min(0.95, 0.55 + (w * h) / (image.shape[0] * image.shape[1]))
                if conf < self.min_conf:
                    continue
                dets.append(Detection("face", float(conf), (int(x), int(y), int(w), int(h)),
                                      source=self.name))
        return _dedupe(dets)


def _dedupe(dets: list[Detection], iou_thresh: float = 0.4) -> list[Detection]:
    kept: list[Detection] = []
    for d in sorted(dets, key=lambda d: -d.confidence):
        if all(_iou(d.box, k.box) < iou_thresh for k in kept):
            kept.append(d)
    return kept


def _iou(a, b) -> float:
    ax, ay, aw, ah = a; bx, by, bw, bh = b
    x1, y1 = max(ax, bx), max(ay, by)
    x2, y2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    inter = max(0, x2 - x1) * max(0, y2 - y1)
    union = aw * ah + bw * bh - inter
    return inter / union if union else 0.0
