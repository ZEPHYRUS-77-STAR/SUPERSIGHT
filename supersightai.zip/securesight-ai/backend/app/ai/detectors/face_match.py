"""Identity matching via face_recognition — optional.

Verifies whether detected faces match a local gallery of known encodings
(e.g. the device owner's family) so the UI can label them. Encodings stay local.
"""
from __future__ import annotations

import numpy as np

from ..types import Detection


class FaceMatcher:
    name = "face_recognition"

    def __init__(self, known: dict[str, np.ndarray] | None = None, tolerance: float = 0.6):
        self.tolerance = tolerance
        self.known = known or {}
        self._fr = None
        try:
            import face_recognition  # noqa
            self._fr = face_recognition
        except Exception:
            self._fr = None

    @property
    def available(self) -> bool:
        return self._fr is not None

    def label(self, image: np.ndarray, faces: list[Detection]) -> list[Detection]:
        if self._fr is None or not self.known:
            return faces
        import cv2
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        locs = [(y, x + w, y + h, x) for (x, y, w, h) in (f.box for f in faces)]
        encs = self._fr.face_encodings(rgb, locs)
        names = list(self.known.keys())
        vecs = list(self.known.values())
        for f, enc in zip(faces, encs):
            if not vecs:
                continue
            dists = self._fr.face_distance(vecs, enc)
            i = int(np.argmin(dists))
            if dists[i] <= self.tolerance:
                f.meta["identity"] = names[i]
        return faces
