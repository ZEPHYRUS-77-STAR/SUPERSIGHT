"""Dedicated weapon detector.

Activates a custom YOLO weapon model when its weights are present (resolved via
the model registry). Without weights it returns nothing rather than guessing —
weapon classification is high-stakes and we avoid false positives from heuristics.
"""
from __future__ import annotations

import numpy as np

from ..types import Detection
from .. import model_registry

_WEAPON_LABELS = {"gun", "pistol", "rifle", "knife", "weapon", "firearm", "handgun"}


class WeaponDetector:
    name = "weapon"

    def __init__(self, min_conf: float = 0.45):
        self.min_conf = min_conf
        self._model = None
        weights = model_registry.resolve("yolo_weapon")
        if weights is not None:
            try:
                from ultralytics import YOLO
                self._model = YOLO(str(weights))
            except Exception:
                self._model = None

    @property
    def available(self) -> bool:
        return self._model is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._model is None:
            return []
        out: list[Detection] = []
        for r in self._model.predict(image, conf=self.min_conf, verbose=False):
            names = r.names
            for b in r.boxes:
                label = str(names.get(int(b.cls[0]), "")).lower()
                if label not in _WEAPON_LABELS:
                    continue
                x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
                out.append(Detection("weapon", float(b.conf[0]),
                                     (x1, y1, x2 - x1, y2 - y1), source=self.name,
                                     meta={"label": label}))
        return out
