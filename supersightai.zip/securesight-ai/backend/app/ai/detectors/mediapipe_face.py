"""MediaPipe face detection — optional, higher quality than Haar when present."""
from __future__ import annotations

import numpy as np

from ..types import Detection


class MediaPipeFaceDetector:
    name = "mediapipe"

    def __init__(self, min_conf: float = 0.4):
        self.min_conf = min_conf
        self._fd = None
        try:
            import mediapipe as mp
            self._fd = mp.solutions.face_detection.FaceDetection(
                model_selection=1, min_detection_confidence=min_conf)
        except Exception:
            self._fd = None

    @property
    def available(self) -> bool:
        return self._fd is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._fd is None:
            return []
        import cv2
        h, w = image.shape[:2]
        res = self._fd.process(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        out: list[Detection] = []
        if not res.detections:
            return out
        for d in res.detections:
            score = float(d.score[0]) if d.score else 0.0
            rb = d.location_data.relative_bounding_box
            x, y = int(rb.xmin * w), int(rb.ymin * h)
            bw, bh = int(rb.width * w), int(rb.height * h)
            out.append(Detection("face", score, (max(0, x), max(0, y), bw, bh),
                                 source=self.name))
        return out
