"""YOLOv8 (Ultralytics) detector for person / object / weapon / document.

Optional: activates only if `ultralytics` and a weights file are available.
Maps a subset of COCO classes to SecureSight categories. A custom-trained
document/ID model can be dropped in via the `weights` argument.
"""
from __future__ import annotations

import numpy as np

from ..types import Detection

# COCO class id -> SecureSight category for the classes we care about.
_COCO_MAP = {
    0: "person",
    # weapon-ish proxies present in COCO; a dedicated weapon model is recommended.
    43: "weapon",   # knife
    # documents/IDs are not in COCO -> require a custom model.
}
_WEAPON_NAMES = {"knife", "gun", "pistol", "rifle", "weapon", "firearm"}
_DOC_NAMES = {"document", "id_card", "aadhaar", "pan", "passport", "licence", "license"}


class YoloDetector:
    name = "yolov8"

    def __init__(self, weights: str = "yolov8n.pt", min_conf: float = 0.35):
        self.min_conf = min_conf
        self._model = None
        try:
            from ultralytics import YOLO  # noqa
            self._model = YOLO(weights)
        except Exception:
            self._model = None  # graceful: pipeline skips this detector

    @property
    def available(self) -> bool:
        return self._model is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._model is None:
            return []
        out: list[Detection] = []
        results = self._model.predict(image, conf=self.min_conf, verbose=False)
        for r in results:
            names = r.names
            for b in r.boxes:
                cls = int(b.cls[0]); conf = float(b.conf[0])
                label = str(names.get(cls, cls)).lower()
                cat = self._category(cls, label)
                if cat is None:
                    continue
                x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
                out.append(Detection(cat, conf, (x1, y1, x2 - x1, y2 - y1),
                                     source=self.name, meta={"label": label}))
        return out

    @staticmethod
    def _category(cls: int, label: str) -> str | None:
        if label in _WEAPON_NAMES:
            return "weapon"
        if label in _DOC_NAMES:
            return "document"
        return _COCO_MAP.get(cls)
