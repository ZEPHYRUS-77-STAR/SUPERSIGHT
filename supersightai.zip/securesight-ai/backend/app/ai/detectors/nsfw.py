"""NSFW detection via NudeNet — optional."""
from __future__ import annotations

import numpy as np

from ..types import Detection


class NsfwDetector:
    name = "nudenet"

    def __init__(self, min_conf: float = 0.55):
        self.min_conf = min_conf
        self._det = None
        try:
            from nudenet import NudeDetector
            self._det = NudeDetector()
        except Exception:
            self._det = None

    @property
    def available(self) -> bool:
        return self._det is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._det is None:
            return []
        import cv2, tempfile, os
        tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
        try:
            cv2.imwrite(tmp.name, image)
            results = self._det.detect(tmp.name)
        finally:
            os.unlink(tmp.name)
        out: list[Detection] = []
        explicit = {"FEMALE_BREAST_EXPOSED", "FEMALE_GENITALIA_EXPOSED",
                    "MALE_GENITALIA_EXPOSED", "BUTTOCKS_EXPOSED", "ANUS_EXPOSED"}
        for r in results:
            score = float(r.get("score", 0))
            if r.get("class") in explicit and score >= self.min_conf:
                x, y, w, h = (int(v) for v in r["box"])
                out.append(Detection("nsfw", score, (x, y, w, h), source=self.name,
                                     meta={"label": r.get("class")}))
        return out
