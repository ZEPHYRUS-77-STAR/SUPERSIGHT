"""Dedicated document / ID-card region detector.

Two-stage: (1) a custom YOLO document model if its weights are present (via the
model registry), else (2) a classical fallback that finds large rectangular,
text-dense quadrilaterals (typical of cards/documents) using OpenCV. The fallback
makes the detector useful even before a trained model is supplied.
"""
from __future__ import annotations

import cv2
import numpy as np

from ..types import Detection
from .. import model_registry


class DocumentDetector:
    name = "document_id"

    def __init__(self, min_conf: float = 0.4):
        self.min_conf = min_conf
        self._model = None
        weights = model_registry.resolve("yolo_document")
        if weights is not None:
            try:
                from ultralytics import YOLO
                self._model = YOLO(str(weights))
            except Exception:
                self._model = None

    @property
    def available(self) -> bool:
        return True  # classical fallback always works

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._model is not None:
            return self._detect_model(image)
        return self._detect_classical(image)

    def _detect_model(self, image):
        out = []
        for r in self._model.predict(image, conf=self.min_conf, verbose=False):
            for b in r.boxes:
                x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
                out.append(Detection("document", float(b.conf[0]),
                                     (x1, y1, x2 - x1, y2 - y1), source="yolo_document"))
        return out

    def _detect_classical(self, image):
        h, w = image.shape[:2]
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 60, 180)
        edges = cv2.dilate(edges, np.ones((5, 5), np.uint8), iterations=2)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        out: list[Detection] = []
        img_area = h * w
        for c in contours:
            peri = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, 0.02 * peri, True)
            if len(approx) != 4:
                continue
            x, y, bw, bh = cv2.boundingRect(approx)
            area = bw * bh
            if area < 0.06 * img_area:        # too small to be a card/doc
                continue
            ar = bw / float(bh) if bh else 0
            # ID cards ~1.4-1.8, A4 docs ~0.7-1.5; accept a broad rectangle band
            if not (0.5 <= ar <= 2.2):
                continue
            conf = min(0.7, 0.4 + area / img_area)
            out.append(Detection("document", float(conf), (x, y, bw, bh),
                                 source="opencv_quad"))
        return out
