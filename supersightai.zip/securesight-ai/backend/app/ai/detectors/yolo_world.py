"""YOLO-World open-vocabulary detector (Ultralytics).

Zero-shot: we set the class vocabulary from `open_vocab.CATEGORY_PROMPTS` and the
model localises any of those concepts. Detections are mapped back to SecureSight
risk categories so scoring + black-box redaction apply automatically.

Optional & offline-capable: activates only when `ultralytics` and a YOLO-World
weight file are available; once the weights are cached locally it runs fully
offline. Falls back to silence (empty list) otherwise so the pipeline never breaks.
"""
from __future__ import annotations

import numpy as np

from ..types import Detection
from ..import open_vocab
from .. import model_registry


class YoloWorldDetector:
    name = "yolo_world"

    def __init__(self, min_conf: float = 0.10, weights: str | None = None):
        self.min_conf = min_conf
        self._model = None
        self._prompts = open_vocab.all_prompts()
        # prefer a registered local weight; else let ultralytics resolve a default
        weights = weights or (str(model_registry.resolve("yolo_world") or "")
                              or "yolov8s-worldv2.pt")
        try:
            from ultralytics import YOLOWorld
            self._model = YOLOWorld(weights)
            self._model.set_classes(self._prompts)
        except Exception:
            self._model = None

    @property
    def available(self) -> bool:
        return self._model is not None

    def detect(self, image: np.ndarray) -> list[Detection]:
        if self._model is None:
            return []
        out: list[Detection] = []
        try:
            results = self._model.predict(image, conf=self.min_conf, verbose=False)
        except Exception:
            return []
        for r in results:
            names = r.names
            for b in r.boxes:
                label = str(names.get(int(b.cls[0]), "")).lower()
                category = open_vocab.category_for(label)
                if category is None:
                    continue
                x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
                out.append(Detection(category, float(b.conf[0]),
                                     (x1, y1, x2 - x1, y2 - y1), source=self.name,
                                     meta={"prompt": label}))
        return out
