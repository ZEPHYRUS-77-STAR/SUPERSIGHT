"""OCR layer: PaddleOCR (primary) + Tesseract (backup/validation).

Returns word-level boxes so PII text can be blurred at the region level. If
neither engine is installed the layer returns no text regions but never errors —
the rest of the pipeline keeps working with the visual detectors.
"""
from __future__ import annotations

import numpy as np

from .types import Detection
from . import pii


class OCREngine:
    def __init__(self):
        self._paddle = None
        self._tess = None
        try:
            from paddleocr import PaddleOCR
            self._paddle = PaddleOCR(use_angle_cls=True, lang="en", show_log=False)
        except Exception:
            self._paddle = None
        try:
            import pytesseract  # noqa
            self._tess = pytesseract
        except Exception:
            self._tess = None

    @property
    def backend(self) -> str:
        if self._paddle:
            return "paddleocr"
        if self._tess:
            return "tesseract"
        return "none"

    def read_words(self, image: np.ndarray) -> list[tuple[str, tuple[int, int, int, int], float]]:
        """Return [(text, (x,y,w,h), conf), ...]."""
        if self._paddle is not None:
            return self._read_paddle(image)
        if self._tess is not None:
            return self._read_tess(image)
        return []

    def _read_paddle(self, image):
        out = []
        result = self._paddle.ocr(image, cls=True)
        for page in result or []:
            for line in page or []:
                box, (text, conf) = line
                xs = [p[0] for p in box]; ys = [p[1] for p in box]
                x, y = int(min(xs)), int(min(ys))
                w, h = int(max(xs) - x), int(max(ys) - y)
                out.append((text, (x, y, w, h), float(conf)))
        return out

    def _read_tess(self, image):
        import cv2
        from pytesseract import Output
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        data = self._tess.image_to_data(gray, output_type=Output.DICT)
        out = []
        for i, txt in enumerate(data["text"]):
            if not txt.strip():
                continue
            conf = float(data["conf"][i]) / 100.0 if data["conf"][i] != "-1" else 0.0
            out.append((txt, (data["left"][i], data["top"][i],
                              data["width"][i], data["height"][i]), conf))
        return out

    def detect_sensitive_text(self, image: np.ndarray) -> list[Detection]:
        """Run OCR, classify PII, and emit a Detection per sensitive word/box."""
        words = self.read_words(image)
        if not words:
            return []
        dets: list[Detection] = []
        # 1) per-word classification (covers isolated IDs/emails/phones)
        for text, box, conf in words:
            for hit in pii.classify_text(text):
                dets.append(Detection(hit["category"], max(hit["confidence"], conf * 0.6),
                                      box, source=self.backend, text=text,
                                      meta={"value": hit["value"]}))
        # 2) full-page classification to catch document-type keywords; attach to
        #    the densest text cluster so we blur the relevant block, not the page.
        full_text = " ".join(w[0] for w in words)
        page_hits = pii.classify_text(full_text)
        doc_cats = {h["category"] for h in page_hits} - {"pii_text"}
        if doc_cats:
            # bounding region covering all text
            xs = [b[0] for _, b, _ in words]; ys = [b[1] for _, b, _ in words]
            xe = [b[0] + b[2] for _, b, _ in words]; ye = [b[1] + b[3] for _, b, _ in words]
            region = (min(xs), min(ys), max(xe) - min(xs), max(ye) - min(ys))
            for cat in doc_cats:
                if not any(d.category == cat for d in dets):
                    dets.append(Detection(cat, 0.55, region, source=self.backend,
                                          text="(document region)"))
        return dets
