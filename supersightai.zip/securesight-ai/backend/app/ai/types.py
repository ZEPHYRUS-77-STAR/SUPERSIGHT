"""Shared data types for the detection pipeline."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# Mapping of detection category -> default risk + human explanation.
CATEGORY_RISK: dict[str, tuple[RiskLevel, str]] = {
    "face":            (RiskLevel.MEDIUM,   "A human face is identifiable in this image."),
    "child_face":      (RiskLevel.CRITICAL, "A child's face may be present — extra caution before sharing."),
    "aadhaar":         (RiskLevel.CRITICAL, "Looks like an Aadhaar number / card — a government ID."),
    "pan":             (RiskLevel.CRITICAL, "Looks like a PAN number / card — a government tax ID."),
    "passport":        (RiskLevel.CRITICAL, "Passport details detected — highly sensitive ID."),
    "driving_licence": (RiskLevel.HIGH,     "Driving licence details detected."),
    "bank_document":   (RiskLevel.HIGH,     "Bank / financial account details detected."),
    "signature":       (RiskLevel.HIGH,     "A handwritten signature appears present."),
    "pii_text":        (RiskLevel.HIGH,     "Sensitive personal text (email, phone, card, ID) detected."),
    "screenshot_pii":  (RiskLevel.MEDIUM,   "Screenshot appears to contain private information."),
    "weapon":          (RiskLevel.HIGH,     "A weapon-like object was detected."),
    "nsfw":            (RiskLevel.HIGH,     "Possible NSFW / explicit content."),
    "document":        (RiskLevel.MEDIUM,   "A document-like region was detected."),
    "person":          (RiskLevel.LOW,      "A person is present in the image."),
}

_RISK_ORDER = {RiskLevel.LOW: 0, RiskLevel.MEDIUM: 1, RiskLevel.HIGH: 2, RiskLevel.CRITICAL: 3}


@dataclass
class Detection:
    category: str
    confidence: float
    # bounding box in absolute pixels: x, y, w, h
    box: tuple[int, int, int, int]
    source: str = "unknown"          # which detector produced it
    text: str | None = None          # OCR text if relevant
    mask_rle: Any = None             # optional segmentation mask handle
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def risk(self) -> RiskLevel:
        return CATEGORY_RISK.get(self.category, (RiskLevel.MEDIUM, ""))[0]

    @property
    def explanation(self) -> str:
        return CATEGORY_RISK.get(self.category, (RiskLevel.MEDIUM, "Sensitive content detected."))[1]

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["risk"] = self.risk.value
        d["explanation"] = self.explanation
        d.pop("mask_rle", None)
        return d


def overall_risk(detections: list[Detection]) -> RiskLevel:
    if not detections:
        return RiskLevel.LOW
    return max((d.risk for d in detections), key=lambda r: _RISK_ORDER[r])
