"""Resolve and report on model weights available under the models directory.

Detectors are lazy and optional; this registry lets the API/UI show which heavy
models are actually present so users understand the active capability level.
"""
from __future__ import annotations

from pathlib import Path

from ..core.config import settings

# logical name -> expected weight filename(s) under models_dir
KNOWN_WEIGHTS = {
    "yolo_general": ["yolov8n.pt", "yolov8s.pt"],
    "yolo_document": ["yolov8-document.pt"],
    "yolo_weapon": ["yolov8-weapon.pt"],
    "sam": ["sam_vit_b.pth", "sam_vit_l.pth", "sam_vit_h.pth"],
    "yolo_world": ["yolov8s-worldv2.pt", "yolov8m-worldv2.pt", "yolov8x-worldv2.pt"],
    "grounding_dino": ["groundingdino_swint_ogc.pth"],
}


def resolve(name: str) -> Path | None:
    for fn in KNOWN_WEIGHTS.get(name, []):
        p = settings.models_dir / fn
        if p.exists():
            return p
    return None


def available() -> dict[str, bool]:
    return {name: resolve(name) is not None for name in KNOWN_WEIGHTS}


def report() -> dict:
    res = available()
    return {"models_dir": str(settings.models_dir),
            "present": {k: v for k, v in res.items() if v},
            "missing": [k for k, v in res.items() if not v]}
