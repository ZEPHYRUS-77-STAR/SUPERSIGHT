"""SecureSight AI — FastAPI application entrypoint.

Binds to localhost only by default (zero-trust, local-first). Run:
    python -m app.main
"""
from __future__ import annotations

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api.routes import router as core_router
from .api.routes_camera import router as camera_router
from .api.routes_upload import router as upload_router
from .api.routes_updates import router as updates_router
from .api.routes_risk import router as risk_router
from .api.errors import install_handlers
from .core.config import APP_NAME, APP_VERSION, settings
from .core import logging as audit_log
from .core.service import service
from .ai import model_registry

app = FastAPI(title=APP_NAME, version=APP_VERSION,
              description="Local-first AI image privacy protection.")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173",
                   "http://127.0.0.1:8077"],
    allow_methods=["*"], allow_headers=["*"],
)

install_handlers(app)
for r in (core_router, camera_router, upload_router, updates_router, risk_router):
    app.include_router(r, prefix="/api")


@app.get("/api/service/status")
def service_status():
    return service.status()


@app.post("/api/service/watch")
def service_watch(body: dict):
    return service.watch_folder(body.get("folder", ""))


@app.post("/api/service/unwatch")
def service_unwatch(body: dict):
    return service.unwatch_folder(body.get("folder", ""))


@app.on_event("startup")
def _startup():
    audit_log.info("server_start", version=APP_VERSION, models=model_registry.report())


@app.on_event("shutdown")
def _shutdown():
    service.stop_all()
    audit_log.info("server_stop")


def main():
    uvicorn.run(app, host=settings.host, port=settings.port)


if __name__ == "__main__":
    main()
