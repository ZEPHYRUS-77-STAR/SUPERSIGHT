"""Online-mode updater (opt-in): model + threat-intelligence updates.

Only runs when settings.online_mode is True. Downloads a signed manifest, verifies
each artifact's SHA-256 against the manifest, and writes new weights into the
models directory. NEVER uploads user images. If online_mode is False every call
is a no-op returning a clear status.
"""
from __future__ import annotations

import hashlib
import json
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from .config import settings
from . import logging as audit_log


@dataclass
class UpdateResult:
    checked: bool
    online: bool
    updated: list[str]
    message: str

    def to_dict(self) -> dict:
        return {"checked": self.checked, "online": self.online,
                "updated": self.updated, "message": self.message}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _fetch(url: str, timeout: int = 30) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "SecureSightAI"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 (opt-in)
        return resp.read()


def check_and_update(force: bool = False) -> UpdateResult:
    if not settings.online_mode and not force:
        return UpdateResult(False, False, [], "online mode disabled; no update performed")
    try:
        manifest = json.loads(_fetch(settings.update_url).decode())
    except Exception as exc:
        audit_log.error("update_manifest_failed", error=str(exc))
        return UpdateResult(True, True, [], f"manifest fetch failed: {exc}")

    updated: list[str] = []
    settings.models_dir.mkdir(parents=True, exist_ok=True)
    for art in manifest.get("artifacts", []):
        name, url, sha = art.get("name"), art.get("url"), art.get("sha256")
        if not (name and url and sha):
            continue
        dest = settings.models_dir / name
        if dest.exists() and _sha256(dest) == sha:
            continue  # already current
        try:
            data = _fetch(url)
            tmp = dest.with_suffix(dest.suffix + ".part")
            tmp.write_bytes(data)
            if _sha256(tmp) != sha:
                tmp.unlink(missing_ok=True)
                audit_log.warn("update_checksum_mismatch", artifact=name)
                continue
            tmp.replace(dest)
            updated.append(name)
        except Exception as exc:
            audit_log.error("update_artifact_failed", artifact=name, error=str(exc))
    audit_log.info("update_completed", count=len(updated))
    return UpdateResult(True, True, updated,
                        f"updated {len(updated)} artifact(s)" if updated else "already up to date")
