"""Consent-based, owner-recoverable Protection Mode.

The user enables protection for a chosen duration. While active, the app keeps
monitoring and applies its policy. UNLIKE malware, this is always recoverable:
the device owner can override/disable it with the recovery passphrase they set
at activation, and can always uninstall the software.

This module intentionally contains NO anti-uninstall, watchdog-respawn, or
admin-lockout logic. See docs/SECURITY.md for the rationale.
"""
from __future__ import annotations

import time

from ..db.database import get_db
from .crypto import hash_passphrase, verify_passphrase

DURATIONS = {"1d": 86400, "7d": 604800, "15d": 1296000,
             "30d": 2592000, "90d": 7776000}


def status() -> dict:
    p = get_db().get_protection()
    active = bool(p.get("active"))
    expires = p.get("expires")
    now = time.time()
    if active and expires and now >= expires:
        # auto-expire
        get_db().set_protection(active=0)
        get_db().log("protection_expired", {})
        active = False
    remaining = max(0, int((expires or now) - now)) if active else 0
    return {"active": active, "started": p.get("started"), "expires": expires,
            "remaining_seconds": remaining,
            "has_recovery": bool(p.get("recovery_hash"))}


def activate(duration: str, recovery_passphrase: str, custom_seconds: int | None = None) -> dict:
    if duration == "custom":
        seconds = int(custom_seconds or 0)
        if seconds <= 0:
            raise ValueError("custom duration requires positive custom_seconds")
    else:
        if duration not in DURATIONS:
            raise ValueError(f"unknown duration {duration!r}")
        seconds = DURATIONS[duration]
    if not recovery_passphrase or len(recovery_passphrase) < 6:
        raise ValueError("recovery passphrase must be at least 6 characters")
    now = time.time()
    salt, h = hash_passphrase(recovery_passphrase)
    get_db().set_protection(active=1, started=now, expires=now + seconds,
                            recovery_salt=salt, recovery_hash=h)
    get_db().log("protection_activated", {"duration": duration, "seconds": seconds})
    return status()


def deactivate(recovery_passphrase: str) -> dict:
    """Owner override. Requires the recovery passphrase set at activation."""
    p = get_db().get_protection()
    if not p.get("active"):
        return status()
    if not p.get("recovery_hash"):
        raise PermissionError("no recovery passphrase on record")
    if not verify_passphrase(recovery_passphrase, p["recovery_salt"], p["recovery_hash"]):
        get_db().log("protection_override_denied", {})
        raise PermissionError("recovery passphrase incorrect")
    get_db().set_protection(active=0)
    get_db().log("protection_deactivated", {"by": "owner_recovery"})
    return status()


def is_active() -> bool:
    return status()["active"]
