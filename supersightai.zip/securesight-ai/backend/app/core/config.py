"""Central configuration for SecureSight AI.

All paths are local to the user's machine. Nothing here points at a remote
server for image data — online mode is limited to model/threat-intel updates.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

APP_NAME = "SecureSight AI"
APP_VERSION = "0.1.0"


def _data_dir() -> Path:
    # Respect XDG / APPDATA, fall back to ~/.securesight
    base = os.environ.get("SECURESIGHT_HOME")
    if base:
        return Path(base)
    if os.name == "nt":
        return Path(os.environ.get("APPDATA", Path.home())) / "SecureSightAI"
    return Path.home() / ".securesight"


@dataclass
class Settings:
    data_dir: Path = field(default_factory=_data_dir)
    host: str = "127.0.0.1"          # bind localhost only — never 0.0.0.0 by default
    port: int = 8077
    # Risk thresholds (0..1)
    face_min_conf: float = 0.40
    nsfw_min_conf: float = 0.55
    object_min_conf: float = 0.35
    # Blur engine
    blur_method: str = "gaussian"    # gaussian | pixelate | fill
    blur_strength: int = 35          # odd kernel for gaussian; block size for pixelate
    region_padding: float = 0.06     # pad each region by this fraction of its size
    # Online mode (opt-in)
    online_mode: bool = False
    update_url: str = "https://example.invalid/securesight/updates"  # placeholder

    @property
    def db_path(self) -> Path:
        return self.data_dir / "securesight.db"

    @property
    def key_path(self) -> Path:
        return self.data_dir / "keyring.bin"

    @property
    def models_dir(self) -> Path:
        return self.data_dir / "models"

    @property
    def quarantine_dir(self) -> Path:
        return self.data_dir / "quarantine"

    def ensure_dirs(self) -> None:
        for p in (self.data_dir, self.models_dir, self.quarantine_dir):
            p.mkdir(parents=True, exist_ok=True)



def _find_thresholds() -> Path | None:
    """Locate ai_models/configs/thresholds.yaml relative to the repo, or via env."""
    env = os.environ.get("SECURESIGHT_THRESHOLDS")
    if env and Path(env).exists():
        return Path(env)
    here = Path(__file__).resolve()
    # backend/app/core/config.py -> repo root is parents[3]
    for base in (here.parents[3] if len(here.parents) > 3 else here.parent,):
        cand = base / "ai_models" / "configs" / "thresholds.yaml"
        if cand.exists():
            return cand
    return None


def _parse_simple_yaml(text: str) -> dict:
    """Minimal YAML reader for the flat + one-level-nested thresholds file.

    Supports `key: value` and a single level of `section:` with indented children.
    Values are coerced to int/float/bool/str. No external dependency required.
    """
    def coerce(v: str):
        v = v.strip()
        if v.lower() in ("true", "false"):
            return v.lower() == "true"
        try:
            return int(v)
        except ValueError:
            pass
        try:
            return float(v)
        except ValueError:
            return v.strip().strip('"').strip("'")

    out: dict = {}
    section: str | None = None
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indented = line[0] in (" ", "\t")
        key, _, val = line.strip().partition(":")
        key = key.strip()
        if not indented:
            if val.strip() == "":
                section = key
                out[section] = {}
            else:
                section = None
                out[key] = coerce(val)
        elif section is not None:
            out[section][key] = coerce(val)
    return out


def _apply_thresholds(s: "Settings") -> None:
    path = _find_thresholds()
    if path is None:
        return
    try:
        cfg = _parse_simple_yaml(path.read_text(encoding="utf-8"))
    except Exception:
        return
    for fld in ("face_min_conf", "nsfw_min_conf", "object_min_conf"):
        if isinstance(cfg.get(fld), (int, float)):
            setattr(s, fld, float(cfg[fld]))
    blur = cfg.get("blur") or {}
    if isinstance(blur.get("method"), str):
        s.blur_method = blur["method"]
    if isinstance(blur.get("strength"), int):
        s.blur_strength = blur["strength"]
    if isinstance(blur.get("region_padding"), (int, float)):
        s.region_padding = float(blur["region_padding"])


settings = Settings()
_apply_thresholds(settings)
settings.ensure_dirs()
