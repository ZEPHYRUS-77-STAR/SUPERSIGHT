"""AES-256-GCM encryption helpers + local key management.

Used to encrypt the local database payloads, logs, and quarantined images.
Keys live only on the device (file-backed keyring, 0600 perms). If the
`cryptography` package is unavailable, a clearly-labelled insecure fallback is
used so the rest of the app still runs in dev — never rely on it in production.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
from pathlib import Path

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _HAVE_CRYPTO = True
except Exception:  # pragma: no cover - optional dep
    _HAVE_CRYPTO = False


def _load_or_create_key(key_path: Path) -> bytes:
    if key_path.exists():
        return key_path.read_bytes()
    key = os.urandom(32)  # AES-256
    key_path.parent.mkdir(parents=True, exist_ok=True)
    key_path.write_bytes(key)
    try:
        os.chmod(key_path, 0o600)
    except Exception:
        pass
    return key


class Cipher:
    """AES-256-GCM authenticated encryption with a device-local key."""

    def __init__(self, key_path: Path):
        self._key = _load_or_create_key(key_path)

    def encrypt(self, plaintext: bytes, aad: bytes = b"securesight") -> bytes:
        if _HAVE_CRYPTO:
            nonce = os.urandom(12)
            ct = AESGCM(self._key).encrypt(nonce, plaintext, aad)
            return nonce + ct
        return _fallback_encrypt(self._key, plaintext, aad)

    def decrypt(self, blob: bytes, aad: bytes = b"securesight") -> bytes:
        if _HAVE_CRYPTO:
            nonce, ct = blob[:12], blob[12:]
            return AESGCM(self._key).decrypt(nonce, ct, aad)
        return _fallback_decrypt(self._key, blob, aad)

    def encrypt_str(self, text: str) -> str:
        return base64.b64encode(self.encrypt(text.encode())).decode()

    def decrypt_str(self, token: str) -> str:
        return self.decrypt(base64.b64decode(token)).decode()


def _fallback_encrypt(key: bytes, pt: bytes, aad: bytes) -> bytes:
    # XOR-keystream + HMAC. NOT for production; keeps dev runnable w/o cryptography.
    nonce = os.urandom(12)
    stream = _keystream(key, nonce, len(pt))
    ct = bytes(a ^ b for a, b in zip(pt, stream))
    tag = hmac.new(key, nonce + ct + aad, hashlib.sha256).digest()
    return nonce + tag + ct


def _fallback_decrypt(key: bytes, blob: bytes, aad: bytes) -> bytes:
    nonce, tag, ct = blob[:12], blob[12:44], blob[44:]
    expected = hmac.new(key, nonce + ct + aad, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected):
        raise ValueError("integrity check failed")
    stream = _keystream(key, nonce, len(ct))
    return bytes(a ^ b for a, b in zip(ct, stream))


def _keystream(key: bytes, nonce: bytes, n: int) -> bytes:
    out = b""
    counter = 0
    while len(out) < n:
        out += hashlib.sha256(key + nonce + counter.to_bytes(8, "big")).digest()
        counter += 1
    return out[:n]


def hash_passphrase(passphrase: str, salt: bytes | None = None) -> tuple[str, str]:
    """PBKDF2-HMAC-SHA256 for the recovery passphrase. Returns (salt_b64, hash_b64)."""
    salt = salt or os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", passphrase.encode(), salt, 200_000)
    return base64.b64encode(salt).decode(), base64.b64encode(dk).decode()


def verify_passphrase(passphrase: str, salt_b64: str, hash_b64: str) -> bool:
    salt = base64.b64decode(salt_b64)
    _, candidate = hash_passphrase(passphrase, salt)
    return hmac.compare_digest(candidate, hash_b64)
