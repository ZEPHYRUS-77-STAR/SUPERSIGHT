"""Encrypted, structured audit logging for SecureSight AI.

Wraps the encrypted SQLite `audit` table and also mirrors human-readable lines to
a local rotating file (no sensitive values written in clear). All log writes are
local; nothing is transmitted.
"""
from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path
from typing import Any

from .config import settings


def _file_logger() -> logging.Logger:
    logger = logging.getLogger("securesight")
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    log_dir = settings.data_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    handler = logging.handlers.RotatingFileHandler(
        log_dir / "securesight.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(handler)
    return logger


_LOG = _file_logger()
# fields we must never write to the plaintext file log
_REDACT = {"value", "values", "text", "path", "filename", "encoding"}


def _redact(detail: dict[str, Any]) -> dict[str, Any]:
    return {k: ("***" if k in _REDACT else v) for k, v in detail.items()}


def audit(event: str, detail: dict[str, Any] | None = None, level: str = "info") -> None:
    """Write to the encrypted DB audit log + redacted file log."""
    detail = detail or {}
    # encrypted DB record (full detail) — imported lazily to avoid a cycle
    try:
        from ..db.database import get_db
        get_db().log(event, detail)
    except Exception as exc:  # never let logging crash a request
        _LOG.error("audit_db_failed event=%s err=%s", event, exc)
    getattr(_LOG, level, _LOG.info)("event=%s detail=%s", event, _redact(detail))


def info(event: str, **detail: Any) -> None:
    audit(event, detail, "info")


def warn(event: str, **detail: Any) -> None:
    audit(event, detail, "warning")


def error(event: str, **detail: Any) -> None:
    audit(event, detail, "error")
