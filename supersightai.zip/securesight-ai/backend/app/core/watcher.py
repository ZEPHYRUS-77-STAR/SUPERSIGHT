"""Folder auto-scan via Watchdog (optional).

Watches a directory and runs the pipeline whenever a new image appears, logging
risky results. Disabled gracefully if `watchdog` is not installed. This is a
*monitor-and-warn* utility, not a mechanism to block the user.
"""
from __future__ import annotations

import threading
from pathlib import Path

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tiff"}


class FolderWatcher:
    def __init__(self, folder: str, on_result=None):
        self.folder = Path(folder)
        self.on_result = on_result
        self._observer = None
        self._thread = None

    @property
    def available(self) -> bool:
        try:
            import watchdog  # noqa
            return True
        except Exception:
            return False

    def start(self) -> bool:
        if not self.available:
            return False
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler

        import cv2
        from ..ai.pipeline import Pipeline
        from ..db.database import get_db

        pipe = Pipeline.get()

        class Handler(FileSystemEventHandler):
            def on_created(inner, event):
                if event.is_directory:
                    return
                p = Path(event.src_path)
                if p.suffix.lower() not in IMAGE_EXT:
                    return
                img = cv2.imread(str(p))
                if img is None:
                    return
                res = pipe.scan(img)
                get_db().add_scan(str(p), res.risk.value, len(res.detections), res.to_dict())
                if res.detections and self_outer.on_result:
                    self_outer.on_result(str(p), res)

        self_outer = self
        self._observer = Observer()
        self._observer.schedule(Handler(), str(self.folder), recursive=True)
        self._observer.start()
        return True

    def stop(self) -> None:
        if self._observer:
            self._observer.stop()
            self._observer.join(timeout=3)
            self._observer = None
