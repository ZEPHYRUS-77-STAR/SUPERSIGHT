"""Background service lifecycle.

Owns the optional folder watcher and exposes start/stop/status so the API and the
desktop tray can manage it. This is a normal, user-controllable service — it can
be stopped at any time and has no anti-uninstall behaviour.
"""
from __future__ import annotations

from pathlib import Path

from . import logging as audit_log
from .config import settings
from .watcher import FolderWatcher


class BackgroundService:
    def __init__(self) -> None:
        self._watchers: dict[str, FolderWatcher] = {}

    def watch_folder(self, folder: str) -> dict:
        folder = str(Path(folder).expanduser())
        if folder in self._watchers:
            return {"watching": folder, "status": "already_active"}
        w = FolderWatcher(folder, on_result=self._on_result)
        if not w.available:
            return {"watching": folder, "status": "unavailable",
                    "reason": "watchdog package not installed"}
        started = w.start()
        if started:
            self._watchers[folder] = w
            audit_log.info("watch_started", folder=folder)
        return {"watching": folder, "status": "active" if started else "failed"}

    def unwatch_folder(self, folder: str) -> dict:
        folder = str(Path(folder).expanduser())
        w = self._watchers.pop(folder, None)
        if w:
            w.stop()
            audit_log.info("watch_stopped", folder=folder)
            return {"watching": folder, "status": "stopped"}
        return {"watching": folder, "status": "not_active"}

    def status(self) -> dict:
        return {"online_mode": settings.online_mode,
                "watched_folders": list(self._watchers.keys())}

    def stop_all(self) -> None:
        for w in self._watchers.values():
            w.stop()
        self._watchers.clear()

    @staticmethod
    def _on_result(path: str, result) -> None:
        if result.detections:
            audit_log.warn("watch_risk_detected", risk=result.risk.value,
                           regions=len(result.detections), path=path)


service = BackgroundService()
