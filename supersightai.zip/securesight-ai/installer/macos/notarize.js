// afterSign hook for electron-builder to notarize the macOS build.
const { notarize } = require("@electron/notarize");
exports.default = async function (context) {
  if (context.electronPlatformName !== "darwin") return;
  const app = `${context.appOutDir}/${context.packager.appInfo.productFilename}.app`;
  await notarize({
    appBundleId: "ai.securesight.desktop",
    appPath: app,
    appleId: process.env.APPLE_ID,
    appleIdPassword: process.env.APPLE_APP_PASSWORD,
    teamId: process.env.APPLE_TEAM_ID,
  });
};
