; Reference NSIS script (electron-builder generates the real one from the YAML).
; Standard, per-user, fully removable installer — no admin lock-in.
!define APPNAME "SecureSight AI"
Name "${APPNAME}"
OutFile "..\..\dist\SecureSightAI-Setup.exe"
InstallDir "$LOCALAPPDATA\${APPNAME}"
RequestExecutionLevel user

Page directory
Page instfiles
UninstPage uninstConfirm
UninstPage instfiles

Section "Install"
  SetOutPath "$INSTDIR"
  File /r "..\..\dist\win-unpacked\*.*"
  CreateShortcut "$SMPROGRAMS\${APPNAME}.lnk" "$INSTDIR\SecureSight AI.exe"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
SectionEnd

Section "Uninstall"
  Delete "$SMPROGRAMS\${APPNAME}.lnk"
  RMDir /r "$INSTDIR"
SectionEnd
