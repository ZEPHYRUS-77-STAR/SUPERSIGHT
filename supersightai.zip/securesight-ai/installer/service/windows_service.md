# Running SecureSight AI at login on Windows (optional, removable)

SecureSight needs no admin rights and is always removable. Use a per-user
Scheduled Task to launch the local API at login:

```powershell
$action  = New-ScheduledTaskAction -Execute "pythonw.exe" -Argument "-m app.main" `
           -WorkingDirectory "$env:USERPROFILE\securesight-ai\backend"
$trigger = New-ScheduledTaskTrigger -AtLogOn
Register-ScheduledTask -TaskName "SecureSightAI" -Action $action -Trigger $trigger
```
Remove any time:
```powershell
Unregister-ScheduledTask -TaskName "SecureSightAI" -Confirm:$false
```
