# -*- coding: utf-8 -*-
"""
SecureSight AI - Solid Black-Box Redaction Service
Purpose: Apply secure covers over sensitive bounding box regions using OpenCV matrices.
"""

import cv2
import numpy as np
from typing import List, Dict, Any, Tuple

class RedactionService:
    @staticmethod
    def apply_black_box_redaction(image_bytes: bytes, bounding_boxes: List[Tuple[int, int, int, int]]) -> bytes:
        """
        Takes raw image bytes and relative percentages [ymin, xmin, ymax, xmax] (0 to 100),
        and burns solid black-out covers onto the pixels to ensure irreversible redaction.
        """
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            return image_bytes

        height, width, _ = img.shape

        for box in bounding_boxes:
            ymin_pct, xmin_pct, ymax_pct, xmax_pct = box
            
            # Convert relative percentages back to actual pixel dimensions
            ymin = int((ymin_pct / 100.0) * height)
            xmin = int((xmin_pct / 100.0) * width)
            ymax = int((ymax_pct / 100.0) * height)
            xmax = int((xmax_pct / 100.0) * width)

            # Restrict coordinates to valid frame boundaries
            ymin = max(0, min(ymin, height - 1))
            xmin = max(0, min(xmin, width - 1))
            ymax = max(0, min(ymax, height - 1))
            xmax = max(0, min(xmax, width - 1))

            if ymax > ymin and xmax > xmin:
                # Black out solid rectangle
                # BGR color coordinates: black is (0,0,0)
                # Fill pixel thickness: -1 represents solid coverage
                cv2.rectangle(img, (xmin, ymin), (xmax, ymax), (0, 0, 0), -1)

                # Optional perimeter safe check for enterprise: double layer border
                cv2.rectangle(img, (xmin - 1, ymin - 1), (xmax + 1, ymax + 1), (20, 20, 20), 1)

        # Re-encode back into raw JPG bytes
        success, encoded_img = cv2.imencode(".jpg", img)
        if not success:
            return image_bytes
            
        return encoded_img.tobytes()

    @staticmethod
    def apply_gaussian_blur(image_bytes: bytes, bounding_boxes: List[Tuple[int, int, int, int]], intensity: int = 51) -> bytes:
        """
        Applies a heavy Gaussian blur to secondary features (e.g. general biometric profiles).
        """
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            return image_bytes

        height, width, _ = img.shape

        # Ensure intensity is odd for Gaussian specifications
        if intensity % 2 == 0:
            intensity += 1

        for box in bounding_boxes:
            ymin_pct, xmin_pct, ymax_pct, xmax_pct = box
            
            ymin = int((ymin_pct / 100.0) * height)
            xmin = int((xmin_pct / 100.0) * width)
            ymax = int((ymax_pct / 100.0) * height)
            xmax = int((xmax_pct / 100.0) * width)

            ymin = max(0, min(ymin, height - 1))
            xmin = max(0, min(xmin, width - 1))
            ymax = max(0, min(ymax, height - 1))
            xmax = max(0, min(xmax, width - 1))

            if ymax > ymin and xmax > xmin:
                sub_img = img[ymin:ymax, xmin:xmax]
                blurred = cv2.GaussianBlur(sub_img, (intensity, intensity), 0)
                img[ymin:ymax, xmin:xmax] = blurred

        success, encoded_img = cv2.imencode(".jpg", img)
        if not success:
            return image_bytes
            
        return encoded_img.tobytes()
