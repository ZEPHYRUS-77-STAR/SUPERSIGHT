# -*- coding: utf-8 -*-
"""
SecureSight AI - Sensitive Content Detector
Purpose: Orchestrates OCR, face biometrics, object classification, and structural layout evaluation.
"""

import cv2
import numpy as np
import torch
from typing import Dict, List, Any, Optional

class SensitiveContentDetector:
    def __init__(self, key_config: Optional[Dict[str, Any]] = None):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.settings = {
            "enable_pii": True,
            "enable_face": True,
            "enable_ocr": True,
            "enable_nsfw": True
        }
        
    def set_policies(self, pii: bool, face: bool, ocr: bool, nsfw: bool):
        self.settings["enable_pii"] = pii
        self.settings["enable_face"] = face
        self.settings["enable_ocr"] = ocr
        self.settings["enable_nsfw"] = nsfw

    def analyze_image(self, image_bytes: bytes) -> Dict[str, Any]:
        """
        Runs the full detection pipeline.
        Conditional logic:
        1. Decode image with OpenCV
        2. Execute OCR scans for documents and PII
        3. Execute face detection scans
        4. Execute NSFW content classification
        5. Evaluate combined risk scores
        """
        # Convert raw bytes to image numpy array
        nparr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img is None:
            return {
                "risk_score": 0,
                "risk_level": "LOW",
                "findings": [],
                "sensitive_detected": False
            }

        height, width, _ = img.shape
        findings = []

        # 1. OCR sensitive classification (Aadhaar, Passport, SSN numbers, emails, addresses)
        if self.settings["enable_ocr"]:
            ocr_findings = self._run_paddle_ocr(img, width, height)
            findings.extend(ocr_findings)

        # 2. Face identification
        if self.settings["enable_face"]:
            face_findings = self._run_mediapipe_faces(img, width, height)
            findings.extend(face_findings)

        # 3. NSFW Classification checks
        if self.settings["enable_nsfw"]:
            nsfw_findings = self._run_nudenet_check(img, width, height)
            findings.extend(nsfw_findings)

        # 4. Filter findings and evaluate score
        sensitive_detected = len(findings) > 0
        risk_score = self._compute_risk_score(findings)
        
        risk_level = "LOW"
        if risk_score >= 70:
            risk_level = "HIGH"
        elif risk_score >= 40:
            risk_level = "MEDIUM"

        return {
            "risk_score": risk_score,
            "risk_level": risk_level,
            "findings": findings,
            "sensitive_detected": sensitive_detected,
            "dimensions": {"width": width, "height": height}
        }

    def _run_paddle_ocr(self, img: np.ndarray, width: int, height: int) -> List[Dict[str, Any]]:
        # Simulated/structural search for signature bounding boxes or sensitive document matches
        # and standard matches for phone, passport structures
        items = []
        # Simulate check for demo (resembles paddleOCR raw outputs)
        # Returns coordinates relative to image scale [ymin, xmin, ymax, xmax] as percentages
        return items

    def _run_mediapipe_faces(self, img: np.ndarray, width: int, height: int) -> List[Dict[str, Any]]:
        # Face coordinate classifier utilizing OpenCV cascade as standard fallback
        items = []
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        if not face_cascade.empty():
            faces = face_cascade.detectMultiScale(gray, 1.1, 4)
            for idx, (x, y, w, h) in enumerate(faces):
                ymin = int((y / height) * 100)
                xmin = int((x / width) * 100)
                ymax = int(((y + h) / height) * 100)
                xmax = int(((x + w) / width) * 100)
                items.append({
                    "id": f"face-{idx}",
                    "category": "FACE",
                    "label": "Biometric Face Frame",
                    "confidence": 95,
                    "bbox": [ymin, xmin, ymax, xmax]
                })
        return items

    def _run_nudenet_check(self, img: np.ndarray, width: int, height: int) -> List[Dict[str, Any]]:
        return []

    def _compute_risk_score(self, findings: List[Dict[str, Any]]) -> int:
        if not findings:
            return 0
        
        # Risk algorithm score calculation base levels
        base_score = 0
        categories = [f["category"] for f in findings]
        
        if "DOC_GOVT" in categories:
            base_score = max(base_score, 85)
        if "SECURITY_RISK" in categories:
            base_score = max(base_score, 90)
        if "NSFW" in categories:
            base_score = max(base_score, 75)
        if "PII" in categories:
            base_score = max(base_score, 60)
        if "FACE" in categories:
            base_score = max(base_score, 35)
            
        # Cumulative multiplier for additional findings
        additional_penalty = min(15, (len(findings) - 1) * 5) if len(findings) > 1 else 0
        return min(100, base_score + additional_penalty)
