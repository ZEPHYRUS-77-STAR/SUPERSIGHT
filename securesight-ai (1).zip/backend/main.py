# -*- coding: utf-8 -*-
"""
SecureSight AI - Parent FastAPI Application Endpoint
"""

import os
import uuid
import datetime
import base64
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, String, Integer, Boolean, DateTime, Float, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from cryptography.fernet import Fernet

# Initialize database
SQLALCHEMY_DATABASE_URL = "sqlite:///./securesight_secure.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# AES-256 local database value encryption
DB_ENCRYPTION_KEY = os.getenv("SECURESIGHT_DB_KEY", Fernet.generate_key().decode())
fernet_cipher = Fernet(DB_ENCRYPTION_KEY.encode())

# Database Models
class ScanResultModel(Base):
    __tablename__ = "scan_results"
    
    id = Column(String, primary_key=True, index=True)
    name = Column(String, index=True)
    timestamp = Column(String, default=lambda: datetime.datetime.utcnow().isoformat())
    original_image_encrypted = Column(String)  # AES-256 base64
    risk_score = Column(Integer)
    risk_level = Column(String)
    findings = Column(JSON)  # List of findings
    upload_status = Column(String)
    source = Column(String)

class PrivacySettingsModel(Base):
    __tablename__ = "privacy_settings"
    
    id = Column(Integer, primary_key=True, default=1)
    enable_pii = Column(Boolean, default=True)
    enable_face = Column(Boolean, default=True)
    enable_ocr = Column(Boolean, default=True)
    enable_nsfw = Column(Boolean, default=True)

class AuditLogModel(Base):
    __tablename__ = "audit_logs"
    
    id = Column(String, primary_key=True)
    timestamp = Column(String)
    action = Column(String)
    details = Column(String)
    status = Column(String)

Base.metadata.create_all(bind=engine)

# FastAPI Init
app = FastAPI(title="SecureSight AI", description="Enterprise Image DLP & Redaction Suite")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic Schemas
class SettingsSchema(BaseModel):
    enable_pii: bool
    enable_face: bool
    enable_ocr: bool
    enable_nsfw: bool

class ScanRequest(BaseModel):
    image_base64: str
    name: str
    source: str = "UPLOAD"

# Dependencies
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Seed default settings
db = SessionLocal()
if not db.query(PrivacySettingsModel).first():
    db.add(PrivacySettingsModel(id=1, enable_pii=True, enable_face=True, enable_ocr=True, enable_nsfw=True))
    db.commit()
db.close()

@app.get("/api/scans")
def get_scan_history(db: Session = Depends(get_db)):
    results = db.query(ScanResultModel).order_by(ScanResultModel.timestamp.desc()).all()
    return [{
        "id": r.id,
        "name": r.name,
        "timestamp": r.timestamp,
        "riskScore": r.risk_score,
        "riskLevel": r.risk_level,
        "findings": r.findings,
        "uploadStatus": r.upload_status,
        "source": r.source
    } for r in results]

@app.get("/api/settings")
def get_local_settings(db: Session = Depends(get_db)):
    settings = db.query(PrivacySettingsModel).first()
    return settings

@app.post("/api/settings")
def update_local_settings(payload: SettingsSchema, db: Session = Depends(get_db)):
    settings = db.query(PrivacySettingsModel).first()
    settings.enable_pii = payload.enable_pii
    settings.enable_face = payload.enable_face
    settings.enable_ocr = payload.enable_ocr
    settings.enable_nsfw = payload.enable_nsfw
    db.commit()
    
    log = AuditLogModel(
        id=str(uuid.uuid4()),
        timestamp=datetime.datetime.utcnow().isoformat(),
        action="SETTINGS_CHANGED",
        details=f"PII={payload.enable_pii}, FACE={payload.enable_face}, OCR={payload.enable_ocr}, NSFW={payload.enable_nsfw}",
        status="SUCCESS"
    )
    db.add(log)
    db.commit()
    return {"success": True, "settings": settings}

@app.get("/api/logs")
def get_audit_trail(db: Session = Depends(get_db)):
    logs = db.query(AuditLogModel).order_by(AuditLogModel.timestamp.desc()).all()
    return logs
