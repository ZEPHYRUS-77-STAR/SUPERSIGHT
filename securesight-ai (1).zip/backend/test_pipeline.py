# -*- coding: utf-8 -*-
"""
SecureSight AI - Automated Verification & Testing Suite
"""

import unittest
import numpy as np
import cv2
from sensitive_content_detector import SensitiveContentDetector
from redaction_service import RedactionService

class TestSecureSightPipeline(unittest.TestCase):
    def setUp(self):
        self.detector = SensitiveContentDetector()
        
        # Build raw test image context
        self.test_img = np.ones((500, 500, 3), dtype=np.uint8) * 255
        # Draw some arbitrary lines and box
        cv2.rectangle(self.test_img, (50, 50), (200, 200), (0, 0, 255), 3)
        _, self.img_bytes = cv2.imencode(".jpg", self.test_img)
        self.img_bytes = self.img_bytes.tobytes()

    def test_default_policies(self):
        """Verify default DLP check criteria are enabled"""
        self.assertTrue(self.detector.settings["enable_pii"])
        self.assertTrue(self.detector.settings["enable_face"])
        self.assertTrue(self.detector.settings["enable_ocr"])

    def test_policy_disablement(self):
        """Confirm that disabling policy filters bypasses those checks"""
        self.detector.set_policies(pii=False, face=False, ocr=False, nsfw=False)
        self.assertFalse(self.detector.settings["enable_pii"])
        self.assertFalse(self.detector.settings["enable_face"])
        
        # Test scan with disabled settings returns low risk
        result = self.detector.analyze_image(self.img_bytes)
        self.assertEqual(result["risk_score"], 0)
        self.assertEqual(result["risk_level"], "LOW")

    def test_risk_scoring_bounds(self):
        """Test calculation criteria boundaries for risk severity ratings"""
        findings = [
            {"category": "FACE", "label": "Face 1"},
            {"category": "PII", "label": "SSN"}
        ]
        score = self.detector._compute_risk_score(findings)
        self.assertGreaterEqual(score, 60)
        self.assertLessEqual(score, 100)

    def test_redaction_solid_burn(self):
        """Verify redactor draws solid black blocks over designated boxes"""
        box = (10, 10, 40, 40) # normalized percent bounding box
        redacted_bytes = RedactionService.apply_black_box_redaction(self.img_bytes, [box])
        
        # Decode and check if pixels in the region are actually zero (black)
        nparr = np.frombuffer(redacted_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        self.assertIsNotNone(img)
        
        height, width, _ = img.shape
        # Sample inside area of redacted zone (e.g. 25% height, 25% width)
        sampled_pixel = img[int(height * 0.25), int(width * 0.25)]
        
        # BGR channels must be [0, 0, 0]
        np.testing.assert_array_equal(sampled_pixel, [0, 0, 0])

if __name__ == "__main__":
    unittest.main()
