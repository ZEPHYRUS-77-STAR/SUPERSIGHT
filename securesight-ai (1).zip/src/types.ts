/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export interface ScanFinding {
  id: string;
  category: 'PII' | 'FACE' | 'OCR_SENSITIVE' | 'NSFW' | 'DOC_GOVT' | 'SECURITY_RISK';
  label: string;
  confidence: number;
  text?: string;
  bbox?: [number, number, number, number]; // [ymin, xmin, ymax, xmax] as 0-100 percentages
  maskPolygon?: [number, number][]; // Optional segmentation polygon points [pct_x, pct_y]
}

export interface ScanResult {
  id: string;
  name: string;
  timestamp: string;
  originalImage: string; // base64
  redactedImage?: string; // base64
  riskScore: number;
  riskLevel: RiskLevel;
  findings: ScanFinding[];
  uploadStatus: 'PENDING' | 'ALLOWED' | 'BLOCKED' | 'UPLOADED';
  source: 'UPLOAD' | 'CAMERA' | 'WATCHDOG';
}

export interface PrivacySettings {
  enablePII: boolean;
  enableFace: boolean;
  enableOCR: boolean;
  enableNSFW: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  details: string;
  status: 'SUCCESS' | 'WARNING' | 'DENIED';
}

export interface DashboardStats {
  totalScans: number;
  highRiskCount: number;
  mediumRiskCount: number;
  lowRiskCount: number;
  uploadsBlocked: number;
  protectedImages: number;
}
