/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Activity, 
  Image as ImageIcon, 
  Upload, 
  Camera, 
  FileText, 
  Settings as SettingsIcon, 
  HelpCircle,
  Bell,
  Cpu,
  RefreshCw,
  X
} from 'lucide-react';

import { ScanResult, AuditLog, DashboardStats } from './types';
import DashboardView from './components/DashboardView';
import GalleryView from './components/GalleryView';
import UploadView from './components/UploadView';
import CameraView from './components/CameraView';
import ReportsView from './components/ReportsView';
import SettingsView from './components/SettingsView';
import AboutView from './components/AboutView';

type TabType = 'DASHBOARD' | 'GALLERY' | 'UPLOAD' | 'CAMERA' | 'REPORTS' | 'SETTINGS' | 'ABOUT';

interface WatchdogNotification {
  id: string;
  title: string;
  message: string;
  type: 'INFO' | 'WARNING';
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('DASHBOARD');
  const [scans, setScans] = useState<ScanResult[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalScans: 0,
    highRiskCount: 0,
    mediumRiskCount: 0,
    lowRiskCount: 0,
    uploadsBlocked: 0,
    protectedImages: 0,
  });
  const [alerts, setAlerts] = useState<WatchdogNotification[]>([]);
  const [geminiConnected, setGeminiConnected] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  // Initial Sync
  useEffect(() => {
    syncAllData();
  }, []);

  const syncAllData = async () => {
    setIsSyncing(true);
    try {
      // 1. Fetch scanned history
      const scansRes = await fetch('/api/scans');
      const scansData = await scansRes.json();
      setScans(scansData);

      // 2. Fetch logs audit
      const logsRes = await fetch('/api/logs');
      const logsData = await logsRes.json();
      setLogs(logsData);

      // 3. Fetch aggregated stats & reports
      const reportsRes = await fetch('/api/reports');
      const reportsData = await reportsRes.json();
      setStats(reportsData.stats);

      // Set Gemini Connected status based on server logs or metadata
      // (If running under normal environment, server can signal connection)
      setGeminiConnected(true); 

    } catch (err) {
      console.warn('System sync warning:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  const handlePostLog = async (action: string, details: string, status: 'SUCCESS' | 'WARNING' | 'DENIED') => {
    // Dynamic refresh trigger
    syncAllData();
  };

  const handleDeleteScan = async (id: string) => {
    try {
      const res = await fetch(`/api/scans/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setAlerts(prev => [
          {
            id: Math.random().toString(),
            title: 'File Permanently Shredded',
            message: 'Image references and black box caches compiled have been fully deleted.',
            type: 'INFO'
          },
          ...prev
        ]);
        syncAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSimulateWatchdog = async () => {
    try {
      const res = await fetch('/api/watchdog/simulate', { method: 'POST' });
      const data = await res.json();
      if (data.success && data.scan) {
        const scan: ScanResult = data.scan;
        
        // Push floating in-app notification header toast
        const newAlert: WatchdogNotification = {
          id: Math.random().toString(),
          title: scan.riskLevel === 'HIGH' ? '🚨 WATCHDOG FILTER DETECTED RISK' : '✓ WATCHDOG AUDITED FILE',
          message: `Scanned fresh item: ${scan.name}. Classification: ${scan.riskLevel} (${scan.riskScore}/100)`,
          type: scan.riskLevel === 'HIGH' ? 'WARNING' : 'INFO'
        };

        setAlerts(prev => [newAlert, ...prev]);
        syncAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleClearNotifications = () => {
    setAlerts([]);
  };

  const removeAlert = (id: string) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#020408] text-slate-200 flex overflow-hidden font-sans relative">
      
      {/* Background Grid Effect */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: "radial-gradient(#22d3ee 0.5px, transparent 0.5px)", backgroundSize: '24px 24px' }}></div>

      {/* Sidebar Navigation */}
      <aside className="w-60 bg-[#0a0d14] border-r border-[#1e293b] flex flex-col z-10 flex-shrink-0 h-screen">
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 bg-cyan-500 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
            <ShieldAlert className="text-white" size={18} />
          </div>
          <span className="font-bold tracking-tight text-lg text-white">SECURESIGHT AI</span>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          {[
            { id: 'DASHBOARD', label: 'Dashboard', icon: Activity },
            { id: 'GALLERY', label: 'Gallery', icon: ImageIcon },
            { id: 'UPLOAD', label: 'Upload Center', icon: Upload },
            { id: 'CAMERA', label: 'Secure Camera', icon: Camera },
            { id: 'REPORTS', label: 'Reports', icon: FileText },
            { id: 'SETTINGS', label: 'Settings', icon: SettingsIcon },
            { id: 'ABOUT', label: 'System Info', icon: HelpCircle },
          ].map((item) => {
            const IconComponent = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as TabType)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors text-sm ${
                  isActive 
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-medium' 
                    : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                }`}
              >
                <IconComponent size={18} />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* System Load Widget (at the bottom of sidebar) */}
        <div className="p-6 mt-auto">
          <div className="bg-white/5 rounded-2xl p-4 border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">System Load</span>
              <span className="text-[10px] text-cyan-400 font-mono">14%</span>
            </div>
            <div className="h-1 bg-[#1e293b] rounded-full overflow-hidden">
              <div className="h-full bg-cyan-500 w-[14%]"></div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col z-10 overflow-hidden h-screen">
        {/* Header content */}
        <header className="h-20 border-b border-[#1e293b] flex items-center justify-between px-8 bg-[#020408]/80 backdrop-blur-md flex-shrink-0">
          <div>
            <h1 className="text-xl font-semibold text-white">
              {activeTab === 'DASHBOARD' && 'Security Dashboard'}
              {activeTab === 'UPLOAD' && 'Upload DLP Center'}
              {activeTab === 'GALLERY' && 'Secure Repository'}
              {activeTab === 'CAMERA' && 'Secure Camera'}
              {activeTab === 'REPORTS' && 'Compliance Ledger'}
              {activeTab === 'SETTINGS' && 'Security Policies'}
              {activeTab === 'ABOUT' && 'System Information'}
            </h1>
            <p className="text-sm text-slate-400">
              {activeTab === 'DASHBOARD' && 'System Active: Watching 4 local directories'}
              {activeTab === 'UPLOAD' && 'Scan file streams with real-time visual redactions'}
              {activeTab === 'GALLERY' && 'View local historic audited file scan logs'}
              {activeTab === 'CAMERA' && 'Biometric live camera feed with computer vision filters'}
              {activeTab === 'REPORTS' && 'Automated compliance registries and risk breakdown statistics'}
              {activeTab === 'SETTINGS' && 'Customize dynamic computer vision screening rules'}
              {activeTab === 'ABOUT' && 'Automated local-first Data Loss Prevention visual shell'}
            </p>
          </div>
          <div className="flex items-center gap-4">
            
            <div className="hidden lg:flex items-center gap-2 bg-[#0a0d14] px-3 py-1.5 rounded-lg border border-[#1e293b]">
              <Cpu size={12} className="text-cyan-400 animate-spin" style={{ animationDuration: '6s' }} />
              <span className="text-[10px] font-mono text-slate-400 uppercase">Engine Type:</span>
              <span className="text-[10px] font-mono font-semibold text-cyan-400">GEMINI-3.5-FLASH</span>
            </div>

            <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-xs font-medium text-emerald-400">Secure Local Processing</span>
            </div>

            <button 
              onClick={syncAllData}
              disabled={isSyncing}
              className={`p-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-slate-300 hover:text-white transition-all ${
                isSyncing ? 'animate-spin' : ''
              }`}
              title="Force synchronization"
            >
              <RefreshCw size={14} />
            </button>

            <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 font-bold" title="amiyaranjan028@gmail.com">
              AR
            </div>
          </div>
        </header>

        {/* Viewport content area */}
        <div className="p-8 space-y-6 flex-1 overflow-y-auto">
          
          {/* Notifications stack warnings banner */}
          {alerts.length > 0 && (
            <div className="mb-6 space-y-2 max-w-xl z-50">
              {alerts.map(alert => (
                <div 
                  key={alert.id} 
                  className={`p-3 rounded-lg border flex justify-between items-center animate-fade-in shadow-lg ${
                    alert.type === 'WARNING' 
                      ? 'bg-red-950/20 border-red-500/30 text-red-100' 
                      : 'bg-emerald-950/20 border-emerald-500/30 text-emerald-100'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold uppercase">{alert.title}</span>
                    <span className="text-xs text-gray-300 font-sans">{alert.message}</span>
                  </div>
                  <button onClick={() => removeAlert(alert.id)} className="text-gray-500 hover:text-white p-1">
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Render target tab */}
          {activeTab === 'DASHBOARD' && (
            <DashboardView 
              stats={stats} 
              logs={logs} 
              onRefresh={syncAllData} 
              onSimulateWatchdog={handleSimulateWatchdog} 
            />
          )}

          {activeTab === 'UPLOAD' && (
            <UploadView 
              onScanCompleted={syncAllData} 
              onPostLog={handlePostLog} 
            />
          )}

          {activeTab === 'GALLERY' && (
            <GalleryView 
              scans={scans} 
              onDeleteScan={handleDeleteScan} 
              onPostLog={handlePostLog} 
            />
          )}

          {activeTab === 'CAMERA' && (
            <CameraView 
              onScanCompleted={syncAllData} 
              onPostLog={handlePostLog} 
            />
          )}

          {activeTab === 'REPORTS' && (
            <ReportsView 
              stats={stats} 
              onPostLog={handlePostLog} 
            />
          )}

          {activeTab === 'SETTINGS' && (
            <SettingsView 
              onPostLog={handlePostLog} 
              onRefresh={syncAllData} 
            />
          )}

          {activeTab === 'ABOUT' && (
            <AboutView />
          )}

        </div>

        {/* Footer / Status Bar exactly matching the requested theme */}
        <footer className="h-10 bg-[#0a0d14] border-t border-[#1e293b] px-8 flex items-center justify-between text-[10px] tracking-widest text-[#64748b] font-mono flex-shrink-0">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
              GROUNDING_DINO: v2.4.0
            </span>
            <span className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
              SAM_2: OPTIMIZED
            </span>
          </div>
          <div>ENC: AES-256-GCM | LOCAL_ONLY: ENABLED</div>
        </footer>
      </main>

    </div>
  );
}
