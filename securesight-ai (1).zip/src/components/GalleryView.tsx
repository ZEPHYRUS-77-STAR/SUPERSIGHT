/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Search, Filter, Trash2, Eye, EyeOff, ShieldCheck, Download, AlertTriangle } from 'lucide-react';
import { ScanResult, RiskLevel } from '../types';

interface GalleryViewProps {
  scans: ScanResult[];
  onDeleteScan: (id: string) => void;
  onPostLog: (action: string, details: string, status: 'SUCCESS' | 'WARNING' | 'DENIED') => void;
}

export default function GalleryView({ scans, onDeleteScan, onPostLog }: GalleryViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRiskFilter, setSelectedRiskFilter] = useState<'ALL' | RiskLevel>('ALL');
  const [redactedState, setRedactedState] = useState<{ [key: string]: boolean }>({});

  // Initialize all cards to redacted (protected) view by default
  useEffect(() => {
    const initialState = { ...redactedState };
    scans.forEach(s => {
      if (initialState[s.id] === undefined) {
        initialState[s.id] = true; 
      }
    });
    setRedactedState(initialState);
  }, [scans]);

  const toggleMask = (id: string) => {
    setRedactedState(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
    onPostLog('TOGGLE_REDACTION_MASK', `User switched visual preview layer for scan item: ${id}`, 'SUCCESS');
  };

  const handleDownloadItem = (scan: ScanResult) => {
    // Generate a secure simulation file download
    const link = document.createElement('a');
    link.download = `SecureSight_${redactedState[scan.id] ? 'REDACTED' : 'RAW'}_${scan.name}`;
    // Use fallback canvas data or seed string
    link.href = scan.originalImage || 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
    link.click();
    onPostLog('SECURE_DOWNLOAD', `Downloaded asset ${scan.name} (Schema: ${redactedState[scan.id] ? 'Protected' : 'Raw'})`, 'SUCCESS');
  };

  // Filter items
  const filteredScans = scans.filter(scan => {
    const matchesSearch = scan.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      scan.findings.some(f => f.label.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (selectedRiskFilter === 'ALL') {
      return matchesSearch;
    }
    return matchesSearch && scan.riskLevel === selectedRiskFilter;
  });

  return (
    <div id="gallery-container" className="space-y-6">
      
      {/* Search and Filters panel */}
      <div className="bg-[#0a0d14] p-4 rounded-xl border border-[#1e293b] backdrop-blur-md flex flex-col md:flex-row justify-between items-center gap-4">
        
        {/* Search Input bar */}
        <div className="relative w-full md:w-80">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            id="gallery-search"
            type="text"
            placeholder="Search filenames, PII text..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-[#020408] border border-[#1e293b] rounded-lg text-xs font-sans text-slate-200 outline-none focus:border-cyan-500/50"
          />
        </div>

        {/* Filter Chips buttons */}
        <div className="flex gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          <span className="text-[10px] uppercase font-mono text-slate-500 flex items-center pr-2 font-medium">Filter Risk:</span>
          
          {(['ALL', 'HIGH', 'MEDIUM', 'LOW'] as const).map(filter => (
            <button
              key={filter}
              onClick={() => setSelectedRiskFilter(filter)}
              className={`px-3 py-1 text-[10px] font-mono rounded transition-all uppercase ${
                selectedRiskFilter === filter 
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-[0_0_10px_rgba(34,211,238,0.3)]' 
                  : 'bg-[#020408] hover:bg-slate-800 border border-[#1e293b] text-slate-400 hover:text-white'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Grid container */}
      {filteredScans.length === 0 ? (
        <div className="bg-[#0a0d14]/40 rounded-xl border border-[#1e293b] p-16 text-center text-slate-500">
          <Filter size={24} className="mx-auto mb-3 text-slate-700 animate-pulse" />
          <p className="text-xs font-mono">No repository records matching current search vector.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredScans.map(scan => {
            const isRedactedActive = redactedState[scan.id];
            
            const badgeColor = 
              scan.riskLevel === 'HIGH' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
              scan.riskLevel === 'MEDIUM' ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20' :
              'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';

            return (
              <div 
                key={scan.id} 
                id={`gallery-card-${scan.id}`}
                className="group relative bg-[#0a0d14] rounded-xl border border-[#1e293b] overflow-hidden flex flex-col justify-between hover:border-slate-700 hover:shadow-lg hover:shadow-cyan-500/5 transition-all"
              >
                {/* Tactical visual header inside individual card */}
                <div className="p-3 border-b border-[#1e293b] flex justify-between items-center bg-[#020408]/20">
                  <div className="truncate max-w-[130px]">
                    <p className="text-xs font-sans text-slate-200 font-semibold truncate" title={scan.name}>
                      {scan.name}
                    </p>
                    <p className="text-[9px] text-slate-500 font-mono mt-0.5">
                      {new Date(scan.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider border ${badgeColor}`}>
                    {scan.riskLevel}
                  </span>
                </div>

                {/* Simulated Thumbnail Visual Viewport */}
                <div className="relative h-40 bg-[#020408]/40 flex items-center justify-center p-2 group-hover:bg-[#020408]/10 transition-colors">
                  {scan.originalImage ? (
                    <div className="relative w-full h-full rounded overflow-hidden">
                      <img 
                        src={scan.originalImage} 
                        alt={scan.name} 
                        className={`w-full h-full object-contain ${isRedactedActive ? 'brightness-50' : 'brightness-100'}`} 
                      />
                      
                      {/* Redacted Black patches over unredacted original */}
                      {isRedactedActive && scan.findings.map((f, i) => {
                        if (!f.bbox) return null;
                        const [ymin, xmin, ymax, xmax] = f.bbox;
                        return (
                          <div
                            key={i}
                            className="absolute bg-black border border-red-500/20"
                            style={{
                              top: `${ymin}%`,
                              left: `${xmin}%`,
                              height: `${ymax - ymin}%`,
                              width: `${xmax - xmin}%`,
                            }}
                          />
                        );
                      })}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center text-center p-4">
                      {scan.riskLevel === 'HIGH' ? (
                        <AlertTriangle size={32} className="text-red-500/20 mb-2" />
                      ) : (
                        <ShieldCheck size={32} className="text-cyan-500/10 mb-2" />
                      )}
                      <p className="text-[10px] font-mono text-slate-500 uppercase">
                        {scan.source} COMPRESSED FILE
                      </p>
                      {scan.findings.length > 0 && isRedactedActive && (
                        <div className="mt-2 text-[9px] text-red-400 font-mono border border-red-500/20 px-2 py-0.5 rounded bg-red-950/10 animate-pulse">
                          {scan.findings.length} Black-Out Masks Applied
                        </div>
                      )}
                    </div>
                  )}

                  {/* Redaction active visual alert banner */}
                  {isRedactedActive && scan.findings.length > 0 && (
                    <div className="absolute inset-0 bg-cyan-900/5 pointer-events-none border border-cyan-500/10" />
                  )}
                </div>

                {/* Scan Findings details block */}
                <div className="p-3 border-t border-[#1e293b] space-y-2 flex-grow bg-[#020408]/20">
                  <span className="text-[9px] font-mono text-slate-500 uppercase font-medium">Security Scan Items:</span>
                  
                  {scan.findings.length === 0 ? (
                    <p className="text-[10px] text-emerald-400 font-mono">✓ Clear // Compliant safe payload</p>
                  ) : (
                    <div className="max-h-16 overflow-y-auto space-y-1 scrollbar-none pr-1">
                      {scan.findings.map(f => (
                        <div key={f.id} className="text-[9px] font-mono text-slate-300 flex items-center justify-between border-b border-[#1e293b]/40 pb-0.5">
                          <span className="truncate max-w-[120px]">{f.label}</span>
                          <span className="text-[8px] text-emerald-400 font-bold">{f.confidence}%</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Card footer block showing actions */}
                <div className="p-3 border-t border-[#1e293b] bg-[#020408]/40 flex justify-between items-center">
                  
                  {/* Toggle unredacted original view button */}
                  {scan.findings.length > 0 ? (
                    <button
                      onClick={() => toggleMask(scan.id)}
                      className={`text-xs font-mono flex items-center gap-1 px-2 py-1 rounded transition-colors ${
                        isRedactedActive 
                          ? 'text-yellow-400 hover:text-yellow-300 bg-yellow-500/10 border border-yellow-500/20' 
                          : 'text-slate-400 hover:text-white bg-[#020408]'
                      }`}
                      title={isRedactedActive ? "View Raw unmasked layout" : "Mask private layers"}
                    >
                      {isRedactedActive ? <EyeOff size={12} /> : <Eye size={12} />}
                      {isRedactedActive ? 'Muted' : 'Raw'}
                    </button>
                  ) : (
                    <span className="text-[9px] font-mono text-emerald-500 border border-emerald-500/20 bg-emerald-950/10 px-2 py-1 rounded select-none">
                      PASSED DLP
                    </span>
                  )}

                  <div className="flex gap-1">
                    <button
                      onClick={() => handleDownloadItem(scan)}
                      className="p-1 px-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded border border-[#1e293b] hover:border-slate-750 transition-all font-mono text-[10px]"
                      title="Secure download"
                    >
                      <Download size={12} />
                    </button>
                    
                    {/* Secure permanent delete shred item Button */}
                    <button
                      onClick={() => onDeleteScan(scan.id)}
                      className="p-1 px-2 hover:bg-red-950/20 text-slate-500 hover:text-red-400 rounded border border-[#1e293b] hover:border-red-900/30 transition-all font-mono text-[10px]"
                      title="Permanent shred"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>

                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}
