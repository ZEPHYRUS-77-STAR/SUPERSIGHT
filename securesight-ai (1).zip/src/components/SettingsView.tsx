/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { ToggleLeft, ToggleRight, Shield, ShieldCheck, HelpCircle } from 'lucide-react';
import { PrivacySettings } from '../types';

interface SettingsViewProps {
  onPostLog: (action: string, details: string, status: 'SUCCESS' | 'WARNING' | 'DENIED') => void;
  onRefresh: () => void;
}

export default function SettingsView({ onPostLog, onRefresh }: SettingsViewProps) {
  const [settings, setSettings] = useState<PrivacySettings>({
    enablePII: true,
    enableFace: true,
    enableOCR: true,
    enableNSFW: true,
  });
  const [loading, setLoading] = useState(true);
  const [saveMessage, setSaveMessage] = useState('');

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        setSettings(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching security policy:', err);
        setLoading(false);
      });
  }, []);

  const handleToggle = (key: keyof PrivacySettings) => {
    const updated = {
      ...settings,
      [key]: !settings[key]
    };
    setSettings(updated);
    setSaveMessage('Saving active security directives...');

    // Post to Express backend
    fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    })
      .then(res => res.json())
      .then(data => {
        setSaveMessage('DLP policies applied securely to local daemon.');
        onPostLog(
          'POLICY_APPLIED_DEMON', 
          `DLP scans modified: ${key} flipped to [${updated[key] ? 'ENABLED' : 'DISABLED'}].`, 
          'WARNING'
        );
        onRefresh(); // Trigger global stats/reports sync
        setTimeout(() => setSaveMessage(''), 3000);
      })
      .catch(err => {
        console.error('Error updating DLP criteria:', err);
        setSaveMessage('Policy error: Access Denied.');
      });
  };

  if (loading) {
    return (
      <div className="bg-[#0a0d14]/40 rounded-xl border border-[#1e293b] p-12 text-center text-slate-550 font-mono text-xs">
        Connecting to SecureSight Local policy daemon...
      </div>
    );
  }

  return (
    <div id="settings-container" className="space-y-6 max-w-3xl">
      
      {/* Title block */}
      <div className="bg-[#0a0d14] p-5 rounded-xl border border-[#1e293b] backdrop-blur-md">
        <h3 className="text-md font-semibold text-white font-sans tracking-tight">Active Security Policies</h3>
        <p className="text-xs text-slate-500 font-mono mt-1">
          Customize active computer vision filters. Overriden policies will classify findings but skip blocking/redactions.
        </p>
      </div>

      {/* Main Form switches */}
      <div className="bg-[#0a0d14] rounded-xl border border-[#1e293b] p-5 backdrop-blur-md space-y-6">
        
        {/* Toggle 1: PII Protection */}
        <div className="flex justify-between items-center pb-4 border-b border-[#1e293b]/60">
          <div className="space-y-1 pr-6">
            <h4 className="text-sm font-sans font-medium text-slate-200">Enable PII Protection</h4>
            <p className="text-xs text-slate-500 font-mono">
              Leverage OCR classifiers to block or mask full names, cellular keys, emails, addresses, credit cards, or bank registry values.
            </p>
          </div>
          <button 
            onClick={() => handleToggle('enablePII')}
            className="text-cyan-400 focus:outline-none transition-transform active:scale-95"
          >
            {settings.enablePII ? (
              <ToggleRight size={38} className="text-cyan-400 stroke-1" />
            ) : (
              <ToggleLeft size={38} className="text-slate-750 stroke-1" />
            )}
          </button>
        </div>

        {/* Toggle 2: Face Protection */}
        <div className="flex justify-between items-center pb-4 border-b border-[#1e293b]/60">
          <div className="space-y-1 pr-6">
            <h4 className="text-sm font-sans font-medium text-slate-200">Enable Biometric Face Detection</h4>
            <p className="text-xs text-slate-500 font-mono">
              Apply structural black mask tiles precisely matching human facial templates.
            </p>
          </div>
          <button 
            onClick={() => handleToggle('enableFace')}
            className="text-cyan-400 focus:outline-none transition-transform active:scale-95"
          >
            {settings.enableFace ? (
              <ToggleRight size={38} className="text-cyan-400 stroke-1" />
            ) : (
              <ToggleLeft size={38} className="text-slate-750 stroke-1" />
            )}
          </button>
        </div>

        {/* Toggle 3: OCR Protection */}
        <div className="flex justify-between items-center pb-4 border-b border-[#1e293b]/60">
          <div className="space-y-1 pr-6">
            <h4 className="text-sm font-sans font-medium text-slate-200">Enable OCR Sensitive Text Scans</h4>
            <p className="text-xs text-slate-500 font-mono">
              Scan images for confidential corporate watermarks, financial ledgers, or private stamps.
            </p>
          </div>
          <button 
            onClick={() => handleToggle('enableOCR')}
            className="text-cyan-400 focus:outline-none transition-transform active:scale-95"
          >
            {settings.enableOCR ? (
              <ToggleRight size={38} className="text-cyan-400 stroke-1" />
            ) : (
              <ToggleLeft size={38} className="text-slate-750 stroke-1" />
            )}
          </button>
        </div>

        {/* Toggle 4: NSFW Protection */}
        <div className="flex justify-between items-center pb-3">
          <div className="space-y-1 pr-6">
            <h4 className="text-sm font-sans font-medium text-slate-200">Enable NSFW Explicit Content Protection</h4>
            <p className="text-xs text-slate-500 font-mono">
              Detect explicit features, nudity, or security weapons, and enforce hard upload blocks.
            </p>
          </div>
          <button 
            onClick={() => handleToggle('enableNSFW')}
            className="text-cyan-400 focus:outline-none transition-transform active:scale-95"
          >
            {settings.enableNSFW ? (
              <ToggleRight size={38} className="text-cyan-400 stroke-1" />
            ) : (
              <ToggleLeft size={38} className="text-slate-750 stroke-1" />
            )}
          </button>
        </div>

        {saveMessage && (
          <div className="p-2 border border-cyan-500/10 bg-cyan-950/20 text-center rounded-lg font-mono text-[10px] text-cyan-400">
            {saveMessage}
          </div>
        )}
      </div>

      {/* Security alert footnote */}
      <div className="p-4 rounded-xl border border-[#1e293b] bg-[#020408]/20 backdrop-blur-md flex gap-3 text-xs w-full">
        <ShieldCheck size={20} className="text-cyan-400 flex-shrink-0 mt-0.5" />
        <div className="text-slate-400 font-sans space-y-1">
          <p className="font-semibold text-slate-300">Local Sandbox Security</p>
          <p className="font-mono text-[10px]">
            DLP scanning runs dynamically in memory on port 3000. All operations are local-first. Under HIPAA & GDPR guidelines, zero raw visual content will ever leave this environment.
          </p>
        </div>
      </div>

    </div>
  );
}
