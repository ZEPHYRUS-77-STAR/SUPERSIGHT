/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Camera, RefreshCw, Layers, ShieldCheck, Download, AlertTriangle } from 'lucide-react';
import { ScanResult } from '../types';

interface CameraViewProps {
  onScanCompleted: (result: ScanResult) => void;
  onPostLog: (action: string, details: string, status: 'SUCCESS' | 'WARNING' | 'DENIED') => void;
}

export default function CameraView({ onScanCompleted, onPostLog }: CameraViewProps) {
  const [cameraActive, setCameraActive] = useState(false);
  const [isCapturing, setIsCapturing] = useState(false);
  const [apiResult, setApiResult] = useState<ScanResult | null>(null);
  const [fallbackMessage, setFallbackMessage] = useState('');
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Initialize and check webcam availability
  useEffect(() => {
    startWebcam();
    return () => stopWebcam();
  }, []);

  const startWebcam = async () => {
    setFallbackMessage('');
    try {
      const constraints = { video: { width: 640, height: 480 } };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
        onPostLog('WEBCAM_INITIALIZED', 'Live biometric local camera feed engaged.', 'SUCCESS');
      }
    } catch (err) {
      console.warn('Webcam stream restricted inside safe sandbox iframe', err);
      setCameraActive(false);
      setFallbackMessage('Browser Sandbox constraints active. Engaged SecureSight AI Biometric Feed Simulator.');
      onPostLog('WEBCAM_SIMULATED', 'Emulating virtual optical sensor feed.', 'WARNING');
    }
  };

  const stopWebcam = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const handleCaptureObj = async () => {
    setIsCapturing(true);
    let capturedBase64 = '';

    if (cameraActive && videoRef.current && canvasRef.current) {
      // Draw actual frames from current camera thread
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        capturedBase64 = canvas.toDataURL('image/jpeg', 0.9);
      }
    } else {
      // Fallback emulated layout: Create a high-fidelity mock image with a simulated face bounding circle
      const canvas = document.createElement('canvas');
      canvas.width = 640;
      canvas.height = 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Render stylized grid cyber background
        ctx.fillStyle = '#060a12';
        ctx.fillRect(0, 0, 640, 480);
        
        ctx.strokeStyle = 'rgba(0, 100, 255, 0.15)';
        ctx.lineWidth = 1;
        for (let x = 0; x < 640; x += 30) {
          ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, 480); ctx.stroke();
        }
        for (let y = 0; y < 480; y += 30) {
          ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(640, y); ctx.stroke();
        }

        // Draw a simulated face target biometric framework
        ctx.strokeStyle = '#059669';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(320, 200, 85, 0, Math.PI * 2);
        ctx.stroke();

        // Biometric scanning matrices
        ctx.fillStyle = 'rgba(5, 150, 105, 0.15)';
        ctx.beginPath();
        ctx.arc(320, 200, 85, 0, Math.PI * 2);
        ctx.fill();

        ctx.font = '10px monospace';
        ctx.fillStyle = '#10b981';
        ctx.fillText('SCANNING VIRTUAL TARGET: SEV-2 BIOMETRIC', 220, 310);
        ctx.fillText('SENSITIVE OBJECT REGISTERS ACTIVE', 230, 330);

        capturedBase64 = canvas.toDataURL('image/jpeg');
      }
    }

    if (!capturedBase64) {
      setIsCapturing(false);
      return;
    }

    try {
      // Route snapshot to backend
      const response = await fetch('/api/scans/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: capturedBase64,
          name: `camera_capture_${Math.floor(Date.now() / 1000)}.jpg`,
          source: 'CAMERA'
        })
      });

      if (!response.ok) throw new Error('Capture analysis crash');
      
      const scanResult: ScanResult = await response.json();
      setApiResult(scanResult);
      onScanCompleted(scanResult);
      onPostLog('CAPTURE_AUDITED', `Interactive snapshot scan finished. Risk rating: ${scanResult.riskLevel}`, 'SUCCESS');

    } catch (err) {
      console.error(err);
      onPostLog('CAPTURE_FAULT', 'Failed to process snapshot on Express pipeline.', 'DENIED');
    } finally {
      setIsCapturing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Live Lens / Simulator Display column */}
      <div className="lg:col-span-2 space-y-4">
        <div id="camera-viewport" className="relative bg-[#0a0d14] rounded-xl border border-[#1e293b] p-4 backdrop-blur-md flex flex-col items-center">
          <div className="w-full flex justify-between items-center border-b border-[#1e293b] pb-2 mb-4">
            <span className="text-xs font-mono text-slate-400 uppercase">SecureSight Camera Lens</span>
            <span className={`text-[10px] font-mono flex items-center gap-1 px-2 py-0.5 rounded ${
              cameraActive ? 'bg-emerald-950/30 text-emerald-400 border border-emerald-500/20' : 'bg-cyan-950/30 text-cyan-400 border border-cyan-500/20 animate-pulse'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${cameraActive ? 'bg-emerald-500 animate-ping' : 'bg-cyan-400'}`} />
              {cameraActive ? 'OPTICAL FEED ACTIVE' : 'SIMULATION MODE ENGAGED'}
            </span>
          </div>

          {/* Fallback container if webcam is denied or unavailable */}
          <div className="relative w-full h-[360px] bg-[#020408]/40 rounded-lg border border-[#1e293b] overflow-hidden flex items-center justify-center">
            {cameraActive ? (
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                className="w-full h-full object-cover scale-x-[-1]" 
              />
            ) : (
              <div className="absolute inset-0 flex flex-col justify-center items-center p-8 text-center select-none">
                {/* Cyber Scan Grid Animation */}
                <span className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-cyan-500/5 to-transparent border-b border-cyan-500/20 animate-pulse" />
                <Camera size={44} className="text-cyan-500/20 mb-3 animate-spin duration-[3000ms]" />
                <p className="text-xs text-cyan-400 uppercase font-mono tracking-widest font-semibold">Biometric Target Radar Active</p>
                <p className="text-[10px] text-slate-500 font-mono mt-2 max-w-sm">
                  {fallbackMessage || 'Initial lens scan engaged. Running emulated target matrices.'}
                </p>
              </div>
            )}
            
            {/* Crosshair decoration */}
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="w-10 h-10 border border-cyan-500/20 rounded-full flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-cyan-500/30 rounded-full" />
              </div>
            </div>
          </div>

          <canvas ref={canvasRef} className="hidden" />

          {/* Capture Trigger Bar */}
          <div className="w-full flex justify-center pt-4 border-t border-[#1e293b] mt-2">
            <button
              onClick={handleCaptureObj}
              disabled={isCapturing}
              className="px-8 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 hover:shadow-lg hover:shadow-cyan-500/10 font-sans font-bold text-sm rounded-xl transition-all flex items-center gap-2"
            >
              <Camera size={16} />
              {isCapturing ? 'Running AI Diagnostics...' : 'Capture Secure Stream'}
            </button>
          </div>
        </div>
      </div>

      {/* Immediate Results Sidebar columns */}
      <div className="lg:col-span-1 space-y-6">
        <div id="camera-diagnostics" className="bg-[#0a0d14] rounded-xl border border-[#1e293b] p-5 backdrop-blur-md h-[465px] flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white font-sans tracking-tight mb-1">Target Diagnostics Ledger</h3>
            <p className="text-xs text-slate-500 font-mono">DLP pipeline results for current stream</p>
          </div>

          {!apiResult ? (
            <div className="my-12 text-center py-10 border border-dashed border-[#1e293b] rounded-lg">
              <Layers size={28} className="mx-auto text-slate-700 mb-3" />
              <p className="text-xs text-slate-500 font-mono">No captures logged. Deploy and snap frame above to trigger audit logs.</p>
            </div>
          ) : (
            <div className="space-y-4 my-4 overflow-y-auto flex-grow select-none">
              
              {/* Score bar */}
              <div className="p-3 bg-[#020408]/60 rounded border border-[#1e293b]/60 flex justify-between items-center font-mono text-xs">
                <span className="text-slate-400">Threat Rating:</span>
                <span className={`font-bold ${
                  apiResult.riskLevel === 'HIGH' ? 'text-red-500 animate-pulse' : apiResult.riskLevel === 'MEDIUM' ? 'text-yellow-400' : 'text-green-400'
                }`}>
                  {apiResult.riskScore} / 100 [{apiResult.riskLevel}]
                </span>
              </div>

              {/* Bounding box matches details */}
              <div className="space-y-2">
                <span className="text-[10px] font-mono text-slate-500 uppercase font-semibold">Artifact coordinates found:</span>
                
                {apiResult.findings.length === 0 ? (
                  <p className="text-xs text-emerald-400 font-mono py-2">✓ No sensitive tags detected in stream.</p>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {apiResult.findings.map(f => (
                      <div key={f.id} className="p-2 bg-[#020408]/20 border border-[#1e293b] rounded font-mono text-[10px] flex justify-between items-center">
                        <span className="text-slate-300 truncate max-w-[120px]">{f.label}</span>
                        <span className="text-[9px] text-slate-500">Box: {f.bbox ? `[${f.bbox.join(',')}]` : 'N/A'}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Policies decision alert block */}
              <div className="p-3 bg-[#020408]/40 rounded border border-[#1e293b] text-[10px] font-mono space-y-1.5 text-slate-400">
                <div className="flex justify-between">
                  <span>DLP INTERCEPT RULE:</span>
                  <span className={apiResult.riskLevel === 'HIGH' ? 'text-red-500 font-bold' : 'text-green-500'}>
                    {apiResult.riskLevel === 'HIGH' ? 'SHUTDOWN_SYNC' : 'ALLOW_REDACT'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>AES DATABASE SAVE:</span>
                  <span className="text-emerald-400 font-bold">SUCCESS</span>
                </div>
              </div>

            </div>
          )}

          <div className="text-[10px] text-slate-500 font-mono border-t border-[#1e293b] pt-3 font-semibold">
            SECURESIGHT LOCAL HARDWARE WRAPPER
          </div>
        </div>
      </div>

    </div>
  );
}
