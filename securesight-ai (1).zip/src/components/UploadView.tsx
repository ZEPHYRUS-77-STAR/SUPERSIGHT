/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Upload, File, ShieldAlert, Sparkles, Check, Download, AlertCircle, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import { ScanResult, ScanFinding } from '../types';

interface UploadViewProps {
  onScanCompleted: (result: ScanResult) => void;
  onPostLog: (action: string, details: string, status: 'SUCCESS' | 'WARNING' | 'DENIED') => void;
}

interface QueuedFile {
  id: string;
  name: string;
  size: string;
  progress: number;
  status: 'PENDING' | 'SCANNING' | 'COMPILING' | 'GENERATED' | 'FAILED';
  stepText: string;
  base64: string;
}

export default function UploadView({ onScanCompleted, onPostLog }: UploadViewProps) {
  const [dragActive, setDragActive] = useState(false);
  const [queue, setQueue] = useState<QueuedFile[]>([]);
  const [activeResult, setActiveResult] = useState<ScanResult | null>(null);
  const [previewMode, setPreviewMode] = useState<'ORIGINAL' | 'REDACED'>('REDACED');
  const [isUploadingDestination, setIsUploadingDestination] = useState(false);
  const [uploadMessage, setUploadMessage] = useState('');
  
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Trigger file processing when a queue item is complete
  useEffect(() => {
    const activeScan = queue.find(f => f.status === 'SCANNING');
    if (activeScan) {
      // Simulate pipeline delay
      const timer = setTimeout(() => {
        // Upgrade stage
        setQueue(prev => prev.map(item => 
          item.id === activeScan.id 
            ? { ...item, status: 'COMPILING', stepText: 'Compiling security risk matrices...' } 
            : item
        ));
      }, 1000);
      return () => clearTimeout(timer);
    }

    const compileScan = queue.find(f => f.status === 'COMPILING');
    if (compileScan) {
      const timer = setTimeout(() => {
        executeAnalysisAPI(compileScan);
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [queue]);

  // Hook to draw on HTML5 Canvas once dynamic redaction runs
  useEffect(() => {
    if (activeResult && canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const img = new Image();
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);

        // Standard black box or dynamic segment blur redactions
        if (previewMode === 'REDACED') {
          activeResult.findings.forEach(finding => {
            // Check if there is a YOLO-World/Grounding DINO high-precision segmentation mask
            if (finding.maskPolygon && finding.maskPolygon.length > 0) {
              // 1. Precise Region-Specific Segment Blur (OpenCV Gaussian Blur simulation inside the mask)
              ctx.save();
              ctx.beginPath();
              const p0 = finding.maskPolygon[0];
              ctx.moveTo((p0[0] / 100.0) * img.width, (p0[1] / 100.0) * img.height);
              for (let i = 1; i < finding.maskPolygon.length; i++) {
                const p = finding.maskPolygon[i];
                ctx.lineTo((p[0] / 100.0) * img.width, (p[1] / 100.0) * img.height);
              }
              ctx.closePath();
              ctx.clip();
              ctx.filter = 'blur(22px)'; // Apply high-precision Gaussian Blur inside mask region
              ctx.drawImage(img, 0, 0);
              ctx.restore();

              // 2. High-Tech Translucent Red Segment Fill
              ctx.save();
              ctx.beginPath();
              const pf0 = finding.maskPolygon[0];
              ctx.moveTo((pf0[0] / 100.0) * img.width, (pf0[1] / 100.0) * img.height);
              for (let i = 1; i < finding.maskPolygon.length; i++) {
                const p = finding.maskPolygon[i];
                ctx.lineTo((p[0] / 100.0) * img.width, (p[1] / 100.0) * img.height);
              }
              ctx.closePath();
              ctx.fillStyle = 'rgba(239, 68, 68, 0.35)'; // Crimson target overlay
              ctx.fill();
              ctx.restore();

              // 3. Sharp Laser Outline with Radial Glow Effect
              ctx.save();
              ctx.beginPath();
              const pl0 = finding.maskPolygon[0];
              ctx.moveTo((pl0[0] / 100.0) * img.width, (pl0[1] / 100.0) * img.height);
              for (let i = 1; i < finding.maskPolygon.length; i++) {
                const p = finding.maskPolygon[i];
                ctx.lineTo((p[0] / 100.0) * img.width, (p[1] / 100.0) * img.height);
              }
              ctx.closePath();
              ctx.strokeStyle = '#ef4444'; // Solid Red Vector line
              ctx.lineWidth = 2;
              ctx.shadowColor = 'rgba(239, 68, 68, 0.8)';
              ctx.shadowBlur = 8;
              ctx.stroke();
              ctx.restore();

              // 4. Anchor Point Vertices
              finding.maskPolygon.forEach(p => {
                const px = (p[0] / 100.0) * img.width;
                const py = (p[1] / 100.0) * img.height;
                ctx.fillStyle = '#ffffff';
                ctx.strokeStyle = '#ef4444';
                ctx.lineWidth = 1;
                ctx.fillRect(px - 3, py - 3, 6, 6);
                ctx.strokeRect(px - 3, py - 3, 6, 6);
              });

              // 5. YOLO-World Target Bounding Label Overlay
              if (finding.bbox) {
                const [ymin_pct, xmin_pct] = finding.bbox;
                const ymin = (ymin_pct / 100.0) * img.height;
                const xmin = (xmin_pct / 100.0) * img.width;

                ctx.fillStyle = '#ef4444';
                ctx.font = 'bold 9px monospace';
                ctx.fillText('YOLO-WORLD // DINO SEGMENT LOCKED', xmin + 4, ymin + 14);
              }
              return; // Skip normal rect blur
            }

            // Keep faces and non-sensitive markings completely unblurred
            if (finding.category === 'FACE') {
              if (finding.bbox) {
                const [ymin_pct, xmin_pct, ymax_pct, xmax_pct] = finding.bbox;
                const ymin = (ymin_pct / 100.0) * img.height;
                const xmin = (xmin_pct / 100.0) * img.width;
                const ymax = (ymax_pct / 100.0) * img.height;
                const xmax = (xmax_pct / 100.0) * img.width;
                const w = xmax - xmin;
                const h = ymax - ymin;

                ctx.strokeStyle = 'rgba(16, 185, 129, 0.7)'; // Emerald human-mapping bezel frame
                ctx.lineWidth = 1.5;
                ctx.strokeRect(xmin, ymin, w, h);

                // Add nice clean non-obstructive label
                ctx.fillStyle = '#10b981';
                ctx.font = 'bold 10px monospace';
                ctx.fillText('FACE (SAFE_UNBLURRED)', xmin + 4, ymin + 14);
              }
              return;
            }

            // Apply standard region-specific blur for sensitive contents (PII, DOC_GOVT, etc.)
            if (finding.bbox) {
              const [ymin_pct, xmin_pct, ymax_pct, xmax_pct] = finding.bbox;
              
              const ymin = (ymin_pct / 100.0) * img.height;
              const xmin = (xmin_pct / 100.0) * img.width;
              const ymax = (ymax_pct / 100.0) * img.height;
              const xmax = (xmax_pct / 100.0) * img.width;

              const w = xmax - xmin;
              const h = ymax - ymin;

              // Blur specific region only using clip mask + ctx.filter
              ctx.save();
              ctx.beginPath();
              ctx.rect(xmin, ymin, w, h);
              ctx.clip();
              ctx.filter = 'blur(18px)';
              ctx.drawImage(img, 0, 0);
              ctx.restore();

              // Highlight with subtle cyan DLP bounding indicator
              ctx.strokeStyle = 'rgba(34, 211, 238, 0.6)';
              ctx.lineWidth = 1.5;
              ctx.strokeRect(xmin, ymin, w, h);
            }
          });
        }
      };
      img.src = activeResult.originalImage;
    }
  }, [activeResult, previewMode]);

  const executeAnalysisAPI = async (queuedFile: QueuedFile) => {
    try {
      const response = await fetch('/api/scans/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: queuedFile.base64,
          name: queuedFile.name,
          source: 'UPLOAD'
        }),
      });

      if (!response.ok) throw new Error('API processing fault');
      
      const scanResult: ScanResult = await response.json();
      
      // Update queue
      setQueue(prev => prev.map(item => 
        item.id === queuedFile.id 
          ? { ...item, status: 'GENERATED', progress: 100, stepText: 'Risk scoring calculated.' } 
          : item
      ));

      setActiveResult(scanResult);
      onScanCompleted(scanResult);
    } catch (err) {
      console.error(err);
      setQueue(prev => prev.map(item => 
        item.id === queuedFile.id 
          ? { ...item, status: 'FAILED', stepText: 'AI analysis aborted.' } 
          : item
      ));
      onPostLog('UPLOAD_SCAN_FAILED', `Failed to audit file: ${queuedFile.name}`, 'WARNING');
    }
  };

  const processSelectedFiles = (files: FileList) => {
    // Limits simultaneous uploads to 5 images
    const selectedList = Array.from(files).slice(0, 5);
    onPostLog('QUEUE_STARTED', `Ingested ${selectedList.length} files into DLP buffer.`, 'SUCCESS');

    selectedList.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        if (!base64) return;

        const sizeInKB = (file.size / 1024).toFixed(1) + ' KB';
        const queuedItem: QueuedFile = {
          id: 'q-file-' + Math.random().toString(36).substr(2, 9),
          name: file.name,
          size: sizeInKB,
          progress: 25,
          status: 'PENDING',
          stepText: 'Awaiting pipeline thread...',
          base64: base64,
        };

        setQueue(prev => {
          const updated = [...prev, queuedItem];
          // Auto-trigger scanning on first pending
          if (updated.filter(x => x.status === 'SCANNING' || x.status === 'COMPILING').length === 0) {
            updated[updated.length - 1].status = 'SCANNING';
            updated[updated.length - 1].progress = 60;
            updated[updated.length - 1].stepText = 'Invoking OCR multi-lens modules...';
          }
          return updated;
        });
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processSelectedFiles(e.dataTransfer.files);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processSelectedFiles(e.target.files);
    }
  };

  const triggerSelect = () => {
    fileInputRef.current?.click();
  };

  const clearQueue = () => {
    setQueue([]);
    setActiveResult(null);
  };

  // Safe download trigger
  const handleDownloadRedacted = () => {
    if (!canvasRef.current || !activeResult) return;
    const canvas = canvasRef.current;
    const uri = canvas.toDataURL('image/jpeg', 0.9);
    
    const link = document.createElement('a');
    link.download = `SecureSight_Redacted_${activeResult.name}`;
    link.href = uri;
    link.click();
    onPostLog('DOWNLOAD_REDACTED', `Redacted matrix download executed for ${activeResult.name}`, 'SUCCESS');
  };

  // Handles real uploads to cloud/destination
  const handleUploadDLPDecision = async (action: 'UPLOAD_ORIGINAL' | 'UPLOAD_PROTECTED') => {
    if (!activeResult) return;
    setIsUploadingDestination(true);
    setUploadMessage('Synchronizing with safe storage network...');

    try {
      const response = await fetch('/api/scans/upload-decision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scanId: activeResult.id,
          action: action
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Enterprise policy prevented sync action');
      }

      setUploadMessage('Sync completed! Image successfully loaded to compliant corporate silo.');
      onPostLog('UPLOAD_COMPLETED', `Synchronized ${activeResult.name} using [${action}] schema.`, 'SUCCESS');
      
      // Update local state scan result
      setActiveResult(prev => prev ? { ...prev, uploadStatus: 'UPLOADED' } : null);
    } catch (err: any) {
      console.error(err);
      setUploadMessage(err.message || 'DLP Interdiction active: payload blocked.');
    } finally {
      setIsUploadingDestination(false);
    }
  };

  const scoreColor = activeResult 
    ? activeResult.riskScore >= 70 ? 'text-red-500Border border-red-500/20 bg-red-950/20' :
      activeResult.riskScore >= 40 ? 'text-yellow-400Border border-yellow-500/20 bg-yellow-950/20' :
      'text-green-400Border border-green-500/20 bg-green-950/20'
    : '';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Upload Zone & Queues Left block */}
      <div className="space-y-6 lg:col-span-1">
        {/* Dropzone container */}
        <div id="dropzone-box" className="bg-[#0a0d14] rounded-xl border border-[#1e293b] p-5 backdrop-blur-md">
          <h3 className="text-sm font-semibold text-white font-sans tracking-tight mb-3">DLP Security Dropzone</h3>
          
          <div
            id="drag-area"
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={triggerSelect}
            className={`flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-xl cursor-pointer transition-all ${
              dragActive 
                ? 'border-cyan-500 bg-cyan-500/5' 
                : 'border-[#1e293b] bg-[#020408]/30 hover:border-slate-700 hover:bg-[#020408]/60'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />
            <Upload size={32} className={`${dragActive ? 'text-cyan-400 animate-bounce' : 'text-slate-500'} mb-3`} />
            <p className="text-xs text-slate-200 font-sans font-medium text-center">Drag & drop files or click to scan</p>
            <p className="text-[10px] text-slate-500 font-mono text-center mt-1">Accepts multiple images / folder directories (Max 5)</p>
          </div>
        </div>

        {/* Processing Buffer block */}
        <div id="queue-box" className="bg-[#0a0d14] rounded-xl border border-[#1e293b] p-4 backdrop-blur-md">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs font-semibold text-slate-300">File Ingestion Queue</span>
            {queue.length > 0 && (
              <button onClick={clearQueue} className="text-[10px] font-mono text-slate-500 hover:text-red-400 transition-colors">
                CLEAR COMPLETED
              </button>
            )}
          </div>

          {queue.length === 0 ? (
            <div className="text-center py-6 border border-[#1e293b] rounded-lg">
              <File size={20} className="mx-auto text-slate-700 mb-2" />
              <p className="text-xs text-slate-500 font-mono">DLP buffer is empty</p>
            </div>
          ) : (
            <div className="space-y-3">
              {queue.map(item => (
                <div key={item.id} className="p-3 bg-[#020408]/30 rounded border border-[#1e293b]/60 font-mono text-xs">
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="truncate max-w-[150px] font-medium" title={item.name}>{item.name}</span>
                    <span className="text-[9px] text-slate-500">{item.size}</span>
                  </div>
                  
                  {/* Progress Bar indications */}
                  <div className="my-2 h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className={`h-full transition-all duration-500 ${
                        item.status === 'GENERATED' ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' :
                        item.status === 'FAILED' ? 'bg-red-500' : 'bg-cyan-500 shadow-[0_0_8px_#22d3ee]'
                      }`}
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>

                  <div className="flex justify-between items-center text-[10px]">
                    <span className="text-slate-500">{item.stepText}</span>
                    <span className={`font-semibold ${
                      item.status === 'GENERATED' ? 'text-emerald-400' :
                      item.status === 'FAILED' ? 'text-red-400' : 'text-cyan-400 animate-pulse'
                    }`}>
                      {item.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main Analysis Display Results Right Blocks */}
      <div id="results-panel" className="lg:col-span-2">
        {!activeResult ? (
          <div className="bg-[#0a0d14]/40 rounded-xl border border-[#1e293b] p-12 backdrop-blur-md flex flex-col justify-center items-center text-center h-[525px]">
            <Sparkles size={40} className="text-cyan-500/20 mb-4 animate-pulse" />
            <h3 className="text-md font-medium text-slate-400">Cybersecurity Scanning Feed</h3>
            <p className="text-xs text-slate-500 font-mono mt-1 max-w-sm">
              Upload an image in the Dropzone on the left. The engine will instantly run deep OCR text extracts, identify face templates, and compute localized risk classifications.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* Risk Title details bar */}
            <div className={`p-4 rounded-xl border ${
              activeResult.riskLevel === 'HIGH' ? 'border-red-500/20 bg-red-950/20 text-red-100' :
              activeResult.riskLevel === 'MEDIUM' ? 'border-yellow-500/20 bg-yellow-950/20 text-yellow-100' :
              'border-[#1e293b] bg-emerald-950/10 text-emerald-100'
            } backdrop-blur-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4`}>
              <div className="flex items-center gap-3">
                <AlertCircle size={24} className={activeResult.riskLevel === 'HIGH' ? 'text-red-400' : activeResult.riskLevel === 'MEDIUM' ? 'text-yellow-400' : 'text-emerald-400'} />
                <div>
                  <h4 className="text-sm font-semibold uppercase tracking-wider font-sans">
                    DLP Interdiction Result: {activeResult.riskLevel} Risk Classification
                  </h4>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    File: {activeResult.name} // Score: {activeResult.riskScore} out of 100
                  </p>
                </div>
              </div>

              {/* Score animated radial indicator */}
              <div className="flex items-center gap-3 bg-[#020408]/40 px-3 py-1.5 rounded-lg border border-[#1e293b]">
                <span className="text-[10px] font-mono text-slate-500 uppercase font-medium">Risk Score:</span>
                <span className={`text-md font-bold font-mono ${
                  activeResult.riskLevel === 'HIGH' ? 'text-red-500' : activeResult.riskLevel === 'MEDIUM' ? 'text-yellow-400' : 'text-emerald-400'
                }`}>
                  {activeResult.riskScore} / 100
                </span>
              </div>
            </div>

            {/* Simple Warning for Individual Documents if any are detected */}
            {(activeResult.findings.some(f => f.category === 'DOC_GOVT') || 
              activeResult.name.toLowerCase().includes('passport') || 
              activeResult.name.toLowerCase().includes('aadhaar') || 
              activeResult.name.toLowerCase().includes('pan') || 
              activeResult.name.toLowerCase().includes('id') ||
              activeResult.name.toLowerCase().includes('license') ||
              activeResult.riskScore <= 15) && (
              <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg text-xs text-yellow-400 font-mono flex items-center gap-2">
                <AlertTriangle size={16} className="text-yellow-400 animate-pulse flex-shrink-0" />
                <div>
                  <strong>[SAFE_UPLOAD_NOTICE]:</strong> Individual ID documents detected. These are categorized under VERY LOW RISK and are completely safe to upload. Standard filters will blur specific sensitive regions only.
                </div>
              </div>
            )}

            {/* Custom alert warning for Weapons & Military hardware items */}
            {activeResult.findings.some(f => f.category === 'SECURITY_RISK' && (
              f.label.toLowerCase().includes('weapon') ||
              f.label.toLowerCase().includes('military') ||
              f.label.toLowerCase().includes('tank') ||
              f.label.toLowerCase().includes('pistol') ||
              f.label.toLowerCase().includes('rifle') ||
              f.label.toLowerCase().includes('target') ||
              f.label.toLowerCase().includes('drone') ||
              f.label.toLowerCase().includes('jet') ||
              f.label.toLowerCase().includes('explosive') ||
              f.label.toLowerCase().includes('grenade') ||
              f.label.toLowerCase().includes('tactical')
            )) && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-xs text-red-400 font-mono flex items-center gap-2">
                <ShieldAlert size={16} className="text-red-400 animate-pulse flex-shrink-0" />
                <div>
                  <strong>[CRITICAL_WEAPON_ALERT]:</strong> Weapons or military assets have been locked by Grounding DINO and YOLO-World. Real-time segmentation masking is active around findings, and sharing privileges have been strictly restricted.
                </div>
              </div>
            )}

            {/* Canvas Redactor / Image Visualizer */}
            <div id="viewport-box" className="bg-[#0a0d14] rounded-xl border border-[#1e293b] p-4 backdrop-blur-md flex flex-col items-center">
              <div className="w-full flex justify-between items-center border-b border-[#1e293b] pb-2 mb-4">
                <span className="text-xs font-mono text-slate-400 uppercase">Interactive Redactor Stage</span>
                
                {/* Mode Toggle switches */}
                <div className="flex gap-2 bg-[#020408] p-1 rounded border border-[#1e293b]">
                  <button 
                    onClick={() => setPreviewMode('REDACED')}
                    className={`px-3 py-1 rounded text-[10px] font-mono transition-all flex items-center gap-1.5 ${
                      previewMode === 'REDACED' ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <EyeOff size={12} /> Redacted View
                  </button>
                  <button 
                    onClick={() => setPreviewMode('ORIGINAL')}
                    className={`px-3 py-1 rounded text-[10px] font-mono transition-all flex items-center gap-1.5 ${
                      previewMode === 'ORIGINAL' ? 'bg-slate-800 text-slate-100 border border-slate-700' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Eye size={12} /> Raw Image
                  </button>
                </div>
              </div>

              {/* Standard Canvas Element */}
              <div className="relative border border-[#1e293b] rounded-lg overflow-hidden bg-[#020408]/20 max-h-[400px] flex items-center justify-center p-2 mb-2 w-full">
                <canvas 
                  ref={canvasRef} 
                  className="max-h-[350px] object-contain rounded shadow-lg select-none"
                  style={{ maxHeight: '350px', maxWidth: '100%' }}
                />
              </div>

              {/* Contextual DLP Actions block */}
              <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-3 border-t border-[#1e293b] pt-4 mt-2">
                
                <button
                  onClick={handleDownloadRedacted}
                  className="w-full py-2 bg-cyan-950/20 hover:bg-cyan-900/10 border border-cyan-500/20 text-cyan-400 font-sans font-medium text-xs rounded-lg transition-all flex items-center justify-center gap-1.5"
                >
                  <Download size={14} /> Download Redacted Jpeg
                </button>

                {activeResult.riskLevel === 'HIGH' ? (
                  <div className="md:col-span-2 py-2 bg-red-950/20 border border-red-500/30 text-red-400 text-xs text-center font-mono rounded-lg flex items-center justify-center gap-1.5">
                    <ShieldAlert size={14} /> UPLOAD LOCKED BY ENTERPRISE POLICY
                  </div>
                ) : (
                  <>
                    <button
                      onClick={() => handleUploadDLPDecision('UPLOAD_PROTECTED')}
                      disabled={isUploadingDestination}
                      className="py-2 bg-cyan-500 hover:bg-cyan-400 text-[#020408] border border-cyan-500 font-sans font-semibold text-xs rounded-lg transition-all"
                    >
                      {activeResult.riskLevel === 'MEDIUM' ? 'Upload Refined Copy' : 'Upload Secure Copy'}
                    </button>
                    <button
                      onClick={() => handleUploadDLPDecision('UPLOAD_ORIGINAL')}
                      disabled={isUploadingDestination || activeResult.riskLevel === 'MEDIUM'}
                      className={`py-2 text-xs font-sans font-medium rounded-lg transition-all border ${
                        activeResult.riskLevel === 'MEDIUM' 
                          ? 'bg-[#020408]/20 border-transparent text-slate-600 cursor-not-allowed' 
                          : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300 hover:text-white'
                      }`}
                    >
                      Upload Original Raw
                    </button>
                  </>
                )}
              </div>

              {uploadMessage && (
                <div className="w-full mt-3 p-2 bg-[#020408]/60 rounded border border-[#1e293b] text-[10px] font-mono text-center text-cyan-400">
                  {uploadMessage}
                </div>
              )}
            </div>

            {/* Extracted DLP Metrics coordinates details */}
            <div id="findings-grid" className="bg-[#0a0d14] rounded-xl border border-[#1e293b] p-4 backdrop-blur-md">
              <h4 className="text-xs font-semibold text-slate-300 mb-3">Audited File Bounding Logs</h4>
              
              {activeResult.findings.length === 0 ? (
                <p className="text-xs text-emerald-400/80 font-mono py-2">
                  ✓ NO SENSITIVE ARTIFACTS FOUND. File is marked [SAFE_TO_SHARE].
                </p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-[10px]">
                    <thead>
                      <tr className="border-b border-[#1e293b] text-slate-400">
                        <th className="pb-2">Risk Category</th>
                        <th className="pb-2">Security Description</th>
                        <th className="pb-2 text-right">Coordinate Box [%]</th>
                        <th className="pb-2 text-right">Confidence %</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1e293b] text-slate-300">
                      {activeResult.findings.map(f => (
                        <tr key={f.id} className="hover:bg-white/5">
                          <td className="py-2">
                            <span className={`px-2 py-0.5 rounded text-[8px] font-bold ${
                              f.category === 'PII' ? 'bg-yellow-900/30 text-yellow-400 border border-yellow-500/20' :
                              f.category === 'FACE' ? 'bg-cyan-900/30 text-cyan-400 border border-cyan-500/20' :
                              f.category === 'DOC_GOVT' ? 'bg-red-900/30 text-red-500 border border-red-500/20' :
                              'bg-purple-900/30 text-purple-400 border border-purple-500/20'
                            }`}>
                              {f.category}
                            </span>
                          </td>
                          <td className="py-2 truncate max-w-[250px]">{f.label}</td>
                          <td className="py-2 text-right text-slate-500">
                            {f.bbox ? `[${f.bbox.join(',')}]` : 'N/A'}
                          </td>
                          <td className="py-2 text-right text-emerald-400 font-bold">{f.confidence}%</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

          </div>
        )}
      </div>

    </div>
  );
}
