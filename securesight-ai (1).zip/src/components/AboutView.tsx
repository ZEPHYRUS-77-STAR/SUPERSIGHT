/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, Key, Brain, Cpu, Shield } from 'lucide-react';

export default function AboutView() {
  return (
    <div id="about-container" className="space-y-6 max-w-4xl font-sans text-slate-300">
      
      {/* Hero card */}
      <div className="bg-[#0a0d14] p-6 rounded-xl border border-[#1e293b] backdrop-blur-md">
        <h3 className="text-xl font-bold font-sans text-white tracking-tight flex items-center gap-2">
          <Shield className="text-cyan-400 animate-pulse" size={22} /> About SecureSight AI
        </h3>
        <p className="text-sm text-cyan-400 mt-2 font-mono font-medium">
          Automated Local-First Data Loss Prevention (DLP) & Visual Redaction Shell
        </p>
      </div>

      {/* Grid splits */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Module 1: Mission */}
        <div className="bg-[#0a0d14] p-5 rounded-xl border border-[#1e293b] backdrop-blur-md space-y-3">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold font-sans text-sm">
            <BookOpen size={16} /> Product Mission
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            SecureSight AI shields your organization from accidental compliance leaks. It intercepts, audits, and redacts sensitive visual data—like Government Passports, credit cards, facial biometrics, and credentials—before they synchronize to unencrypted clouds or shared Slack/Teams channels.
          </p>
        </div>

        {/* Module 2: Tech Specs */}
        <div className="bg-[#0a0d14] p-5 rounded-xl border border-[#1e293b] backdrop-blur-md space-y-3">
          <div className="flex items-center gap-2 text-cyan-450 text-cyan-400 font-semibold font-sans text-sm">
            <Cpu size={16} /> Technology Stack
          </div>
          <div className="text-[11px] font-mono text-slate-400 space-y-1">
            <p>• <strong className="text-cyan-400 font-sans font-medium">Core Model:</strong> Gemini 3.5 AI Multimodal Vision</p>
            <p>• <strong className="text-cyan-400 font-sans font-medium">DLP Core:</strong> SOLID Black-Box Redaction / OpenCV</p>
            <p>• <strong className="text-cyan-400 font-sans font-medium">Backend:</strong> Node.js Express server with Python core stubs</p>
            <p>• <strong className="text-cyan-400 font-sans font-medium">Frontend:</strong> React 19, Vite, Tailwind CSS, Framer Motion</p>
            <p>• <strong className="text-cyan-400 font-sans font-medium">Desktop Shell:</strong> Electron Wrapper</p>
          </div>
        </div>

        {/* Module 3: Security Architecture */}
        <div className="bg-[#0a0d14] p-5 rounded-xl border border-[#1e293b] backdrop-blur-md space-y-3">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold font-sans text-sm">
            <Key size={16} /> Security Architecture
          </div>
          <ul className="text-xs text-slate-400 space-y-2 leading-relaxed list-disc pl-4">
            <li>
              <strong>Memory Bound Processing:</strong> Captured frames are evaluated on-the-fly and never written to unencrypted disks.
            </li>
            <li>
              <strong>AES 256 Storage:</strong> Local SQLite histories are encrypted using a cryptographic salt key generated at boot.
            </li>
            <li>
              <strong>Zero Leak Policy:</strong> Enforces mandatory blockers for High-Risk categories (Passports, SSN, weapons). Unredacted records cannot bypass the router.
            </li>
          </ul>
        </div>

        {/* Module 4: Non-Technical Benefits */}
        <div className="bg-[#0a0d14] p-5 rounded-xl border border-[#1e293b] backdrop-blur-md space-y-3">
          <div className="flex items-center gap-2 text-cyan-450 text-cyan-400 font-semibold font-sans text-sm">
            <Brain size={16} /> Compliance & Privacy
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            For individual users, SecureSight keeps home snapshots safe before online storage. For businesses, it provides continuous automated HIPAA, PCI-DSS, and GDPR compliance, turning files into safe, fully cleaned PDFs or images effortlessly without altering your team's workflow.
          </p>
        </div>

      </div>

    </div>
  );
}
