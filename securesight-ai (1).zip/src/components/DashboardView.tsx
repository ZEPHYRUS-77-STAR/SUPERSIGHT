/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Shield, Eye, AlertTriangle, CheckCircle, FileText, Activity } from 'lucide-react';
import { AuditLog, DashboardStats } from '../types';

interface DashboardViewProps {
  stats: DashboardStats;
  logs: AuditLog[];
  onRefresh: () => void;
  onSimulateWatchdog: () => void;
}

export default function DashboardView({ stats, logs, onRefresh, onSimulateWatchdog }: DashboardViewProps) {
  const [trends, setTrends] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/reports')
      .then((res) => res.json())
      .then((data) => {
        setTrends(data.riskTrends || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching trend reports:', err);
        setLoading(false);
      });
  }, [stats]);

  // Generate tactical network coordinate decorations
  const gridCoords = Array.from({ length: 6 }, (_, i) => `0x00F8C${i * 4}`);

  return (
    <div id="dashboard-container" className="space-y-6">
      {/* Dynamic Action Header banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-[#0a0d14] p-4 rounded-xl border border-[#1e293b] backdrop-blur-md gap-4">
        <div>
          <h2 className="text-xl font-semibold text-white font-sans tracking-tight">DLP Compliance Console</h2>
          <p className="text-sm text-slate-400 font-mono mt-1">Status: SECURE // Operational Node active on port 3000</p>
        </div>
        <div className="flex gap-2">
          <button
            id="watchdog-trigger-btn"
            onClick={onSimulateWatchdog}
            className="px-4 py-2 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 hover:bg-cyan-500/20 text-xs font-mono tracking-wider uppercase rounded-lg transition-all shadow-[0_0_10px_rgba(34,211,238,0.15)]"
          >
            Trigger Directory Watchdog Scan
          </button>
          <button
            id="refresh-stats-btn"
            onClick={onRefresh}
            className="px-3 py-2 bg-[#020408] border border-[#1e293b] text-slate-300 hover:text-white hover:border-slate-700 text-xs font-mono rounded-lg transition-all"
          >
            Sync System
          </button>
        </div>
      </div>

      {/* Main Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        {/* Total Scans Card */}
        <div id="stat-total-scans" className="relative group overflow-hidden bg-[#0a0d14] p-4 rounded-xl border border-[#1e293b] backdrop-blur-md flex flex-col justify-between h-28">
          <div className="absolute top-1 right-1 text-xs font-mono text-slate-600 select-none">NODE-01</div>
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Total Scans</span>
            <Activity size={16} className="text-cyan-400" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-white">{stats.totalScans}</div>
            <div className="text-[10px] text-slate-500 font-mono">DLP pipeline active</div>
          </div>
          <div className="absolute bottom-0 left-0 h-[2px] bg-cyan-500 w-0 group-hover:w-full transition-all duration-300 shadow-[0_0_8px_#22d3ee]" />
        </div>

        {/* High Risk Card */}
        <div id="stat-high-risk" className="relative group overflow-hidden bg-[#0a0d14] p-4 rounded-xl border border-[#1e293b] backdrop-blur-md flex flex-col justify-between h-28">
          <div className="absolute top-1 right-1 text-xs font-mono text-red-950 select-none">SEV-1</div>
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">High Risk</span>
            <AlertTriangle size={16} className="text-red-500" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-red-400">{stats.highRiskCount}</div>
            <div className="text-[10px] text-red-500/80 font-mono">Blocked or redacted</div>
          </div>
          <div className="absolute bottom-0 left-0 h-[2px] bg-red-500 w-0 group-hover:w-full transition-all duration-300" />
        </div>

        {/* Medium Risk Card */}
        <div id="stat-medium-risk" className="relative group overflow-hidden bg-[#0a0d14] p-4 rounded-xl border border-[#1e293b] backdrop-blur-md flex flex-col justify-between h-28">
          <div className="absolute top-1 right-1 text-xs font-mono text-yellow-950/80 select-none">SEV-2</div>
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Medium Risk</span>
            <Eye size={16} className="text-yellow-500" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-yellow-400">{stats.mediumRiskCount}</div>
            <div className="text-[10px] text-yellow-500/80 font-mono">Mask overlays applied</div>
          </div>
          <div className="absolute bottom-0 left-0 h-[2px] bg-yellow-500 w-0 group-hover:w-full transition-all duration-300" />
        </div>

        {/* Low Risk Card */}
        <div id="stat-low-risk" className="relative group overflow-hidden bg-[#0a0d14] p-4 rounded-xl border border-[#1e293b] backdrop-blur-md flex flex-col justify-between h-28">
          <div className="absolute top-1 right-1 text-xs font-mono text-emerald-950/60 select-none">SYS-OK</div>
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Low Risk</span>
            <CheckCircle size={16} className="text-emerald-500" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-emerald-400">{stats.lowRiskCount}</div>
            <div className="text-[10px] text-emerald-500/80 font-mono">Marked clean & safe</div>
          </div>
          <div className="absolute bottom-0 left-0 h-[2px] bg-emerald-500 w-0 group-hover:w-full transition-all duration-300" />
        </div>

        {/* Uploads Blocked Card */}
        <div id="stat-blocked" className="relative group overflow-hidden bg-[#0a0d14] p-4 rounded-xl border border-[#1e293b] backdrop-blur-md flex flex-col justify-between h-28 col-span-1">
          <div className="absolute top-1 right-1 text-xs font-mono text-red-950 select-none">DLP-BLOCK</div>
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Blocked</span>
            <Shield size={16} className="text-red-500" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-red-500">{stats.uploadsBlocked}</div>
            <div className="text-[10px] text-red-500/80 font-mono">Upload streams cut</div>
          </div>
          <div className="absolute bottom-0 left-0 h-[2px] bg-red-600 w-0 group-hover:w-full transition-all duration-300" />
        </div>

        {/* Protected copy images Card */}
        <div id="stat-protected" className="relative group overflow-hidden bg-[#0a0d14] p-4 rounded-xl border border-[#1e293b] backdrop-blur-md flex flex-col justify-between h-28 col-span-1">
          <div className="absolute top-1 right-1 text-xs font-mono text-cyan-950 select-none">ENC-MAPPED</div>
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-xs font-mono uppercase tracking-wider">Protected Copy</span>
            <FileText size={16} className="text-cyan-400" />
          </div>
          <div>
            <div className="text-2xl font-bold font-mono text-cyan-400">{stats.protectedImages}</div>
            <div className="text-[10px] text-cyan-500/80 font-mono font-sans">Active redacted layers</div>
          </div>
          <div className="absolute bottom-0 left-0 h-[2px] bg-cyan-400 w-0 group-hover:w-full transition-all duration-300 shadow-[0_0_8px_#22d3ee]" />
        </div>
      </div>

      {/* Main Core Section Split (Vector Chart & Audit Feed) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Vector graph panel */}
        <div id="cyber-chart" className="lg:col-span-2 bg-[#0a0d14] rounded-xl border border-[#1e293b] p-5 backdrop-blur-md flex flex-col justify-between h-auto">
          <div>
            <div className="flex justify-between items-center">
              <h3 className="text-md font-medium text-slate-200">Security Threat Scan Trend (7-Day Metric)</h3>
              <div className="flex gap-2 text-[10px] font-mono">
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-red-500 animate-pulse" /> High</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-yellow-400" /> Medium</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded bg-emerald-500" /> Low</span>
              </div>
            </div>
            <p className="text-xs text-slate-500 font-mono mt-1">Real-time localized watchdog metrics on system channels</p>
          </div>

          <div className="my-6 relative h-48 w-full">
            {loading ? (
              <div className="absolute inset-0 flex items-center justify-center text-slate-500 font-mono text-xs">
                Recalculating network matrices...
              </div>
            ) : (
              <div className="h-full w-full flex flex-col justify-between">
                {/* Visual SVG bar grid charts */}
                <div className="h-36 w-full flex justify-between items-end px-4 border-b border-[#1e293b] relative">
                  {/* Grid Lines */}
                  <div className="absolute inset-0 w-full h-full flex flex-col justify-between pointer-events-none opacity-20">
                    <div className="border-t border-[#1e293b] w-full" />
                    <div className="border-t border-[#1e293b] w-full" />
                    <div className="border-t border-[#1e293b] w-full" />
                  </div>

                  {trends.map((t, idx) => {
                    const totalVal = t.high + t.medium + t.low || 1;
                    const maxScale = Math.max(...trends.map(x => x.high + x.medium + x.low)) || 4;
                    const highPct = (t.high / maxScale) * 100;
                    const medPct = (t.medium / maxScale) * 100;
                    const lowPct = (t.low / maxScale) * 100;

                    return (
                      <div key={idx} className="flex flex-col items-center flex-1 h-full justify-end group z-10">
                        <div className="w-8 flex flex-col justify-end h-full gap-[2px] cursor-pointer hover:brightness-125 transition-all">
                          {/* Segmented stacking of risk categories */}
                          {highPct > 0 && <div style={{ height: `${highPct}%` }} className="bg-red-500/85 rounded-t w-full border border-red-400/20 shadow-lg shadow-red-500/10" title={`High: ${t.high}`} />}
                          {medPct > 0 && <div style={{ height: `${medPct}%` }} className="bg-yellow-400/85 w-full border border-yellow-300/20" title={`Medium: ${t.medium}`} />}
                          {lowPct > 0 && <div style={{ height: `${lowPct}%` }} className="bg-emerald-500/85 rounded-b w-full border border-emerald-400/20" title={`Low: ${t.low}`} />}
                          {totalVal === 0 && <div className="h-1 bg-slate-800 w-full rounded" />}
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 mt-2">{t.day}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono border-t border-[#1e293b] pt-3">
            <span>DLP ENCRYPTION KEY MAPPED IN MEMORY</span>
            <span>SECURE AES-256 SYSTEM CONTAINER</span>
          </div>
        </div>

        {/* Live Operational Logs panel */}
        <div id="logs-panel" className="bg-[#0a0d14] rounded-xl border border-[#1e293b] p-5 backdrop-blur-md flex flex-col justify-between h-auto">
          <div>
            <h3 className="text-md font-medium text-slate-200">Network Security Logs</h3>
            <p className="text-xs text-slate-500 font-mono mt-1">Direct kernel event logs generated under local sandbox</p>
          </div>

          <div className="my-4 h-64 overflow-y-auto space-y-3 font-mono text-xs pr-1 scrollbar-thin">
            {logs.map((log) => {
              const statusColor = 
                log.status === 'SUCCESS' ? 'text-emerald-400' :
                log.status === 'WARNING' ? 'text-yellow-400' : 'text-red-500';

              return (
                <div key={log.id} className="p-2 bg-[#020408]/40 rounded border border-[#1e293b]/40 flex flex-col hover:bg-[#020408]/80 transition-colors">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-slate-500">{new Date(log.timestamp).toLocaleTimeString()}</span>
                    <span className={`text-[10px] font-bold ${statusColor}`}>{log.action}</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 select-all">{log.details}</p>
                </div>
              );
            })}
          </div>

          <div className="text-[10px] text-slate-500 font-mono border-t border-[#1e293b] pt-3 flex justify-between items-center">
            <span>AUDIT LOG TRACK AT 100%</span>
            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> LIVE STREAM</span>
          </div>
        </div>
      </div>
    </div>
  );
}
